"""Tiny SQLite store: officer decisions on alerts (human-in-the-loop) and citizen-submitted reports."""
import json
import sqlite3
import time
from contextlib import contextmanager

from .config import DB_PATH

SCHEMA = """
CREATE TABLE IF NOT EXISTS decisions(
  id INTEGER PRIMARY KEY, city TEXT, ctx_key TEXT, ward TEXT, level TEXT, action TEXT, officer TEXT, note TEXT, ts REAL);
CREATE TABLE IF NOT EXISTS reports(
  id INTEGER PRIMARY KEY, city TEXT, ctx_key TEXT, frame INTEGER, text TEXT, lat REAL, lon REAL, place TEXT,
  cell INTEGER, label TEXT, flood_conf REAL, credibility REAL, status TEXT, breakdown TEXT, has_image INTEGER, ts REAL);
"""


@contextmanager
def conn():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    c.executescript(SCHEMA)                       # idempotent: tables are created on first use
    try:
        yield c
        c.commit()
    finally:
        c.close()


def init_db():
    with conn() as c:
        c.executescript(SCHEMA)


def save_decision(city, ctx_key, ward, level, action, officer="control-room", note=""):
    with conn() as c:
        c.execute("INSERT INTO decisions(city,ctx_key,ward,level,action,officer,note,ts) VALUES(?,?,?,?,?,?,?,?)",
                  (city, ctx_key, ward, level, action, officer, note, time.time()))


def get_decisions(city, ctx_key):
    with conn() as c:
        rows = c.execute("SELECT * FROM decisions WHERE city=? AND ctx_key=? ORDER BY id", (city, ctx_key)).fetchall()
    return {(r["ward"], r["level"]): dict(r) for r in rows}      # latest decision per (ward, level) wins


def save_report(city, ctx_key, frame, text, lat, lon, place, cell, label, flood_conf, cred, status, breakdown, has_image):
    with conn() as c:
        c.execute("INSERT INTO reports(city,ctx_key,frame,text,lat,lon,place,cell,label,flood_conf,credibility,status,breakdown,"
                  "has_image,ts) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                  (city, ctx_key, frame, text, lat, lon, place, cell, label, flood_conf, cred, status,
                   json.dumps(breakdown), int(has_image), time.time()))


def list_reports(city, ctx_key):
    with conn() as c:
        rows = c.execute("SELECT * FROM reports WHERE city=? AND ctx_key=? ORDER BY id", (city, ctx_key)).fetchall()
    out = []
    for r in rows:
        d = dict(r)
        d["breakdown"] = json.loads(d["breakdown"])
        out.append(d)
    return out


def reset():
    with conn() as c:
        c.executescript("DELETE FROM decisions; DELETE FROM reports;")
