"""
Replay + validation of past events (the "history & comparison" and "prove it predicts" parts).

For an event we step through time. At every issue time the model sees only observed rain up to that hour
plus a noisy FORECAST of the future; we then compare with what really flooded in the 18 labelled hours.

 nowcast skill : P(flood) now vs truth now                     -> AUC, precision, recall
 alert skill   : for each cell that flooded, when did the system first raise a High alert (p>=0.35 within the
                 next 6 h)? -> hit rate, lead time (h), false-alarm share
The 2023 event is IN-SAMPLE for the model (trained before 2025); the 2025 event is OUT-OF-TIME.
"""
import json

import numpy as np
from sklearn.metrics import average_precision_score, roc_auc_score

from ..config import CITY_ORDER, MODELS, THRESH
from ..context import replay_context
from ..data_service import EVENT_FRAMES, CityData, get_city
from ..ml.features import context_features
from ..ml.model import get_model
from .risk import central_forecast

_NOW = {}
THR = THRESH["high"]


def nowcast(cd: CityData, event: str, frame: int) -> np.ndarray:
    """P(flood) right now for every cell (horizon 0) at a frame."""
    k = (cd.name, event, frame)
    if k not in _NOW:
        ctx = replay_context(cd, event, frame)
        p, _ = get_model().predict(context_features(ctx, [0]))
        _NOW[k] = p
    return _NOW[k]


def evaluate(cd: CityData, event: str) -> dict:
    ev = cd.events[event]
    truth = cd.truth_flood[event]                       # (18, n)
    land = ~cd.cells.is_water.values
    n_in_sample = ev["date"] < "2025-01-01"

    # ---- nowcast skill ----
    P0 = np.stack([nowcast(cd, event, f) for f in range(EVENT_FRAMES)])
    y, p = truth[:, land].ravel(), P0[:, land].ravel()
    pred = p >= THR
    tp = int((pred & (y == 1)).sum())
    out = dict(
        episode_definition="3+ consecutive flooded hours", event=event, date=ev["date"], in_sample=bool(n_in_sample), total_mm_24h=ev["total_mm_24h"],
        auc=round(float(roc_auc_score(y, p)), 3), pr_auc=round(float(average_precision_score(y, p)), 3),
        precision=round(tp / max(1, int(pred.sum())), 3), recall=round(tp / max(1, int((y == 1).sum())), 3),
        flood_share_truth=np.round(truth[:, land].mean(1), 3).tolist(),
        flood_share_pred=np.round(P0[:, land].mean(1), 3).tolist(),
    )
    # ---- alert / lead-time skill (High and Critical thresholds) ----
    # a flood EPISODE = 3+ consecutive flooded hours (labels flicker hour to hour, so 1 hour is not a flood)
    run3 = (truth[:-2] & truth[1:-1] & truth[2:]).astype(bool)
    ever = run3.any(0) & land
    first = np.where(ever, run3.argmax(0), np.nan)
    issue = list(range(-12, 12))
    thresholds = {"high": THRESH["high"], "critical": THRESH["critical"]}
    alerted_at = {k: np.full(cd.n, np.nan) for k in thresholds}
    for i in issue:
        Pf = central_forecast(replay_context(cd, event, i), np.arange(0, 7)).max(0)
        for k, thr in thresholds.items():
            newly = (Pf >= thr) & land & np.isnan(alerted_at[k])
            alerted_at[k][newly] = i
    for k in thresholds:
        a_at = alerted_at[k]
        alerted = ~np.isnan(a_at) & land
        lead = (first - a_at)[ever & alerted]
        early = lead[lead > 0]
        out[f"alerts_{k}"] = dict(
            cells_alerted=int(alerted.sum()), hit_rate=round(float((lead > 0).sum() / max(1, ever.sum())), 3),
            median_lead_h=round(float(np.median(early)), 1) if len(early) else 0.0,
            false_alarm_share=round(float((alerted & ~ever).sum() / max(1, alerted.sum())), 3))
    out["cells_flooded"] = int(ever.sum())
    out["hit_rate_before_flood"] = out["alerts_high"]["hit_rate"]
    out["median_lead_h"] = out["alerts_high"]["median_lead_h"]
    out["false_alarm_share"] = out["alerts_high"]["false_alarm_share"]
    out["lead_cap_note"] = "alerts are evaluated from 12 h before the labelled window; any earlier warning is not measured"
    # ---- event facts for comparison ----
    pop = cd.cells["pop"].values
    r = cd.r1[ev["start_idx"] - 12: ev["start_idx"] + 30]
    flooded_cells = ever
    out.update(
        peak_rain_1h=round(float(cd.r1[ev["start_idx"]: ev["start_idx"] + 18].max()), 1),
        rain_24h_max=round(float(np.convolve(r, np.ones(24), "valid").max()), 0),
        people_in_flooded_cells=int(pop[flooded_cells].sum()),
        pct_cells_flooded=round(float(flooded_cells.sum() / land.sum() * 100), 1),
        severity_peak=np.bincount(cd.truth_sev[event][int(truth[:, land].mean(1).argmax())][land], minlength=4).tolist())
    return out


def compute_all_metrics(verbose=True) -> dict:
    res = {}
    for city in CITY_ORDER:
        cd = get_city(city)
        res[city] = {e: evaluate(cd, e) for e in cd.events}
        if verbose:
            for e, m in res[city].items():
                print(f"  {city:10s} {m['date']} ({'in-sample' if m['in_sample'] else 'OUT-OF-TIME'}) AUC {m['auc']} | HIGH: hit {m['alerts_high']['hit_rate']} "
                      f"lead {m['alerts_high']['median_lead_h']}h FA {m['alerts_high']['false_alarm_share']} | CRIT: hit {m['alerts_critical']['hit_rate']} "
                      f"lead {m['alerts_critical']['median_lead_h']}h FA {m['alerts_critical']['false_alarm_share']}")
    (MODELS / "replay_metrics.json").write_text(json.dumps(res, indent=1))
    return res


def load_metrics() -> dict:
    p = MODELS / "replay_metrics.json"
    return json.loads(p.read_text()) if p.exists() else {}
