"""
Synthetic social-media data (English + Hinglish, typos, emojis).

 * make_corpus()      -> labelled posts to TRAIN the text classifier (templates held out for testing)
 * make_streams(...)  -> posts tied to each historic event: genuine reports from cells that really flooded,
                         plus misplaced reports, rumours and chatter (all labelled with hidden truth)

REAL USE: replace with CrisisNLP / HumAID / CrisisMMD labelled tweets. Templated text makes the classifier
look better than it would on real, messy language, so treat its scores as optimistic.
"""
import numpy as np
import pandas as pd

from ..config import DATA

TEMPLATES = {
    "waterlogging": [
        "Knee deep water at {p}, vehicles stuck everywhere", "{p} is completely waterlogged since the last hour",
        "Water entering shops at {p}!! please help", "Drain overflowing at {p}, whole lane under water",
        "{p} me paani bhar gaya hai, ghutno tak pani", "Severe waterlogging near {p} #flood", "Roads turned into a river at {p}",
        "Dirty water inside our building compound at {p}, ground floor flooded", "Cars floating in {p}, never seen this much water",
        "water level rising fast at {p}, already above the footpath", "{p} mein bahut pani jama hai, bachche school nahi ja pa rahe",
        "flooded streets in {p} again, drains are choked", "Heavy flooding at {p} junction, traffic crawling in water",
        "Sewage and rainwater mixed, {p} lane is under 2 feet water", "ground floor houses in {p} have water inside",
        "Whole colony at {p} is submerged, water above the steps",
    ],
    "road_blocked": [
        "Road closed at {p}, water above the divider", "Subway near {p} flooded, do not take that route",
        "Bus stopped at {p}, cannot cross the water", "{p} underpass completely blocked, cars stuck inside",
        "Please avoid {p} road, one lane submerged and traffic is stuck", "Bridge approach at {p} under water, diversion in place",
        "{p} rasta band hai, pani ke wajah se gaadiyan fas gayi", "Auto and cabs refusing to go to {p}, water on the road",
        "Traffic police diverting vehicles at {p} due to flooding", "Cannot reach {p}, main road under water, stuck for an hour",
        "Train services affected, tracks near {p} submerged", "waterlogged road at {p}, two bikes fell down",
    ],
    "rescue_request": [
        "Family stuck on first floor at {p}, water rising, need help", "Need boat rescue at {p}, elderly people trapped",
        "Please send help to {p}, water inside the house", "SOS {p} water is up to the waist, children with us",
        "Stranded in {p} with a pregnant woman, no way out, please send rescue", "{p} me log phase hue hai, madad chahiye jaldi",
        "Anyone from NDRF? people on rooftops at {p}", "Urgent: diabetic patient needs evacuation from {p}, water everywhere",
        "We are trapped in our car at {p}, water entering, help", "Rescue needed at {p}, bedridden mother and water rising",
    ],
    "damage": [
        "Power cut in {p} after flooding, transformer under water", "Wall collapsed near {p} due to heavy rain and water",
        "Tree fell on the road at {p}, water everywhere", "{p} mein bijli gayi hai paani ki wajah se, 5 ghante se",
        "Shop goods destroyed by flood water at {p}", "Electric pole leaning at {p}, wires in water, dangerous",
        "Boundary wall washed away at {p}", "Phone network down in {p} after the floods", "Water supply contaminated in {p} after flooding",
    ],
    "not_flood": [
        "Lovely rain in {p} today, chai and pakode time", "Traffic jam at {p} because of an accident", "Match postponed due to rain, so sad",
        "Heavy rain but roads are clear at {p}, no waterlogging", "Anyone know a good biryani place near {p}?", "Just reached {p}, all dry here",
        "Rain stopped in {p}, sun is out", "Monday blues, so much work", "Metro running smoothly today, kudos to the staff",
        "Water supply cut at {p} for maintenance till 5pm", "Rain rain go away lol", "Beautiful clouds over {p} this evening",
        "Is there a 24 hour pharmacy in {p}?", "Sale at the mall near {p} this weekend", "Power cut at {p} for line maintenance, back by noon",
        "It is raining but {p} is fine, drains working well", "Traffic is normal in {p}, no issues so far",
        "New cafe opened at {p}, try the cold coffee", "Water bottle delivery guy still not here, ugh",
        "Flood of emails to answer today", "rain in {p}, perfect weather for a drive, roads are fine",
    ],
}
RUMOR = [
    "Dam breached near {p}!! forward to everyone, run to high ground",
    "Breaking: embankment broke at {p}, whole area will be under 10 feet water, share now",
    "Forward this: water released from the dam, {p} will go under in 1 hour",
    "Heard {p} is completely drowned, nobody can survive, please share",
]
LABELS = list(TEMPLATES)
EMOJI = ["", "", "", " 🌧️", " 😰", " 🙏", " #rain", " #flood", "!!", " pls RT", " 📍"]
HASHTAG_CITY = {"Mumbai": " #MumbaiRains", "Chennai": " #ChennaiRains", "Kochi": " #KochiRains", "Kolkata": " #KolkataRains",
                "Hyderabad": " #HyderabadRains", "Guwahati": " #GuwahatiFloods", "Nagpur": " #NagpurRains"}


def corrupt(text, rng, p_typo=0.05):
    chars = list(text)
    for i in range(len(chars)):
        if chars[i].isalpha() and rng.random() < p_typo * 0.5:
            chars[i] = ""                               # drop a letter
        elif chars[i].isalpha() and rng.random() < p_typo * 0.25:
            chars[i] = chars[i] * 2
    out = "".join(chars)
    r = rng.random()
    return out.lower() if r < 0.15 else (out.upper() if r < 0.2 else out)


def all_places():
    from ..gazetteer import GAZETTEER
    return [p for d in GAZETTEER.values() for p in d]


def make_corpus(seed=3, per_template=22):
    rng = np.random.default_rng(seed)
    places = all_places()
    rows = []
    for label, tpls in {**TEMPLATES, "rumor": RUMOR}.items():
        for ti, tpl in enumerate(tpls):
            split = "test" if ti % 4 == 3 else "train"                  # whole templates are held out
            for _ in range(per_template):
                t = tpl.format(p=rng.choice(places)) + rng.choice(EMOJI)
                rows.append(dict(text=corrupt(t, rng), label=label, split=split, template=f"{label}-{ti}"))
    return pd.DataFrame(rows)


def make_streams(cities: dict, seed=11):
    """One CSV per city: data/social_<city>.csv (posts around both historic events)."""
    from ..gazetteer import GAZETTEER
    rng = np.random.default_rng(seed)
    for name, cd in cities.items():
        rows = []
        gaz = GAZETTEER[name]
        c = cd.cells
        land = np.flatnonzero(~c.is_water.values)
        for eid, ev in cd.events.items():
            flooded = cd.truth_flood[eid]
            for f in range(-6, 18):
                ts0 = cd.abs_to_ts(ev["start_idx"] + f)
                posts = []                                                  # (kind, label, cell, text)
                if f >= 0:
                    fc = np.flatnonzero(flooded[f] & ~c.is_water.values)
                    if len(fc):
                        lam = min(7.0, 0.045 * len(fc) + 0.5)
                        w = c["pop"].values[fc] + 1
                        for cell in rng.choice(fc, size=rng.poisson(lam), p=w / w.sum()):
                            lab = rng.choice(["waterlogging", "road_blocked", "rescue_request", "damage"], p=[.45, .25, .15, .15])
                            posts.append(("genuine", lab, int(cell)))
                    dry = np.setdiff1d(land, np.flatnonzero(flooded[f]))
                    if len(dry):
                        for cell in rng.choice(dry, size=rng.poisson(0.6)):                 # reported at a dry place
                            posts.append(("misplaced", rng.choice(["waterlogging", "road_blocked"]), int(cell)))
                    for _ in range(rng.poisson(0.35)):
                        posts.append(("rumor", "damage", int(rng.choice(land))))
                for _ in range(rng.poisson(1.6)):
                    posts.append(("chatter", "not_flood", int(rng.choice(land))))
                for kind, lab, cell in posts:
                    # name the nearest known place to the cell (if any), else leave location to GPS
                    near = min(cd.gaz, key=lambda g: np.hypot(c.x[cell] - cd.xy(g["lat"], g["lon"])[0], c.y[cell] - cd.xy(g["lat"], g["lon"])[1])) if cd.gaz else None
                    place = near["name"] if near and np.hypot(c.x[cell] - cd.xy(near["lat"], near["lon"])[0], c.y[cell] - cd.xy(near["lat"], near["lon"])[1]) < 1800 else None
                    mode = rng.choice(["gps", "place", "none"], p=[.35, .5, .15])
                    if place is None and mode == "place":
                        mode = "gps"
                    tpl = rng.choice(RUMOR if kind == 'rumor' else TEMPLATES[lab])
                    p_text = place if mode == "place" else "our area"          # place names only appear in 'place' posts
                    text = corrupt(tpl.format(p=p_text) + rng.choice(EMOJI) + (HASHTAG_CITY[name] if rng.random() < .3 else ""), rng)
                    if mode == "gps":
                        lat, lon = c.lat[cell] + rng.normal(0, .0006), c.lon[cell] + rng.normal(0, .0006)
                    else:
                        lat = lon = np.nan
                    rows.append(dict(
                        city=name, event_id=eid, frame=f, minute=int(rng.integers(0, 60)),
                        timestamp=ts0 + pd.Timedelta(minutes=0), text=text, lat=lat, lon=lon,
                        has_image=int(rng.random() < (0.25 if kind == "genuine" else 0.08)),
                        kind=kind, truth_flood=int(kind == "genuine"), true_cell=cell))
        df = pd.DataFrame(rows).sort_values(["event_id", "frame", "minute"]).reset_index(drop=True)
        df.insert(0, "post_id", [f"{cd.code}-P{i + 1:04d}" for i in range(len(df))])
        df.to_csv(DATA / f"social_{name.lower()}.csv", index=False)
        print(f"{name:10s} {len(df)} posts  genuine {int((df.kind == 'genuine').sum())}  misplaced {int((df.kind == 'misplaced').sum())}  "
              f"rumor {int((df.kind == 'rumor').sum())}  chatter {int((df.kind == 'chatter').sum())}")
