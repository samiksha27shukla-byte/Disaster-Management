"""
Social-media signals -> verified incident reports.

Pipeline for every post:  text classifier (flood or not) -> locate (GPS, else place name via gazetteer) ->
verification score from FIVE independent signals -> status (verified / likely / unverified).

 score = 100 * sigmoid(-3.2 + 2.4*text + 3.4*geo_plausibility + 1.0*rain_support + 1.6*corroboration
                       + 0.5*photo + 0.8*location_precision)
   text            flood-language confidence from the NLP model
   geo_plausibility model flood probability at that spot (and its neighbours) at that time
   rain_support    is it actually raining hard (city rain, last 3 h)?
   corroboration   other flood reports within 1.2 km in the last 3 h
Weights are hand-set (not learned); thresholds: verified >= 70, likely >= 45.
"""
import math

import numpy as np
import pandas as pd

from .. import db
from ..config import DATA, LOOKBACK
from ..ml.nlp import extract_place, get_nlp
from . import replay

_STREAM = {}
_SCORED = {}
VERIFIED, LIKELY = 70, 45


def _sigmoid(v):
    return 1 / (1 + math.exp(-v))


def neighbours(cd, cell, radius=700.0):
    c = cd.cells
    d = np.hypot(c.x.values - c.x[cell], c.y.values - c.y[cell])
    return np.flatnonzero((d <= radius) & (d > 0))


def score_report(cd, cell, flood_conf, loc, has_image, p_now, r3_city, n_corr, rumor_prob=0.0):
    """p_now = nowcast probability for all cells. -> (score 0-100, status, breakdown)"""
    p_cell = float(p_now[cell])
    nb = neighbours(cd, cell)
    p_neigh = float(p_now[nb].mean()) if len(nb) else p_cell
    land = ~cd.cells.is_water.values
    rank = float((p_now[land] < p_cell).mean())              # how unusual is this spot compared with the rest of the city?
    geo = 0.4 * p_cell + 0.2 * p_neigh + 0.4 * rank
    rain = float(np.clip((r3_city - 8.0) / 40.0, 0, 1))
    corr = min(1.0, n_corr / 3.0)
    loc_prec = {"gps": 1.0, "place": 0.6, "none": 0.0}[loc]
    z = (-3.4 + 1.5 * flood_conf + 3.2 * geo + 0.8 * rain + 1.6 * corr + 0.6 * has_image + 0.6 * loc_prec
         - 3.5 * rumor_prob)
    score = 100 * _sigmoid(z)
    if loc == "none":
        score = min(score, 40.0)
    status = "verified" if score >= VERIFIED else ("likely" if score >= LIKELY else "unverified")
    return round(score, 1), status, dict(
        text_confidence=round(flood_conf, 2), rumour_likelihood=round(float(rumor_prob), 2), model_risk_at_location=round(float(geo), 2),
        rain_support=round(rain, 2), corroborating_reports=int(n_corr), photo=bool(has_image), location_precision=loc)


def _locate(cd, text, lat, lon):
    if lat is not None and not (isinstance(lat, float) and math.isnan(lat)):
        i, d = cd.nearest_cell(lat, lon)
        return i, "gps", None
    g = extract_place(cd, text)
    if g:
        return g["cell"], "place", g["name"]
    return None, "none", None


def _stream(cd):
    if cd.name not in _STREAM:
        _STREAM[cd.name] = pd.read_csv(DATA / f"social_{cd.name.lower()}.csv")
    return _STREAM[cd.name]


def scored_stream(cd, event):
    """All posts of an event, scored in time order using only information available at post time."""
    k = (cd.name, event)
    if k in _SCORED:
        return _SCORED[k]
    df = _stream(cd)
    df = df[df.event_id == event].sort_values(["frame", "minute"])
    nlp = get_nlp()
    out, flood_posts = [], []
    ev = cd.events[event]
    for r in df.itertuples():
        cl = nlp.classify_full(r.text)
        label, conf, rumor = cl["label"], cl["flood_conf"], cl["rumor_prob"]
        cell, loc, place = _locate(cd, r.text, r.lat, r.lon)
        item = dict(post_id=r.post_id, frame=int(r.frame), minute=int(r.minute), text=r.text, label=label, flood_conf=round(conf, 2),
                    has_image=bool(r.has_image), loc=loc, place=place, cell=None if cell is None else int(cell),
                    truth_flood=bool(r.truth_flood), kind=r.kind, source="stream")
        if cell is not None:
            item["lat"], item["lon"] = float(cd.cells.lat[cell]), float(cd.cells.lon[cell])
        if conf >= 0.5 and cell is not None:
            p0 = replay.nowcast(cd, event, int(r.frame))
            n_corr = sum(1 for q in flood_posts if 0 <= r.frame - q["frame"] <= 3 and
                         math.hypot(cd.cells.x[q["cell"]] - cd.cells.x[cell], cd.cells.y[q["cell"]] - cd.cells.y[cell]) <= 1200)
            r3 = float(cd.r1[ev["start_idx"] + int(r.frame) - 2: ev["start_idx"] + int(r.frame) + 1].sum())
            sc, st, bd = score_report(cd, cell, conf, loc, int(r.has_image), p0, r3, n_corr, rumor)
            item.update(credibility=sc, status=st, breakdown=bd)
            flood_posts.append(dict(frame=int(r.frame), cell=int(cell)))
        elif conf >= 0.5:
            item.update(credibility=round(min(40.0, 100 * conf * 0.4) * (1 - rumor), 1), status="unverified",
                        breakdown=dict(text_confidence=round(conf, 2), rumour_likelihood=round(rumor, 2), location_precision="none"))
        else:
            item.update(credibility=None, status="not_flood", breakdown={})
        out.append(item)
    _SCORED[k] = out
    return out


def visible_reports(ctx, risk=None):
    """Reports a control room can see right now (stream up to the current frame + officer/citizen submissions)."""
    cd = ctx.cd
    items = []
    if ctx.mode == "replay":
        items += [p for p in scored_stream(cd, ctx.event) if p["frame"] <= ctx.frame]
    for r in db.list_reports(cd.name, ctx.key):
        items.append(dict(post_id=f"USR-{r['id']}", frame=r["frame"], minute=0, text=r["text"], label=r["label"], flood_conf=round(r["flood_conf"], 2),
                          has_image=bool(r["has_image"]), loc="gps" if r["place"] is None else "place", place=r["place"], cell=r["cell"],
                          lat=r["lat"], lon=r["lon"], credibility=r["credibility"], status=r["status"], breakdown=r["breakdown"], source="user"))
    return items


def submit_report(ctx, risk, text, lat=None, lon=None, has_image=False):
    """Score a newly submitted report against the current situation and store it."""
    cd = ctx.cd
    cl = get_nlp().classify_full(text)
    label, conf, rumor = cl["label"], cl["flood_conf"], cl["rumor_prob"]
    cell, loc, place = _locate(cd, text, lat, lon)
    res = dict(text=text, label=label, flood_conf=round(conf, 2), loc=loc, place=place, cell=None if cell is None else int(cell))
    if conf < 0.5:
        res.update(credibility=None, status="not_flood", breakdown={})
        return res
    if cell is None:
        res.update(credibility=round(min(40.0, 100 * conf * 0.4) * (1 - rumor), 1), status="unverified",
                   breakdown=dict(text_confidence=round(conf, 2), rumour_likelihood=round(rumor, 2), location_precision="none"))
    else:
        recent = [p for p in visible_reports(ctx) if p.get("cell") is not None and p["flood_conf"] >= 0.5
                  and ctx.frame is not None and 0 <= (ctx.frame or 0) - p["frame"] <= 3]
        n_corr = sum(1 for q in recent if math.hypot(cd.cells.x[q["cell"]] - cd.cells.x[cell], cd.cells.y[q["cell"]] - cd.cells.y[cell]) <= 1200)
        r3 = float(ctx.rain[ctx.L - 2: ctx.L + 1].sum())
        sc, st, bd = score_report(cd, cell, conf, loc, int(has_image), risk.p_now, r3, n_corr, rumor)
        res.update(credibility=sc, status=st, breakdown=bd, lat=float(cd.cells.lat[cell]), lon=float(cd.cells.lon[cell]))
    db.save_report(cd.name, ctx.key, ctx.frame if ctx.frame is not None else 0, text, res.get("lat"), res.get("lon"), place, res["cell"], label,
                   conf, res.get("credibility"), res["status"], res["breakdown"], has_image)
    return res


def evaluate_verification(cities) -> dict:
    """AUC of the credibility score at separating genuine reports from misplaced / rumour reports (synthetic stream)."""
    from sklearn.metrics import roc_auc_score
    rows = []
    for cd in cities:
        for e in cd.events:
            rows += [p for p in scored_stream(cd, e) if p.get("credibility") is not None]
    y = [int(p["truth_flood"]) for p in rows]
    s = [p["credibility"] for p in rows]
    by = {}
    for p in rows:
        by.setdefault(p["kind"], []).append(p["credibility"])
    stat = pd.crosstab(pd.Series([p["kind"] for p in rows]), pd.Series([p["status"] for p in rows]), normalize="index").round(2)
    return dict(n=len(rows), auc=round(float(roc_auc_score(y, s)), 3),
                mean_score_by_kind={k: round(float(np.mean(v)), 1) for k, v in by.items()},
                status_share_by_kind=stat.to_dict("index"))
