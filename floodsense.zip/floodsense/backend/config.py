"""Shared constants. Probability bands, horizons and file locations."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
MODELS = ROOT / "models"
FRONTEND = ROOT / "frontend"
DB_PATH = ROOT / "floodsense.db"

START = "2021-01-01"          # hour index 0 of every weather series
LOOKBACK = 96                 # hours of history kept in a Context
HORIZON = 24                  # hours ahead we predict
AXIS_LEN = LOOKBACK + HORIZON + 26
DX = 500.0                    # grid spacing (m)
CELL_KM2 = DX * DX / 1e6

LEVELS = ["Low", "Moderate", "High", "Critical"]
THRESH = {"moderate": 0.15, "high": 0.35, "critical": 0.60}   # probability bands
SEVERITY = ["None", "Low", "Medium", "High"]
CITY_ORDER = ["Mumbai", "Chennai", "Kochi", "Kolkata", "Hyderabad", "Guwahati", "Nagpur"]
RAIN_SCENARIOS = (0.75, 1.0, 1.3)   # forecast-rain multipliers used to build the uncertainty range


def level_index(p: float) -> int:
    if p >= THRESH["critical"]:
        return 3
    if p >= THRESH["high"]:
        return 2
    if p >= THRESH["moderate"]:
        return 1
    return 0


def level_name(p: float) -> str:
    return LEVELS[level_index(p)]


def city_level_index(level_idx_array) -> int:
    """City-wide status from the SHARE of land cells at each level (not just the worst ward)."""
    import numpy as np
    lv = np.asarray(level_idx_array)
    if len(lv) == 0:
        return 0
    crit, high, mod = (lv == 3).mean(), (lv >= 2).mean(), (lv >= 1).mean()
    return 3 if crit >= 0.20 else 2 if high >= 0.20 else 1 if mod >= 0.30 else 0
