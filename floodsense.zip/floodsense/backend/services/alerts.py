"""
Ward-level alerts built from the risk forecast.

 Level      Audience                          Status
 Moderate   control room                      watch
 High       control room + field teams        auto-sent to teams; citizens only after verification
 Critical   + citizens (SMS, local language)  PENDING until a human officer confirms (human-in-the-loop)

One alert per ward and level (de-duplicated). Escalation produces a new alert key.
"""
import math

import numpy as np

from .. import db
from ..config import LEVELS, SEVERITY, THRESH, level_index
from ..gazetteer import ALERT_TEXT, CITY_LANG, LANG_NAME
from .risk import Risk, reasons_for


def _nearest_safe_shelter(risk: Risk, lat, lon):
    cd = risk.ctx.cd
    sh = cd.shelters
    if sh.empty:
        return None
    x, y = cd.xy(lat, lon)
    safe = risk.p_peak[sh.cell.values] < THRESH["high"]
    cand = sh[safe] if safe.any() else sh
    d = np.hypot(cand.x.values - x, cand.y.values - y)
    r = cand.iloc[int(np.argmin(d))]
    place = cd.place_of_cell(int(r.cell))
    return dict(id=r.resource_id, name=f"{place} shelter ({r.resource_id})" if place else r.resource_id,
                capacity=int(r.capacity), cell=int(r.cell), lat=float(r.lat), lon=float(r.lon))


def build_alerts(risk: Risk, reports: list[dict] | None = None) -> list[dict]:
    ctx, cd = risk.ctx, risk.ctx.cd
    c = cd.cells
    decisions = db.get_decisions(cd.name, ctx.key)
    verified_cells = {r["cell"] for r in (reports or []) if r.get("status") in ("verified", "likely") and r.get("cell") is not None}
    lang_local = CITY_LANG[cd.name]
    alerts = []
    tops = {}
    for ward, row in cd.wards.iterrows():
        idx = np.array([i for i in row.cells if not c.is_water[i]], dtype=int)
        if len(idx):
            tops[ward] = (idx, idx[np.argsort(-risk.p_peak[idx])][:3])
    need = sorted({int(i) for _, o in tops.values() if level_index(float(risk.p_peak[o].mean())) >= 1 for i in o})
    all_reasons = reasons_for(risk, need, top=3)              # ONE batched SHAP call for every alerting ward
    for ward, row in cd.wards.iterrows():
        if ward not in tops:
            continue
        idx, order = tops[ward]
        wp = float(risk.p_peak[order].mean())
        lvl = level_index(wp)
        if lvl < 1:
            continue
        lo = float(np.mean([risk.lo[risk.h_peak[i], i] for i in order]))
        hi = float(np.mean([risk.hi[risk.h_peak[i], i] for i in order]))
        high_cells = [i for i in idx if risk.p_peak[i] >= THRESH["high"]]
        leads = [risk.lead_high_min[i] for i in high_cells if not np.isnan(risk.lead_high_min[i])]
        t_impact = float(min(leads)) if leads else None
        sev = int(max(risk.sev[i] for i in order))
        people = float(sum(risk.people_at_risk[i] for i in idx if risk.p_peak[i] >= THRESH["moderate"]))
        prio = float(np.mean(risk.priority[order]))
        rs = all_reasons
        agg = {}
        for i in order:
            for it in rs.get(int(i), []):
                a = agg.setdefault(it["text"], [0, 0.0])
                a[0] += 1
                a[1] += it["shap"]
        reasons = [t for t, _ in sorted(agg.items(), key=lambda kv: (-kv[1][0], -kv[1][1]))[:3]]
        shelter = _nearest_safe_shelter(risk, row.lat, row.lon)
        level = LEVELS[lvl]
        key = f"{cd.name}|{ctx.key}|{ward}|{level}"
        dec = decisions.get((ward, level))
        ward_cells_verified = bool(set(idx.tolist()) & verified_cells)

        if level == "Moderate":
            audience, status = ["control_room"], "watch"
        elif level == "High":
            audience = ["control_room", "field_teams"]
            status = "sent_to_field_teams"
            if ward_cells_verified or lo >= THRESH["high"]:
                audience.append("citizens")
                citizens = "advisory_ready"
            else:
                citizens = "awaiting_verification"
        else:
            audience = ["control_room", "field_teams", "citizens"]
            status = "pending_confirmation"
        if level == "Critical" and dec:
            status = "confirmed_sent" if dec["action"] == "confirm" else "dismissed"
        if level == "High" and dec and dec["action"] == "confirm":
            citizens = "advisory_sent"

        h_txt = max(1, math.ceil((t_impact or 0) / 60.0))          # "now" is shown as "within 1 hour(s)"
        messages = {}
        if lvl >= 2:
            for lg in dict.fromkeys(["en", "hi", lang_local]):
                messages[lg] = dict(lang=LANG_NAME[lg], text=ALERT_TEXT[lg].format(
                    area=row.label, h=h_txt, shelter=shelter["name"] if shelter else "-"))
        alerts.append(dict(
            key=key, ward=ward, area=row.label, lat=float(row.lat), lon=float(row.lon), level=level, level_idx=lvl,
            probability=round(wp, 3), p_low=round(lo, 3), p_high=round(hi, 3), severity=SEVERITY[sev], severity_idx=sev,
            impact_in_min=None if t_impact is None else round(t_impact), people_at_risk=round(people),
            priority=round(prio, 1), reasons=reasons, audience=audience, status=status,
            citizens_status=(citizens if level == "High" else ("pending_confirmation" if level == "Critical" and status == "pending_confirmation"
                                                                else ("sent" if status == "confirmed_sent" else "n/a"))),
            decision=dict(action=dec["action"], officer=dec["officer"], note=dec["note"]) if dec else None,
            shelter=shelter, messages=messages,
            action=_recommended_action(level, t_impact)))
    alerts.sort(key=lambda a: (-a["level_idx"], -a["priority"]))
    return alerts


def _recommended_action(level, t_impact):
    if level == "Critical":
        return "Confirm and broadcast citizen alert; start evacuation of high-priority cells; deploy pumps/boats now."
    if level == "High":
        return "Pre-position pumps, boats and ambulances; prepare shelters; verify citizen reports."
    return "Monitor rainfall and river level; no public alert yet."
