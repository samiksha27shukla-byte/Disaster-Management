"""Loads the per-city data once: grid cells (static terrain + vulnerability), hourly weather series,
historic event ground truth, simulated emergency resources and the place gazetteer."""
import json
from functools import lru_cache

import numpy as np
import pandas as pd

from .config import CELL_KM2, CITY_ORDER, DATA, START
from .gazetteer import GAZETTEER

LAND_USE = {"Residential": 0, "Commercial": 1, "Industrial": 2, "OpenLand": 3, "Vegetation": 4, "Waterbody": 5}
STATIC_FROM_TRAINING = ["slope_deg", "relative_elevation", "flow_accumulation", "twi", "dist_to_river_m",
                        "dist_to_drain_m", "dist_to_coast_m", "drain_density", "vegetation_index"]
EVENT_FRAMES = 18


def _pr(a):
    return pd.Series(np.asarray(a, float)).rank(pct=True).values


class CityData:
    def __init__(self, name: str, meta: dict):
        self.name, self.meta = name, meta
        self.code, self.state = meta["code"], meta["state"]
        self.lat0, self.lon0 = meta["lat"], meta["lon"]
        self.tide_amp, self.coastal, self.river_tau = meta["tide_amp"], meta["coastal"], meta["river_tau"]
        self.events = {e["id"]: e for e in meta["events"]}

        tr = pd.read_csv(DATA / f"{name.lower()}_training.csv", parse_dates=["timestamp"])
        cells = pd.read_csv(DATA / f"{name.lower()}_cells.csv")
        n = len(cells)
        first = tr.iloc[:n]
        assert (first.cell_id.values == cells.cell_id.values).all(), "cell order mismatch"
        for col in STATIC_FROM_TRAINING:
            cells[col] = first[col].values
        cells["land_use_code"] = cells.land_use_class.map(LAND_USE)
        cells["rf"] = cells["HIDDEN_rain_spatial_factor"]            # stands in for a gridded rainfall product
        cells["x"] = (cells.lon - self.lon0) * 111320.0 * np.cos(np.radians(self.lat0))
        cells["y"] = (cells.lat - self.lat0) * 111320.0
        water = cells.land_use_class.eq("Waterbody").values
        cells["is_water"] = water
        cells["pop"] = np.where(water, 0.0, cells.population_density_per_km2 * CELL_KM2)   # people per cell
        v = (0.40 * _pr(cells.population_density_per_km2) + 0.25 * _pr(cells.slum_pct)
             + 0.15 * _pr(cells.elderly_pct + cells.children_pct) + 0.10 * _pr(cells.dist_to_nearest_hospital_m)
             + 0.10 * _pr(cells.critical_infra_count + cells.underpass_count))
        cells["vuln"] = np.where(water, 0.0, v)
        self.cells = cells
        self.n = n
        self.cell_index = {c: i for i, c in enumerate(cells.cell_id)}

        w = np.load(DATA / f"weather_{name.lower()}.npz")
        self.r1, self.sm, self.riv, self.tide = (w[k].astype(float) for k in ("r1", "sm", "riv", "tide"))

        # ground truth for the two historic events (frame 0..17 = the 18 labelled hours)
        self.truth_flood, self.truth_sev = {}, {}
        for eid, ev in self.events.items():
            sub = tr[tr.event_id == eid]
            hrs = ((sub.timestamp - pd.Timestamp(START)) / pd.Timedelta(hours=1)).round().astype(int).values
            fr, ci = hrs - ev["start_idx"], sub.cell_id.map(self.cell_index).values
            f, s = np.zeros((EVENT_FRAMES, n), int), np.zeros((EVENT_FRAMES, n), int)
            f[fr, ci], s[fr, ci] = sub.flooded.values, sub.severity.values
            self.truth_flood[eid], self.truth_sev[eid] = f, s

        # resources
        res = pd.read_csv(DATA / "resources_all_cities.csv")
        res = res[res.city == name].reset_index(drop=True)
        ci = [self.nearest_cell(la, lo)[0] for la, lo in zip(res.lat, res.lon)]
        res["cell"] = ci
        res["x"] = (res.lon - self.lon0) * 111320.0 * np.cos(np.radians(self.lat0))
        res["y"] = (res.lat - self.lat0) * 111320.0
        self.resources = res

        # gazetteer snapped to grid (keep only places that fall inside the modelled area)
        self.gaz = []
        for pname, (la, lo) in GAZETTEER[name].items():
            i, d = self.nearest_cell(la, lo)
            if d <= 900:
                self.gaz.append(dict(name=pname, lat=la, lon=lo, cell=i, dist_m=round(d)))

        # wards
        rows = []
        for ward, g in cells.groupby("ward", sort=True):
            la, lo = g.lat.mean(), g.lon.mean()
            lab = self._nearest_place(la, lo)
            rows.append(dict(ward=ward, lat=la, lon=lo, cells=g.index.tolist(),
                             label=f"{lab} area ({ward})" if lab else f"Zone {ward}"))
        self.wards = pd.DataFrame(rows).set_index("ward")

    # ---- geometry helpers ----
    def xy(self, lat, lon):
        return ((lon - self.lon0) * 111320.0 * np.cos(np.radians(self.lat0)), (lat - self.lat0) * 111320.0)

    def nearest_cell(self, lat, lon):
        x, y = self.xy(lat, lon)
        d = np.hypot(self.cells.x.values - x, self.cells.y.values - y)
        d = np.where(self.cells.is_water.values, d + 1e5, d) if "is_water" in self.cells else d
        i = int(np.argmin(d))
        return i, float(d[i])

    def _nearest_place(self, lat, lon):
        if not self.gaz:
            return None
        x, y = self.xy(lat, lon)
        best = min(self.gaz, key=lambda g: np.hypot(self.xy(g["lat"], g["lon"])[0] - x, self.xy(g["lat"], g["lon"])[1] - y))
        return best["name"]

    def place_of_cell(self, i):
        return self._nearest_place(self.cells.lat[i], self.cells.lon[i])

    @property
    def shelters(self):
        return self.resources[self.resources.type == "shelter"]

    def abs_to_ts(self, abs_hour: int) -> pd.Timestamp:
        return pd.Timestamp(START) + pd.Timedelta(hours=int(abs_hour))


@lru_cache(maxsize=1)
def load_all() -> dict:
    meta = json.loads((DATA / "cities.json").read_text())
    return {c: CityData(c, meta[c]) for c in CITY_ORDER if c in meta}


def get_city(name: str) -> CityData:
    cities = load_all()
    key = {k.lower(): k for k in cities}.get(name.lower())
    if key is None:
        raise KeyError(f"unknown city {name}")
    return cities[key]
