"""
Approximate neighbourhood coordinates, used to turn place names in social posts into map locations.

NOTE: coordinates are approximate (to ~3 decimals) and only used to snap to the nearest SYNTHETIC grid
cell. The flood risk shown at these names comes from synthetic data - the names are demo labels, not
statements about real flood behaviour. In production replace with OSM/Nominatim geocoding.
"""

GAZETTEER = {
    "Mumbai": {
        "Dharavi": (19.0430, 72.8553), "Sion": (19.0390, 72.8619), "Kurla": (19.0728, 72.8826),
        "Chembur": (19.0522, 72.9005), "Dadar": (19.0178, 72.8478), "Matunga": (19.0270, 72.8570),
        "Mahim": (19.0410, 72.8400), "Bandra": (19.0596, 72.8295), "BKC": (19.0680, 72.8700),
        "Vidyavihar": (19.0790, 72.8975),
    },
    "Chennai": {
        "T Nagar": (13.0418, 80.2341), "Mylapore": (13.0368, 80.2676), "Egmore": (13.0732, 80.2609),
        "Kodambakkam": (13.0521, 80.2255), "Nungambakkam": (13.0569, 80.2425),
        "Teynampet": (13.0450, 80.2500), "Vadapalani": (13.0500, 80.2121),
        "Anna Nagar": (13.0850, 80.2101), "Chetpet": (13.0721, 80.2411), "Kilpauk": (13.0836, 80.2417),
    },
    "Kochi": {
        "Kaloor": (9.9961, 76.3036), "Vyttila": (9.9672, 76.3189), "Palarivattom": (10.0000, 76.3100),
        "MG Road": (9.9816, 76.2864), "Kadavanthra": (9.9680, 76.3050),
        "Ernakulam South": (9.9697, 76.2886), "Elamkulam": (9.9600, 76.3050),
        "Kacheripady": (9.9860, 76.2840),
    },
    "Kolkata": {
        "Park Street": (22.5535, 88.3510), "Ballygunge": (22.5266, 88.3637),
        "Esplanade": (22.5646, 88.3510), "Bhowanipore": (22.5360, 88.3470), "Alipore": (22.5300, 88.3300),
        "Kalighat": (22.5200, 88.3430), "Entally": (22.5600, 88.3700), "Sealdah": (22.5650, 88.3700),
    },
    "Hyderabad": {
        "Punjagutta": (17.4260, 78.4510), "Banjara Hills": (17.4126, 78.4482),
        "Somajiguda": (17.4240, 78.4580), "Khairatabad": (17.4120, 78.4620), "Nampally": (17.3920, 78.4720),
        "Abids": (17.3900, 78.4760), "Mehdipatnam": (17.3950, 78.4400), "Lakdikapul": (17.4040, 78.4630),
        "Basheerbagh": (17.4000, 78.4750), "Himayatnagar": (17.4000, 78.4850),
    },
    "Guwahati": {
        "Paltan Bazaar": (26.1816, 91.7456), "Ganeshguri": (26.1470, 91.7870), "Dispur": (26.1433, 91.7898),
        "Bharalumukh": (26.1650, 91.7270), "Chandmari": (26.1700, 91.7550), "Ulubari": (26.1700, 91.7650),
    },
    "Nagpur": {
        "Sitabuldi": (21.1458, 79.0850), "Dharampeth": (21.1370, 79.0650), "Sadar": (21.1600, 79.0830),
        "Itwari": (21.1400, 79.1100), "Mahal": (21.1450, 79.1000), "Sakkardara": (21.1170, 79.1150),
        "Ramdaspeth": (21.1380, 79.0800), "Civil Lines": (21.1550, 79.0800),
    },
}

# Citizen-alert templates. Machine-written: have native speakers review before real use.
ALERT_TEXT = {
    "en": "FLOOD WARNING: {area}. Heavy flooding likely within about {h} hour(s). Move to higher ground or the nearest "
          "shelter ({shelter}). Avoid underpasses and low roads. Emergency: 112.",
    "hi": "बाढ़ चेतावनी: {area}। लगभग {h} घंटे में भारी जलभराव की आशंका। ऊँचे स्थान या नज़दीकी आश्रय ({shelter}) पर जाएँ। "
          "अंडरपास और निचली सड़कों से बचें। आपातकाल: 112।",
    "mr": "पूर चेतावणी: {area}. सुमारे {h} तासांत मोठे जलभराव होण्याची शक्यता. उंच जागी किंवा जवळच्या निवाऱ्यात ({shelter}) जा. "
          "अंडरपास आणि सखल रस्ते टाळा. आणीबाणी: 112.",
    "ta": "வெள்ள எச்சரிக்கை: {area}. சுமார் {h} மணி நேரத்தில் கடும் வெள்ளப்பெருக்கு ஏற்பட வாய்ப்பு. உயரமான இடத்திற்கு அல்லது அருகிலுள்ள "
          "நிவாரண முகாமுக்கு ({shelter}) செல்லுங்கள். சுரங்கப்பாதைகள், தாழ்வான சாலைகளைத் தவிர்க்கவும். அவசர உதவி: 112.",
    "ml": "വെള്ളപ്പൊക്ക മുന്നറിയിപ്പ്: {area}. ഏകദേശം {h} മണിക്കൂറിനുള്ളിൽ കനത്ത വെള്ളക്കെട്ടിന് സാധ്യത. ഉയർന്ന സ്ഥലത്തേക്കോ അടുത്തുള്ള "
          "ക്യാമ്പിലേക്കോ ({shelter}) മാറുക. അടിപ്പാതകളും താഴ്ന്ന റോഡുകളും ഒഴിവാക്കുക. അടിയന്തരം: 112.",
    "bn": "বন্যা সতর্কতা: {area}। প্রায় {h} ঘণ্টার মধ্যে ভারী জলাবদ্ধতার আশঙ্কা। উঁচু জায়গায় বা নিকটতম আশ্রয়ে ({shelter}) যান। "
          "আন্ডারপাস ও নিচু রাস্তা এড়িয়ে চলুন। জরুরি: 112।",
    "te": "వరద హెచ్చరిక: {area}. సుమారు {h} గంటల్లో భారీ వరద నీరు చేరే అవకాశం. ఎత్తైన ప్రదేశానికి లేదా సమీప ఆశ్రయానికి ({shelter}) వెళ్లండి. "
          "అండర్‌పాస్‌లు, లోతట్టు రోడ్లను నివారించండి. అత్యవసరం: 112.",
    "as": "বানপানীৰ সতৰ্কবাণী: {area}। প্ৰায় {h} ঘণ্টাৰ ভিতৰত গুৰুতৰ বানপানীৰ আশংকা। ওখ ঠাইলৈ বা ওচৰৰ আশ্ৰয়লৈ ({shelter}) যাওক। "
          "আণ্ডাৰপাছ আৰু নিম্ন অঞ্চল এৰাই চলক। জৰুৰীকালীন: 112।",
}
CITY_LANG = {"Mumbai": "mr", "Nagpur": "mr", "Chennai": "ta", "Kochi": "ml", "Kolkata": "bn",
             "Hyderabad": "te", "Guwahati": "as"}
LANG_NAME = {"en": "English", "hi": "हिन्दी", "mr": "मराठी", "ta": "தமிழ்", "ml": "മലയാളം", "bn": "বাংলা",
             "te": "తెలుగు", "as": "অসমীয়া"}
