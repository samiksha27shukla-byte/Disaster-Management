"""
Optional LIVE mode: pulls the real hourly rainfall (past 4 days + 3-day forecast) for the city centre from the free
Open-Meteo API and feeds it through the same model. Terrain, drainage and population stay SYNTHETIC, so this is a demo of
the live data path, not a real flood forecast. Needs internet; fails cleanly otherwise (the dashboard shows a message).
"""
import hashlib

import httpx
import numpy as np
import pandas as pd

from ..config import AXIS_LEN, LOOKBACK
from ..context import Context, _rollout
from ..data_service import CityData

URL = "https://api.open-meteo.com/v1/forecast"


def fetch_hourly(lat: float, lon: float, timeout: float = 8.0) -> dict:
    r = httpx.get(URL, params=dict(latitude=lat, longitude=lon, hourly="precipitation", past_days=4, forecast_days=4,
                                   timezone="auto"), timeout=timeout)
    r.raise_for_status()
    return r.json()


def live_context(cd: CityData, payload: dict | None = None) -> Context:
    js = payload or fetch_hourly(cd.lat0, cd.lon0)
    times = pd.to_datetime(js["hourly"]["time"])
    rain_all = np.nan_to_num(np.array(js["hourly"]["precipitation"], dtype=float))
    now_local = (pd.Timestamp.now("UTC").tz_localize(None) + pd.Timedelta(seconds=js.get("utc_offset_seconds", 0))).floor("h")
    idx = int(np.argmin(np.abs((times - now_local).total_seconds())))
    a0 = idx - LOOKBACK
    rain = np.zeros(AXIS_LEN)
    lo, hi = max(a0, 0), min(a0 + AXIS_LEN, len(rain_all))
    rain[lo - a0: hi - a0] = rain_all[lo:hi]
    sm, riv = np.full(AXIS_LEN, 0.15), np.zeros(AXIS_LEN)
    _rollout(cd, rain, sm, riv, 0)
    tide = np.zeros(AXIS_LEN)                       # no tide forecast in this demo
    key = "live-" + hashlib.md5(str(now_local).encode()).hexdigest()[:6]
    return Context(cd, "live", key, f"{cd.name} · LIVE rainfall (Open-Meteo)", times[idx], rain, sm, riv, tide,
                   params=dict(source="open-meteo", note="real rainfall, synthetic terrain; tide not included"))
