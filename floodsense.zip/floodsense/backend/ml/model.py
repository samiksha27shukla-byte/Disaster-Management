"""Inference wrapper around the LightGBM models: 5-model bagged ensemble for P(flood), a multiclass
severity model, and exact TreeSHAP contributions (LightGBM `pred_contrib`) for explanations."""
import json
from functools import lru_cache

import lightgbm as lgb
import numpy as np

from ..config import MODELS
from .features import FEATURES


class FloodModel:
    def __init__(self):
        self.meta = json.loads((MODELS / "model_meta.json").read_text())
        self.clf = [lgb.Booster(model_file=str(MODELS / f"flood_{k}.txt")) for k in range(self.meta["n_ensemble"])]
        self.sev = lgb.Booster(model_file=str(MODELS / "severity.txt"))

    def predict(self, X):
        """-> (mean probability, std across ensemble) for each row."""
        arr = X[FEATURES].to_numpy(float)
        ps = np.stack([m.predict(arr) for m in self.clf])
        return ps.mean(0), ps.std(0)

    def severity(self, X):
        """-> (rows, 4) class probabilities for severity 0..3."""
        return self.sev.predict(X[FEATURES].to_numpy(float))

    def contributions(self, X, n_models: int = 1):
        """Exact TreeSHAP contribution (log-odds) per feature from the first `n_models` ensemble members
        (the members are bagged copies of one model; 1 is enough for explanations and 5x faster). Last column = bias."""
        arr = X[FEATURES].to_numpy(float)
        return np.mean([m.predict(arr, pred_contrib=True) for m in self.clf[:n_models]], axis=0)


@lru_cache(maxsize=1)
def get_model() -> FloodModel:
    return FloodModel()


def model_available() -> bool:
    return (MODELS / "model_meta.json").exists()
