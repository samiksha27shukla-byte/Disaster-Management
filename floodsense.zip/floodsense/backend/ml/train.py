"""
Train the flood models.   python -m backend.ml.train

 * 5 bagged LightGBM classifiers  -> P(flood) with an ensemble spread
 * 1 LightGBM multiclass model    -> severity 0..3
Trained ONLY on rows before 2025-01-01, so the 2025 events are a true out-of-time test
(replay of the 2025 event is honest validation; the 2023 event is in-sample).
Then trains the NLP model and pre-computes replay metrics (see services/replay.py).
"""
import json
import time

import lightgbm as lgb
import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, precision_score, recall_score, roc_auc_score

from ..config import CITY_ORDER, DATA, MODELS, THRESH
from ..data_service import LAND_USE
from .features import FEATURES

CUTOFF = "2025-01-01"
N_ENSEMBLE = 5


def load_training() -> pd.DataFrame:
    dfs = [pd.read_csv(DATA / f"{c.lower()}_training.csv", parse_dates=["timestamp"]) for c in CITY_ORDER]
    df = pd.concat(dfs, ignore_index=True)
    df["land_use_code"] = df.land_use_class.map(LAND_USE)
    return df


def reliability(y, p, bins=8):
    edges = np.quantile(p, np.linspace(0, 1, bins + 1))
    out = []
    for lo, hi in zip(edges[:-1], edges[1:]):
        m = (p >= lo) & (p <= hi)
        if m.sum() > 30:
            out.append(dict(mean_pred=round(float(p[m].mean()), 3), observed=round(float(y[m].mean()), 3), n=int(m.sum())))
    return out


def train(verbose=True) -> dict:
    t0 = time.time()
    MODELS.mkdir(exist_ok=True)
    df = load_training()
    tr, te = df[df.timestamp < CUTOFF], df[df.timestamp >= CUTOFF]
    Xtr, Xte = tr[FEATURES].to_numpy(float), te[FEATURES].to_numpy(float)
    base = dict(objective="binary", learning_rate=0.06, num_leaves=31, min_data_in_leaf=40, feature_fraction=0.8,
                bagging_fraction=0.8, bagging_freq=1, lambda_l2=1.0, verbose=-1, num_threads=4)
    models = []
    for k in range(N_ENSEMBLE):
        m = lgb.train({**base, "seed": 100 + k}, lgb.Dataset(Xtr, tr.flooded.values, feature_name=FEATURES), 250)
        m.save_model(str(MODELS / f"flood_{k}.txt"))
        models.append(m)
    p = np.mean([m.predict(Xte) for m in models], axis=0)
    y = te.flooded.values
    thr = THRESH["high"]
    metrics = dict(
        n_train=int(len(tr)), n_test=int(len(te)), test_flood_rate=round(float(y.mean()), 4),
        auc=round(float(roc_auc_score(y, p)), 4), pr_auc=round(float(average_precision_score(y, p)), 4),
        precision_at_high=round(float(precision_score(y, p >= thr)), 3), recall_at_high=round(float(recall_score(y, p >= thr)), 3),
        reliability=reliability(y, p),
    )
    # severity (multiclass)
    sev = lgb.train(dict(objective="multiclass", num_class=4, learning_rate=0.06, num_leaves=31, min_data_in_leaf=40,
                         feature_fraction=0.8, bagging_fraction=0.8, bagging_freq=1, verbose=-1, num_threads=4, seed=7),
                    lgb.Dataset(Xtr, tr.severity.values, feature_name=FEATURES), 200)
    sev.save_model(str(MODELS / "severity.txt"))
    sp = sev.predict(Xte)
    fl = te.flooded.values == 1
    cond = sp[fl][:, 1:].argmax(1) + 1
    metrics["severity_accuracy_when_flooded"] = round(float((cond == te.severity.values[fl]).mean()), 3)
    metrics["severity_within_one_when_flooded"] = round(float((np.abs(cond - te.severity.values[fl]) <= 1).mean()), 3)
    imp = pd.Series(models[0].feature_importance("gain"), FEATURES)
    imp = (imp / imp.sum()).sort_values(ascending=False)
    meta = dict(n_ensemble=N_ENSEMBLE, trained_before=CUTOFF, features=FEATURES, metrics=metrics,
                feature_importance={k: round(float(v), 4) for k, v in imp.head(12).items()},
                thresholds=THRESH, trained_at=time.strftime("%Y-%m-%d %H:%M"))
    (MODELS / "model_meta.json").write_text(json.dumps(meta, indent=1))
    if verbose:
        print(f"flood+severity models trained in {time.time() - t0:.0f}s")
        print(json.dumps({k: v for k, v in metrics.items() if k != 'reliability'}, indent=1))
        print("top features:", list(meta["feature_importance"].items())[:6])
    return meta


if __name__ == "__main__":
    train()
