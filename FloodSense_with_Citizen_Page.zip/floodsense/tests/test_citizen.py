"""Citizen page: advisories only after the alert gate allows them; nothing internal leaks.

Run:  pytest -q tests/test_citizen.py      (needs the built models)
"""
import pytest
from fastapi.testclient import TestClient

import backend.db as dbmod
import backend.services.citizen as citizen_mod

EVENT = "MUM_EVT2"
WARD = "MUM-W18"          # an advisory ward at frame -12 in the demo replay
FRAME = -12
FORBIDDEN_KEYS = {"probability", "p_low", "p_high", "reasons", "decision", "officer", "audience",
                  "people_at_risk", "priority", "severity", "citizens_status", "level", "level_idx", "lead_min"}


@pytest.fixture(scope="module")
def client(tmp_path_factory):
    dbmod.DB_PATH = tmp_path_factory.mktemp("cdb") / "test.db"
    from backend.main import app
    with TestClient(app) as c:
        yield c


def citizen(client, **kw):
    body = {"city": "Mumbai", "mode": "replay", "event": EVENT, "frame": FRAME, **kw}
    r = client.post("/api/citizen", json=body)
    assert r.status_code == 200, r.text
    return r.json()


def keys_deep(o):
    if isinstance(o, dict):
        for k, v in o.items():
            yield k
            yield from keys_deep(v)
    elif isinstance(o, list):
        for v in o:
            yield from keys_deep(v)


def force_citizen_status(monkeypatch, status):
    """Keep the real alerts but override the gate status of the target ward, to test each branch."""
    real = citizen_mod.build_alerts

    def patched(risk, reports=None):
        alerts = real(risk, reports)
        for a in alerts:
            if a["ward"] == WARD:
                a["citizens_status"] = status
        return alerts

    monkeypatch.setattr(citizen_mod, "build_alerts", patched)


def test_ward_list_and_languages(client):
    m = citizen(client)
    assert len(m["wards"]) > 0
    assert {l["code"] for l in m["languages"]} >= {"en", "hi"}
    assert "advisory" not in m and "status" not in m


def test_public_view_has_no_internal_fields(client):
    d = citizen(client, ward=WARD)
    leaked = FORBIDDEN_KEYS & set(keys_deep(d))
    assert not leaked, f"internal fields leaked: {leaked}"
    assert d["ward"]["id"] == WARD and d["origin_cell"] and d["shelter"]


def test_advisory_shown_when_gate_allows(client):
    d = citizen(client, ward=WARD)
    assert d["status"] == "advisory"
    assert d["advisory"]["text"].startswith("FLOOD WARNING")
    assert "112" in d["advisory"]["text"]


@pytest.mark.parametrize("gate", ["pending_confirmation", "awaiting_verification", "dismissed", "n/a"])
def test_no_advisory_while_gate_closed(client, monkeypatch, gate):
    force_citizen_status(monkeypatch, gate)
    d = citizen(client, ward=WARD)
    assert d["status"] in ("monitoring", "no_advisory")
    assert d["advisory"] is None
    assert "FLOOD WARNING" not in str(d)


def test_advisory_shown_after_officer_confirms(client, monkeypatch):
    force_citizen_status(monkeypatch, "sent")
    d = citizen(client, ward=WARD)
    assert d["status"] == "advisory"


def test_language_choice_falls_back(client):
    d = citizen(client, ward=WARD, lang="xx")
    assert d["advisory"]["lang"] == "en"
    d_hi = citizen(client, ward=WARD, lang="hi")
    assert d_hi["advisory"]["lang"] == "hi"


def test_unknown_ward_is_404(client):
    r = client.post("/api/citizen", json={"city": "Mumbai", "mode": "replay", "event": EVENT, "frame": FRAME, "ward": "NOPE"})
    assert r.status_code == 404


def test_report_message_hides_scores():
    from backend.services.citizen import report_message
    for res in ({"status": "not_flood", "credibility": None}, {"status": "verified", "credibility": 88.0}):
        msg = report_message(res)
        assert "88" not in msg and "credib" not in msg.lower()


def test_citizen_page_served(client):
    r = client.get("/citizen.html")
    assert r.status_code == 200 and "Flood" in r.text
