"""
Time-aware evacuation routing.

Road network: one node per grid cell, 8-neighbour links (a stand-in for an OSMnx road graph - swap
`build_graph` for an OSM graph when online). Each edge gets a flood probability that CHANGES WITH TIME
(interpolated from the 24 h forecast), so a route is judged at the moment each edge would be reached:
  * edges whose probability >= 0.60 (0.35 for underpasses) at arrival time are impassable
  * wetter edges are slower; the 'safest' mode additionally penalises risk
  * every route comes with a validity window: how long until the path closes if you wait
"""
import heapq
import math

import numpy as np

from ..config import DX, HORIZON, THRESH
from .risk import Risk

BLOCK_P, BLOCK_P_UNDERPASS = THRESH["critical"], THRESH["high"]
SPEED_KMH = {"Commercial": 15, "Industrial": 20, "Residential": 20, "OpenLand": 28, "Vegetation": 28, "Waterbody": 20}
_GRAPHS = {}


def build_graph(cd):
    if cd.name in _GRAPHS:
        return _GRAPHS[cd.name]
    c = cd.cells
    gx = np.rint(c.x.values / DX + 9.5).astype(int)
    gy = np.rint(c.y.values / DX + 7).astype(int)
    pos = {(a, b): i for i, (a, b) in enumerate(zip(gx, gy))}
    ok = np.array([(not c.is_water[i]) or i % 2 == 0 for i in range(cd.n)])      # rivers crossable at 'bridges'
    adj = {i: [] for i in range(cd.n) if ok[i]}
    for i in adj:
        for da in (-1, 0, 1):
            for db in (-1, 0, 1):
                if da == 0 and db == 0:
                    continue
                j = pos.get((gx[i] + da, gy[i] + db))
                if j is not None and ok[j]:
                    adj[i].append((j, DX * (math.sqrt(2) if da and db else 1.0)))
    speed = np.array([SPEED_KMH[u] for u in c.land_use_class])
    G = dict(adj=adj, speed=speed, under=(c.underpass_count.values > 0),
             d={(u, v): dist for u, nb in adj.items() for v, dist in nb})
    _GRAPHS[cd.name] = G
    return G


def minute_grid(risk: Risk):
    """P interpolated to 5-minute steps: shape (24*12+1, n)."""
    H, n = risk.P.shape
    t = np.arange(0, (H - 1) * 60 + 1, 5) / 60.0
    lo = np.floor(t).astype(int).clip(0, H - 2)
    w = (t - lo)[:, None]
    return risk.P[lo] * (1 - w) + risk.P[lo + 1] * w


def _edge(G, Pm, u, v, d, t_min, origin=None):
    k = min(int(round(t_min / 5.0)), Pm.shape[0] - 1)
    # people already standing in the origin cell can leave it; every other edge is judged by both ends
    p = Pm[k, v] if u == origin else max(Pm[k, u], Pm[k, v])
    lim = BLOCK_P_UNDERPASS if (G["under"][u] or G["under"][v]) else BLOCK_P
    if p >= lim:
        return None, p
    spd = min(G["speed"][u], G["speed"][v]) * 1000 / 60.0              # m per minute
    return d / spd * (1 + 2.0 * max(0.0, p - 0.15)), p


def dijkstra(risk: Risk, origin: int, mode="safest", depart_min=0.0, Pm=None):
    cd = risk.ctx.cd
    G, Pm = build_graph(cd), (minute_grid(risk) if Pm is None else Pm)
    best = {origin: 0.0}
    tarr = {origin: float(depart_min)}
    prev = {}
    pq = [(0.0, origin)]
    while pq:
        cost, u = heapq.heappop(pq)
        if cost > best.get(u, 1e18):
            continue
        for v, d in G["adj"][u]:
            dt, p = _edge(G, Pm, u, v, d, tarr[u], origin)
            if dt is None:
                continue
            nc = cost + dt * (1 + 6.0 * p if mode == "safest" else 1.0)
            if nc < best.get(v, 1e18):
                best[v], tarr[v], prev[v] = nc, tarr[u] + dt, u
                heapq.heappush(pq, (nc, v))
    return tarr, prev


def _path(prev, origin, dest):
    if dest != origin and dest not in prev:
        return None
    p = [dest]
    while p[-1] != origin:
        p.append(prev[p[-1]])
    return p[::-1]


def _validity(risk, G, Pm, path, depart_min):
    """Minutes the route stays open if the journey starts later (path fixed)."""
    limit = HORIZON * 60
    d = 0
    while depart_min + d <= limit - 30:
        t = depart_min + d
        for u, v in zip(path[:-1], path[1:]):
            dt, _ = _edge(G, Pm, u, v, G["d"][(u, v)], t, path[0])
            if dt is None:
                return max(0, d - 10)
            t += dt
        d += 10
    return None            # stays open for the whole forecast window


def route_info(risk: Risk, origin: int, dest: int, mode="safest", depart_min=0.0, pre=None):
    cd = risk.ctx.cd
    G, Pm = build_graph(cd), minute_grid(risk)
    tarr, prev = pre if pre else dijkstra(risk, origin, mode, depart_min, Pm)
    path = _path(prev, origin, dest)
    if path is None:
        return None
    c = cd.cells
    eta = tarr[dest] - depart_min
    maxp = float(max([Pm[min(int(round(tarr.get(n, depart_min) / 5)), Pm.shape[0] - 1), n] for n in path[1:]] or [0.0]))
    return dict(mode=mode, path=path, coords=[[float(c.lat[i]), float(c.lon[i])] for i in path],
                eta_min=round(eta, 1), max_risk=round(maxp, 2),
                safe_window_min=_validity(risk, G, Pm, path, depart_min))


def evac_plan(risk: Risk, max_zones=8):
    """Where to move people, to which shelter, by which route and by when."""
    from .alerts import _nearest_safe_shelter                # noqa: F401  (shared safe-shelter logic lives with alerts)
    cd, c = risk.ctx.cd, risk.ctx.cd.cells
    G, Pm = build_graph(cd), minute_grid(risk)
    sh = cd.shelters.reset_index(drop=True)
    cap_left = {int(r.cell): int(r.capacity) for r in sh.itertuples()}
    sh_by_cell = {int(r.cell): r for r in sh.itertuples()}
    safe_cells = [int(r.cell) for r in sh.itertuples() if risk.p_peak[int(r.cell)] < THRESH["high"]]

    zones = []
    for ward, row in cd.wards.iterrows():
        idx = np.array([i for i in row.cells if not c.is_water[i] and risk.p_peak[i] >= THRESH["high"]])
        if len(idx) == 0:
            continue
        exposed = float(sum(risk.people_at_risk[i] for i in idx))
        people = float(sum(risk.people_at_risk[i] * (0.04 + 0.12 * risk.vuln[i]) for i in idx))   # share needing to move
        origin = int(idx[np.argmax(risk.priority[idx])])
        leads = [risk.lead_high_min[i] for i in idx if not np.isnan(risk.lead_high_min[i])]
        zones.append(dict(ward=ward, label=row.label, origin=origin, people=people, exposed=exposed, cells=idx.tolist(),
                          lead=float(min(leads)) if leads else None, prio=float(np.mean(risk.priority[idx]))))
    zones.sort(key=lambda z: -z["prio"])

    plan, used = [], {}
    for z in zones[:max_zones]:
        tarr, prev = dijkstra(risk, z["origin"], "safest", 0.0, Pm)
        options = sorted(((tarr[s] if s in tarr else 1e9, s) for s in safe_cells), key=lambda t: t[0])
        remaining, assignments = z["people"], []
        for eta, s in options:
            if remaining <= 1 or eta >= 1e9:
                break
            take = min(remaining, cap_left[s])
            if take <= 0:
                continue
            assignments.append((eta, s, take))
            cap_left[s] -= take
            used[s] = used.get(s, 0) + take
            remaining -= take
            if len(assignments) == 2:
                break
        if not assignments:
            reachable = [s for s in safe_cells if s in tarr and s != z["origin"]]
            isolated = not reachable
            plan.append(dict(ward=z["ward"], area=z["label"], people=round(z["people"]), exposed=round(z["exposed"]),
                             status="ISOLATED" if isolated else "SHELTERS FULL",
                             action="Cut off by floodwater: boat / rescue-team evacuation needed" if isolated
                             else "Shelters in reach are full: open overflow shelters",
                             lat=float(c.lat[z["origin"]]), lon=float(c.lon[z["origin"]])))
            continue
        eta, s, take = assignments[0]
        info = route_info(risk, z["origin"], s, "safest", 0.0, pre=(tarr, prev))
        fast = route_info(risk, z["origin"], s, "fastest", 0.0)
        r = sh_by_cell[s]
        # leave early enough to arrive before the zone reaches High risk (20 min buffer)
        depart_by = None if z["lead"] is None else max(0.0, z["lead"] - info["eta_min"] - 20)
        plan.append(dict(
            ward=z["ward"], area=z["label"], lat=float(c.lat[z["origin"]]), lon=float(c.lon[z["origin"]]),
            people=round(z["people"]), exposed=round(z["exposed"]), people_first_shelter=round(take),
            shelter=dict(id=r.resource_id, name=f"{cd.place_of_cell(s) or ''} shelter ({r.resource_id})".strip(),
                         capacity=int(r.capacity), lat=float(r.lat), lon=float(r.lon)),
            second_shelter=None if len(assignments) < 2 else dict(id=sh_by_cell[assignments[1][1]].resource_id, people=round(assignments[1][2])),
            route=info, fastest_route=fast,
            depart_by_min=None if depart_by is None else round(depart_by),
            action="DEPART NOW" if (depart_by is not None and depart_by <= 5) else
                   ("Prepare; depart within %d min" % depart_by if depart_by is not None else "Prepare and monitor"),
            status="ok" if info["safe_window_min"] is None or info["safe_window_min"] > 0 else "closing"))
    shelters_used = [dict(id=sh_by_cell[s].resource_id, used=int(u), capacity=int(sh_by_cell[s].capacity)) for s, u in used.items()]
    return dict(zones=plan, shelters_used=shelters_used, people_total=round(sum(z["people"] for z in zones)),
                exposed_total=round(sum(z["exposed"] for z in zones)),
                shelter_capacity_total=int(sum(cap_left.values()) + sum(used.values())))
