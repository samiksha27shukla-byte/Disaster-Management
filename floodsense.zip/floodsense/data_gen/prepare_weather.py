#!/usr/bin/env python3
"""
Re-runs the weather part of the synthetic generator with the SAME seeds, so the backend has the full
hourly series (rain, soil moisture, river level, tide) for every city, and saves:

    data/weather_<city>.npz   hourly arrays + event start indices
    data/cities.json          city metadata (centre, state, tide amplitude, events)

It then verifies that the saved series reproduces the rainfall columns in the training CSVs.
Run from the project root:   python data_gen/prepare_weather.py
"""
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.argv = [sys.argv[0], str(ROOT / "data")]          # generator reads argv[1] as output dir
import generate_flood_data as g                         # noqa: E402

DATA = ROOT / "data"


def main():
    meta = {}
    for ci, (name, cfg) in enumerate(g.CITIES.items()):
        rng = np.random.default_rng(g.SEED + ci)
        c, hosp, shel = g.build_cells(cfg["code"], name, cfg, rng)      # advances the RNG identically
        S, ev_starts = g.gen_weather(rng, cfg)
        np.savez_compressed(
            DATA / f"weather_{name.lower()}.npz",
            r1=S["r1"].astype("float32"), sm=S["sm"].astype("float32"),
            riv=S["riv"].astype("float32"), tide=S["tide"].astype("float32"),
            ev_starts=np.array(ev_starts, dtype=int))
        meta[name] = dict(
            code=cfg["code"], state=cfg["state"], lat=cfg["lat"], lon=cfg["lon"],
            tide_amp=cfg["tide_amp"], coastal=bool(cfg["tide_amp"]), river_tau=cfg["river_tau"],
            events=[dict(id=f"{cfg['code']}_EVT{i + 1}", date=e[0], total_mm_24h=e[1], surge_m=e[2],
                         start_idx=int(ev_starts[i])) for i, e in enumerate(cfg["events"])],
            start=g.START)

        # --- consistency check against the training CSV (event hours) ---
        tr = pd.read_csv(DATA / f"{name.lower()}_training.csv", parse_dates=["timestamp"])
        cells = pd.read_csv(DATA / f"{name.lower()}_cells.csv")
        rf = cells.set_index("cell_id")["HIDDEN_rain_spatial_factor"]
        sub = tr[tr.event_id == f"{cfg['code']}_EVT2"]
        hrs = ((sub.timestamp - pd.Timestamp(g.START)) / pd.Timedelta(hours=1)).round().astype(int).values
        rebuilt = S["r1"][hrs] * rf.loc[sub.cell_id].values
        err = np.abs(rebuilt - sub.rain_1h.values).max()
        assert err < 0.12, f"{name}: series mismatch vs training CSV (max err {err})"
        print(f"{name:10s} ok   events at hour idx {ev_starts}   max rain_1h err {err:.3f}")
    (DATA / "cities.json").write_text(json.dumps(meta, indent=1))
    print("saved weather_*.npz and cities.json")


if __name__ == "__main__":
    main()
