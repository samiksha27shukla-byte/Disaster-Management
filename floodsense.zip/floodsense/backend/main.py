"""
FloodSense API (FastAPI).  Run:  uvicorn backend.main:app --port 8000   then open http://localhost:8000

Every analytical endpoint takes the same "context request": (city, mode, event, frame, scenario) where
  mode = replay    a historic event at a chosen frame (-12..+17 h around the 18 labelled hours)
  mode = scenario  what-if rainfall typed by the user
  mode = live      real rainfall from Open-Meteo (needs internet)
"""
import json
import math
import threading
from contextlib import asynccontextmanager

import numpy as np
import pandas as pd
from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from . import db
from .config import FRONTEND, HORIZON, LEVELS, MODELS, SEVERITY, THRESH, city_level_index, level_index
from .context import SCENARIO_DEFAULTS, Context, replay_context, scenario_context
from .data_service import EVENT_FRAMES, CityData, get_city, load_all
from .ml.features import FEATURES, REASON_TEXT
from .ml.model import get_model, model_available
from .services import replay as replay_svc
from .services import social
from .services.alerts import build_alerts
from .services.live_weather import fetch_hourly, live_context
from .services.optimizer import plan_resources
from .services.overview import load_overview
from .services.risk import cell_series, compute_risk, reasons_for
from .services.routing import dijkstra, evac_plan, route_info

@asynccontextmanager
async def lifespan(_app):
    db.init_db()
    if not model_available():
        from .ml.bootstrap import build_all
        build_all()

    def warm():
        try:
            build_state(replay_context(get_city("Mumbai"), "MUM_EVT2", 7))
        except Exception as e:                                                     # never block startup
            print("warm-up skipped:", e)
    threading.Thread(target=warm, daemon=True).start()
    yield


app = FastAPI(title="FloodSense", version="1.0", lifespan=lifespan)


# ----------------------------------------------------------------------------------------------- helpers
def clean(o):
    if isinstance(o, dict):
        return {str(k): clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [clean(v) for v in o]
    if isinstance(o, np.ndarray):
        return clean(o.tolist())
    if isinstance(o, (float, np.floating)):
        return None if (math.isnan(o) or math.isinf(o)) else float(o)
    if isinstance(o, np.integer):
        return int(o)
    if isinstance(o, (bool, np.bool_)):
        return bool(o)
    if isinstance(o, pd.Timestamp):
        return o.strftime("%Y-%m-%d %H:%M")
    return o


def ok(payload):
    return JSONResponse(clean(payload))


class CtxReq(BaseModel):
    city: str = "Mumbai"
    mode: str = "replay"
    event: str | None = None
    frame: int = 7
    scenario: dict | None = None


class CellReq(CtxReq):
    cell_id: str


class RouteReq(CtxReq):
    origin_cell: str
    shelter_id: str | None = None


class ReportReq(CtxReq):
    text: str
    lat: float | None = None
    lon: float | None = None
    has_image: bool = False


class DecisionReq(BaseModel):
    city: str
    ctx_key: str
    ward: str
    level: str
    action: str            # confirm | dismiss
    officer: str = "control-room"
    note: str = ""


def city_or_404(name: str) -> CityData:
    try:
        return get_city(name)
    except KeyError:
        raise HTTPException(404, f"unknown city '{name}'")


def make_context(req: CtxReq) -> Context:
    cd = city_or_404(req.city)
    if req.mode == "replay":
        ev = req.event or sorted(cd.events)[-1]
        if ev not in cd.events:
            raise HTTPException(404, f"unknown event '{ev}' for {cd.name}: {list(cd.events)}")
        return replay_context(cd, ev, int(np.clip(req.frame, -12, EVENT_FRAMES - 1)))
    if req.mode == "scenario":
        return scenario_context(cd, req.scenario)
    if req.mode == "live":
        try:
            return live_context(cd)
        except Exception as e:                                           # no internet, API down, ...
            raise HTTPException(503, f"Live weather unavailable ({type(e).__name__}). Use replay or scenario mode offline.")
    raise HTTPException(400, "mode must be replay, scenario or live")


# ----------------------------------------------------------------------------------------------- state
def build_state(ctx: Context) -> dict:
    cd, c = ctx.cd, ctx.cd.cells
    risk = compute_risk(ctx)
    reports = social.visible_reports(ctx)
    alerts = build_alerts(risk, reports)
    evac = evac_plan(risk)
    plan = plan_resources(risk, alerts, evac)
    land = ~c.is_water.values
    n = cd.n
    lv_peak = np.array([level_index(p) for p in risk.p_peak])
    lv_now = np.array([level_index(p) for p in risk.p_now])

    truth_f = truth_s = None
    if ctx.mode == "replay" and ctx.frame is not None and ctx.frame >= 0:
        truth_f, truth_s = cd.truth_flood[ctx.event][ctx.frame], cd.truth_sev[ctx.event][ctx.frame]

    idx = np.arange(n)
    h_pk = risk.h_peak
    cells = [dict(
        i=int(i), id=c.cell_id[i], lat=float(c.lat[i]), lon=float(c.lon[i]), ward=c.ward[i], water=bool(c.is_water[i]),
        p_now=round(float(risk.p_now[i]), 3), p_peak=round(float(risk.p_peak[i]), 3),
        p_lo=round(float(risk.lo[h_pk[i], i]), 3), p_hi=round(float(risk.hi[h_pk[i], i]), 3),
        h_peak=int(h_pk[i]), lead_high=None if np.isnan(risk.lead_high_min[i]) else round(float(risk.lead_high_min[i])),
        lead_crit=None if np.isnan(risk.lead_crit_min[i]) else round(float(risk.lead_crit_min[i])),
        lvl_now=int(lv_now[i]), lvl=int(lv_peak[i]), sev=int(risk.sev[i]), vuln=round(float(risk.vuln[i]), 2),
        prio=round(float(risk.priority[i]), 1), pop=int(c["pop"][i]), elev=round(float(c.elevation_m[i]), 1),
        land_use=c.land_use_class[i],
        truth=None if truth_f is None else int(truth_f[i]), truth_sev=None if truth_s is None else int(truth_s[i]),
    ) for i in idx]

    assigned = {a["resource_id"] for a in plan["assignments"]}
    resources = [dict(id=r.resource_id, type=r.type, lat=float(r.lat), lon=float(r.lon), capacity=int(r.capacity),
                      unit=r.capacity_unit, status=r.status, ward=r.ward, assigned=r.resource_id in assigned)
                 for r in cd.resources.itertuples()]

    L = ctx.L
    lead = [a["impact_in_min"] for a in alerts if a["level_idx"] >= 2 and a["impact_in_min"] is not None]
    top_ward = alerts[0] if alerts else None
    exposed = risk.people_at_risk[risk.p_peak >= THRESH["high"]].sum()
    summary = dict(
        overall_level=LEVELS[city_level_index(lv_peak[land])], level_counts_peak={LEVELS[k]: int((lv_peak[land] == k).sum()) for k in range(4)},
        level_counts_now={LEVELS[k]: int((lv_now[land] == k).sum()) for k in range(4)},
        mean_p_now=round(float(risk.p_now[land].mean()), 3), mean_p_peak=round(float(risk.p_peak[land].mean()), 3),
        people_at_risk=int(exposed), critical_wards=int(sum(a["level"] == "Critical" for a in alerts)),
        high_wards=int(sum(a["level"] == "High" for a in alerts)), pending_confirmations=int(sum(a["status"] == "pending_confirmation" for a in alerts)),
        next_impact_min=min(lead) if lead else None, top_alert=top_ward["area"] if top_ward else None,
        rain=dict(now_mm_h=round(float(ctx.rain[L]), 1), last3h=round(float(ctx.rain[L - 2:L + 1].sum()), 1),
                  last24h=round(float(ctx.rain[L - 23:L + 1].sum()), 1), next6h=round(float(ctx.rain[L + 1:L + 7].sum()), 1),
                  next24h=round(float(ctx.rain[L + 1:L + 25].sum()), 1)),
        soil_moisture=round(float(ctx.sm[L]), 2), river_level=round(float(ctx.riv[L]), 2),
        tide_m=round(float(ctx.tide[L]), 2) if cd.coastal else None,
        verified_reports=int(sum(1 for r in reports if r["status"] == "verified")), reports_total=len(reports),
    )
    if truth_f is not None:
        summary["truth"] = dict(flooded_share=round(float(truth_f[land].mean()), 3),
                                predicted_share_now=round(float(risk.p_now[land].mean()), 3))
    reports_sorted = sorted(reports, key=lambda r: (r["frame"] if r["frame"] is not None else 0, r.get("minute", 0)), reverse=True)[:80]
    series_hours = list(range(-24, 25))
    return dict(
        context=dict(city=cd.name, state=cd.state, mode=ctx.mode, key=ctx.key, label=ctx.label, now=str(ctx.now_ts)[:16], event=ctx.event,
                     frame=ctx.frame, params=ctx.params, frame_range=[-12, EVENT_FRAMES - 1], coastal=cd.coastal,
                     lat=cd.lat0, lon=cd.lon0, event_date=cd.events[ctx.event]["date"] if ctx.event else None,
                     events=[dict(id=k, date=v["date"], total=v["total_mm_24h"]) for k, v in cd.events.items()]),
        summary=summary, cells=cells, traj=np.round(risk.P[:13], 2), alerts=alerts, evac=evac, plan=plan, resources=resources,
        reports=reports_sorted,
        series=dict(hours=series_hours, rain=np.round(ctx.rain[L - 24:L + 25], 1), tide=np.round(ctx.tide[L - 24:L + 25], 2) if cd.coastal else None,
                    river=np.round(ctx.riv[L - 24:L + 25], 3), city_p=np.round([float(risk.P[h][land].mean()) for h in range(HORIZON + 1)], 3)),
        wards={w: dict(label=r.label, lat=float(r.lat), lon=float(r.lon)) for w, r in cd.wards.iterrows()},
    )


@app.post("/api/state")
def api_state(req: CtxReq):
    return ok(build_state(make_context(req)))


@app.post("/api/cell")
def api_cell(req: CellReq):
    ctx = make_context(req)
    cd = ctx.cd
    if req.cell_id not in cd.cell_index:
        raise HTTPException(404, "unknown cell")
    i = cd.cell_index[req.cell_id]
    risk = compute_risk(ctx)
    c = cd.cells
    rs = reasons_for(risk, [i], top=5)[i]
    X = risk.X.iloc[int(risk.h_peak[i]) * cd.n + i]
    snap = {f: (None if pd.isna(X[f]) else round(float(X[f]), 2)) for f in FEATURES}
    nearby = [r for r in social.visible_reports(ctx) if r.get("cell") is not None and r["status"] != "not_flood"
              and math.hypot(c.x[r["cell"]] - c.x[i], c.y[r["cell"]] - c.y[i]) <= 1200]
    sev_p = get_model().severity(risk.X.iloc[[int(risk.h_peak[i]) * cd.n + i]])[0]
    truth = None
    if ctx.mode == "replay":
        truth = dict(frames=list(range(EVENT_FRAMES)), flooded=cd.truth_flood[ctx.event][:, i], current_frame=ctx.frame)
    return ok(dict(
        cell=dict(id=req.cell_id, ward=c.ward[i], area=cd.wards.loc[c.ward[i], "label"], lat=float(c.lat[i]), lon=float(c.lon[i]), land_use=c.land_use_class[i],
                  elevation_m=float(c.elevation_m[i]), imperviousness_pct=float(c.imperviousness_pct[i])),
        series=cell_series(risk, i), peak=dict(p=float(risk.p_peak[i]), hour=int(risk.h_peak[i]), level=LEVELS[level_index(risk.p_peak[i])],
                                               severity=SEVERITY[int(risk.sev[i])], severity_probs=sev_p.tolist(),
                                               lead_high_min=risk.lead_high_min[i], lead_crit_min=risk.lead_crit_min[i]),
        reasons=rs, features=snap,
        vulnerability=dict(index=float(risk.vuln[i]), priority=float(risk.priority[i]), people_in_cell=int(c["pop"][i]),
                           people_at_risk=float(risk.people_at_risk[i]), population_density_per_km2=float(c.population_density_per_km2[i]),
                           slum_pct=float(c.slum_pct[i]), elderly_pct=float(c.elderly_pct[i]), children_pct=float(c.children_pct[i]),
                           hospital_dist_m=float(c.dist_to_nearest_hospital_m[i]), shelter_dist_m=float(c.dist_to_nearest_shelter_m[i]),
                           underpasses=int(c.underpass_count[i]), critical_infra=int(c.critical_infra_count[i]),
                           known_flood_spot=bool(c.is_known_flood_spot[i]), past_floods_5y=int(c.past_flood_count_5y[i])),
        truth=truth, reports=nearby[:8]))


@app.post("/api/route")
def api_route(req: RouteReq):
    ctx = make_context(req)
    cd = ctx.cd
    if req.origin_cell not in cd.cell_index:
        raise HTTPException(404, "unknown origin cell")
    o = cd.cell_index[req.origin_cell]
    risk = compute_risk(ctx)
    sh = cd.shelters
    if req.shelter_id:
        sh = sh[sh.resource_id == req.shelter_id]
        if sh.empty:
            raise HTTPException(404, "unknown shelter")
    pre_safe, pre_fast = dijkstra(risk, o, "safest"), dijkstra(risk, o, "fastest")
    out = []
    for r in sh.itertuples():
        d = int(r.cell)
        if d not in pre_safe[0] and d != o:
            continue
        safe = route_info(risk, o, d, "safest", 0.0, pre=pre_safe)
        fast = route_info(risk, o, d, "fastest", 0.0, pre=pre_fast)
        if safe is None:
            continue
        out.append(dict(shelter=dict(id=r.resource_id, name=f"{cd.place_of_cell(d) or ''} shelter ({r.resource_id})".strip(), capacity=int(r.capacity),
                                     lat=float(r.lat), lon=float(r.lon), p_peak=float(risk.p_peak[d]), safe=bool(risk.p_peak[d] < THRESH["high"])),
                        safest=safe, fastest=fast))
    out.sort(key=lambda r: (not r["shelter"]["safe"], r["safest"]["eta_min"]))
    return ok(dict(origin=req.origin_cell, routes=out[:3], note="Route validity = how long the path stays open if you wait."))


@app.post("/api/report")
def api_report(req: ReportReq):
    ctx = make_context(req)
    risk = compute_risk(ctx)
    if not req.text.strip():
        raise HTTPException(400, "empty report")
    return ok(social.submit_report(ctx, risk, req.text.strip(), req.lat, req.lon, req.has_image))


@app.post("/api/alert/decision")
def api_decision(d: DecisionReq):
    if d.action not in ("confirm", "dismiss"):
        raise HTTPException(400, "action must be confirm or dismiss")
    db.save_decision(d.city, d.ctx_key, d.ward, d.level, d.action, d.officer, d.note)
    return ok(dict(saved=True))


@app.post("/api/reset-demo")
def api_reset():
    db.reset()
    return ok(dict(reset=True))


# ----------------------------------------------------------------------------------------------- reference data
@app.get("/api/meta")
def api_meta():
    meta = json.loads((MODELS / "model_meta.json").read_text())
    nlp = json.loads((MODELS / "nlp_meta.json").read_text()) if (MODELS / "nlp_meta.json").exists() else {}
    ver = json.loads((MODELS / "verification_eval.json").read_text()) if (MODELS / "verification_eval.json").exists() else {}
    cities = {k: dict(state=v.state, lat=v.lat0, lon=v.lon0, coastal=v.coastal, n_cells=v.n,
                      events=[dict(id=e["id"], date=e["date"], total=e["total_mm_24h"]) for e in v.events.values()]) for k, v in load_all().items()}
    return ok(dict(synthetic_data=True, disclaimer="All data is synthetic. Area names are demo labels, not real flood statements.",
                   thresholds=THRESH, levels=LEVELS, scenario_defaults=SCENARIO_DEFAULTS, cities=cities,
                   model=dict(trained_before=meta["trained_before"], metrics={k: v for k, v in meta["metrics"].items() if k != "reliability"},
                              reliability=meta["metrics"].get("reliability"), feature_importance=meta["feature_importance"], n_ensemble=meta["n_ensemble"],
                              reason_features=list(REASON_TEXT)),
                   nlp=nlp, verification=ver))


@app.get("/api/india")
def api_india():
    return ok(load_overview())


@app.get("/api/history/{city}")
def api_history(city: str):
    cd = city_or_404(city)
    m = replay_svc.load_metrics().get(cd.name)
    if not m:
        raise HTTPException(404, "metrics not built yet (run python -m backend.ml.bootstrap)")
    return ok(dict(city=cd.name, events=list(m.values())))


@app.get("/api/compare")
def api_compare():
    m = replay_svc.load_metrics()
    rows = []
    for city, evs in m.items():
        for e in evs.values():
            rows.append(dict(city=city, state=get_city(city).state, **{k: v for k, v in e.items() if k not in ("flood_share_truth", "flood_share_pred")}))
    return ok(dict(rows=rows))


@app.get("/api/live/{city}")
def api_live(city: str):
    cd = city_or_404(city)
    try:
        js = fetch_hourly(cd.lat0, cd.lon0)
    except Exception as e:
        raise HTTPException(503, f"Live weather unavailable ({type(e).__name__}). This needs internet access.")
    return ok(dict(city=cd.name, hours=js["hourly"]["time"][-120:], precipitation=js["hourly"]["precipitation"][-120:]))


@app.get("/api/health")
def api_health():
    return ok(dict(status="ok", model=model_available()))


app.mount("/", StaticFiles(directory=str(FRONTEND), html=True), name="frontend")
