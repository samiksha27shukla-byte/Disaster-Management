#!/usr/bin/env bash
# One-command start (macOS / Linux).  Creates a virtualenv, installs, builds models if missing, serves on :8000
set -e
cd "$(dirname "$0")"
[ -d .venv ] || python3 -m venv .venv
source .venv/bin/activate
pip install -q -r requirements.txt
python -m backend.ml.bootstrap          # skips anything already built
echo "Open http://localhost:8000"
exec uvicorn backend.main:app --host 0.0.0.0 --port 8000
