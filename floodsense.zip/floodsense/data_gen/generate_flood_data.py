#!/usr/bin/env python3
"""
Synthetic urban-flood dataset generator for Indian cities (Hackathon PS-14).

*** ALL DATA IS SYNTHETIC. Replace with real data (ERA5/IMD rain, DEM, OSM) before claiming results. ***

Design (what makes it more realistic than a random table):
  * Fixed 500 m grid per city (same cells at every time step -> replay / per-cell trends work)
  * Terrain derived from a smooth surface + water-body distance; slope, relative elevation,
    D8 flow accumulation and TWI are COMPUTED from that surface (not drawn independently)
  * Hourly rainfall with city-specific monsoon climatology, bursty storms, 2 injected heavy events
  * Soil moisture / river level are simulated from antecedent rainfall; tide for coastal cities
  * Flood label = terrain x rainfall x drainage capacity x soil x river x tide (hidden capacity + noise)
  * Rare floods overall; heavy events flood mostly low / impervious / poorly drained cells

Usage:  python generate_flood_data.py [output_dir]
"""
import os
import sys
import numpy as np
import pandas as pd

OUT = sys.argv[1] if len(sys.argv) > 1 else "flood_sample_data"
SEED = 2026
NX, NY, DX = 20, 15, 500.0            # 300 cells of 500 m  -> ~10 km x 7.5 km urban core
START, END = "2021-01-01", "2026-09-30"
N_EVENT_HRS, N_BG_RANDOM, N_BG_WET = 18, 16, 28

# ----------------------------------------------------------------------------------------------
# City configuration. Coordinates in metres relative to the city centre (x east, y north).
# Monthly climatology (mm) is APPROXIMATE, from general knowledge - replace with IMD/ERA5 values.
# drain_cap is an ASSUMED design capacity (mm/h), not an official figure.
# ----------------------------------------------------------------------------------------------
CITIES = {
    "Mumbai": dict(
        code="MUM", state="Maharashtra", lat=19.05, lon=72.87,
        coast=dict(base=-4200, amp=400, per=2000, land="east"),
        rivers=[[(1500, 3500), (800, 2000), (0, 800), (-1000, 0), (-2500, -800)]],
        lakes=[], hills=[(-500, 3200, 1100, 45), (3500, -3000, 900, 25)],
        elev=(1.0, 18.0), L=2500, pop_core=32000, slum=0.40, drain_cap=25, tide_amp=2.0,
        tide_align=True, river_tau=12, industrial=[(3500, 1800, 1300)], target=0.30,
        clim=[0.5, 0.5, 0.5, 1, 15, 520, 840, 585, 340, 90, 15, 3],
        events=[("2023-07-27", 240, 0.2), ("2025-07-20", 340, 0.4)]),
    "Chennai": dict(
        code="CHE", state="Tamil Nadu", lat=13.06, lon=80.24,
        coast=dict(base=4200, amp=300, per=2500, land="west"),
        rivers=[[(-5000, -1500), (-2000, -1000), (1000, -1600), (3500, -1800)],
                [(-5000, 1200), (-2000, 1500), (500, 600), (3200, 900)]],
        lakes=[], hills=[], elev=(2.0, 18.0), L=2500, pop_core=27000, slum=0.22,
        drain_cap=28, tide_amp=0.45, tide_align=False, river_tau=36,
        industrial=[(-3500, 3000, 1400)], target=0.30,
        clim=[25, 10, 8, 15, 50, 50, 90, 120, 120, 270, 350, 140],
        events=[("2023-12-04", 300, 0.3), ("2025-12-01", 380, 0.6)]),
    "Kochi": dict(
        code="KOC", state="Kerala", lat=9.99, lon=76.30,
        coast=dict(base=-3500, amp=600, per=1200, land="east"),
        rivers=[[(-2500, -3000), (-1500, 0), (-2000, 3000)],
                [(-1000, 3500), (1500, 2800), (4500, 3200)]],
        lakes=[], hills=[(4000, -2000, 900, 12)], elev=(0.6, 10.0), L=2500,
        pop_core=9000, slum=0.08, drain_cap=25, tide_amp=0.4, tide_align=False,
        river_tau=60, industrial=[(2500, -2500, 1300)], target=0.30,
        clim=[10, 15, 30, 120, 300, 750, 650, 400, 250, 300, 180, 40],
        events=[("2023-07-25", 230, 0.1), ("2025-08-08", 300, 0.2)]),
    "Kolkata": dict(
        code="KOL", state="West Bengal", lat=22.55, lon=88.35,
        coast=None,
        rivers=[[(-4200, -3500), (-3800, 0), (-4300, 3500)],
                [(-3000, -3000), (0, -2200), (3500, -1800)]],
        lakes=[], hills=[], elev=(1.5, 8.0), L=3000, pop_core=28000, slum=0.30,
        drain_cap=20, tide_amp=None, tide_align=False, river_tau=72,
        industrial=[(-1500, -2500, 1300)], target=0.25,
        clim=[10, 25, 30, 50, 130, 300, 380, 350, 300, 150, 20, 5],
        events=[("2023-09-14", 190, 0), ("2025-09-21", 260, 0)]),
    "Hyderabad": dict(
        code="HYD", state="Telangana", lat=17.40, lon=78.47,
        coast=None,
        rivers=[[(-5000, -500), (-2000, -300), (500, -800), (3000, -1300), (5000, -1500)]],
        lakes=[(1200, 1800, 600)], hills=[(2500, 2500, 900, 25), (-3000, -2000, 1000, 20)],
        elev=(500.0, 25.0), L=2500, pop_core=18000, slum=0.20, drain_cap=22,
        tide_amp=None, tide_align=False, river_tau=24,
        industrial=[(-3800, 2500, 1400)], target=0.20,
        clim=[5, 10, 15, 20, 30, 110, 160, 160, 160, 90, 15, 5],
        events=[("2023-09-10", 130, 0), ("2025-09-26", 190, 0)]),
    "Guwahati": dict(
        code="GUW", state="Assam", lat=26.15, lon=91.74,
        coast=None,
        rivers=[[(-5000, 3300), (0, 3000), (5000, 3500)],
                [(-1500, -2000), (0, 0), (500, 2500)]],
        lakes=[(-4000, -3000, 1000)], hills=[(-2000, -2500, 1500, 90), (3000, -3000, 1200, 70)],
        elev=(50.0, 35.0), L=2500, pop_core=6000, slum=0.15, drain_cap=20,
        tide_amp=None, tide_align=False, river_tau=120,
        industrial=[(3500, -500, 1000)], target=0.22,
        clim=[10, 20, 60, 140, 250, 350, 350, 280, 250, 130, 15, 5],
        events=[("2023-06-20", 170, 0), ("2025-06-14", 230, 0)]),
    "Nagpur": dict(
        code="NAG", state="Maharashtra", lat=21.14, lon=79.09,
        coast=None,
        rivers=[[(-3000, -3500), (-500, -1000), (500, 500), (3000, 2000)],
                [(-4000, 1500), (-1000, 1800), (1500, 3000)]],
        lakes=[], hills=[(3000, 3000, 1200, 15)], elev=(290.0, 30.0), L=2500,
        pop_core=11000, slum=0.18, drain_cap=22, tide_amp=None, tide_align=False,
        river_tau=24, industrial=[(-3500, -2500, 1400)], target=0.18,
        clim=[15, 15, 10, 10, 25, 190, 300, 270, 190, 60, 15, 10],
        events=[("2023-09-23", 130, 0), ("2025-08-20", 200, 0)]),
}


# ----------------------------------------------------------------------------------------------
# helpers
# ----------------------------------------------------------------------------------------------
def sigmoid(v):
    return 1.0 / (1.0 + np.exp(-v))


def zscore(a):
    return (a - a.mean()) / (a.std() + 1e-9)


def smooth_noise(rng, ny, nx, sigma):
    f = rng.standard_normal((ny, nx))
    ky = np.fft.fftfreq(ny)[:, None]
    kx = np.fft.fftfreq(nx)[None, :]
    g = np.exp(-2 * (np.pi * sigma) ** 2 * (kx ** 2 + ky ** 2))
    s = np.real(np.fft.ifft2(np.fft.fft2(f) * g))
    return (s - s.mean()) / (s.std() + 1e-9)


def dist_polyline(px, py, pts):
    d = np.full(px.shape, np.inf)
    for (x1, y1), (x2, y2) in zip(pts[:-1], pts[1:]):
        vx, vy = x2 - x1, y2 - y1
        t = np.clip(((px - x1) * vx + (py - y1) * vy) / (vx * vx + vy * vy), 0, 1)
        d = np.minimum(d, np.hypot(px - (x1 + t * vx), py - (y1 + t * vy)))
    return d


def flow_accumulation(elev):
    ny, nx = elev.shape
    acc = np.ones_like(elev)
    for idx in np.argsort(-elev, axis=None):
        j, i = divmod(idx, nx)
        best, bd = None, 0.0
        for dj in (-1, 0, 1):
            for di in (-1, 0, 1):
                if dj == 0 and di == 0:
                    continue
                jj, ii = j + dj, i + di
                if 0 <= jj < ny and 0 <= ii < nx:
                    dz = (elev[j, i] - elev[jj, ii]) / (1.414 if (dj and di) else 1.0)
                    if dz > bd:
                        bd, best = dz, (jj, ii)
        if best is not None:
            acc[best] += acc[j, i]
    return acc


def trailing(H, w):
    c = np.concatenate([[0.0], np.cumsum(H)])
    idx = np.arange(len(H))
    return c[idx + 1] - c[np.maximum(0, idx - w + 1)]


def leading(H, w):
    c = np.concatenate([[0.0], np.cumsum(H)])
    idx = np.arange(len(H))
    return c[np.minimum(len(H), idx + 1 + w)] - c[idx + 1]


# ----------------------------------------------------------------------------------------------
# static cell attributes
# ----------------------------------------------------------------------------------------------
def build_cells(code, name, cfg, rng):
    ii, jj = np.meshgrid(np.arange(NX), np.arange(NY))
    x = (ii - (NX - 1) / 2) * DX
    y = (jj - (NY - 1) / 2) * DX

    coast = cfg["coast"]
    if coast:
        cx = coast["base"] + coast["amp"] * np.sin(y / coast["per"])
        signed = (x - cx) if coast["land"] == "east" else (cx - x)
        land = signed > 150
        dcoast = np.maximum(signed, 0)
    else:
        land, dcoast = np.ones_like(x, bool), None

    dr = np.full(x.shape, np.inf)
    for r in cfg["rivers"]:
        dr = np.minimum(dr, dist_polyline(x, y, r))
    for lx, ly, lr in cfg["lakes"]:
        dr = np.minimum(dr, np.maximum(0, np.hypot(x - lx, y - ly) - lr))
    dw = dr if dcoast is None else np.minimum(dr, dcoast)

    e0, span = cfg["elev"]
    n1 = smooth_noise(rng, NY, NX, 2.5)
    n01 = (n1 - n1.min()) / (n1.max() - n1.min())
    elev = e0 + span * (0.6 * (1 - np.exp(-dw / cfg["L"])) + 0.4 * n01)
    hillf = np.zeros_like(x)
    for hx, hy, hr, hh in cfg["hills"]:
        g = np.exp(-((x - hx) ** 2 + (y - hy) ** 2) / (2 * (hr / 1.5) ** 2))
        elev += hh * g
        hillf += g
    hillf = np.clip(hillf, 0, 1)
    elev -= 0.05 * span * np.exp(-dr / 200)
    elev += rng.normal(0, 0.02 * span + 0.05, elev.shape)
    elev = np.maximum(elev, 0.5 * e0 if e0 > 1 else 0.3)

    gy, gx = np.gradient(elev, DX)
    slope = np.degrees(np.arctan(np.hypot(gx, gy)))
    pad = np.pad(elev, 2, mode="edge")
    nb = sum(pad[2 + dj:2 + dj + NY, 2 + di:2 + di + NX]
             for dj in range(-2, 3) for di in range(-2, 3)) / 25.0
    rel = elev - nb
    acc = flow_accumulation(elev)
    twi = np.log((acc * DX + 1) / np.tan(np.radians(np.maximum(slope, 0.3))))

    dc = np.hypot(x / 6000, y / 4500)
    imperv = 0.95 - 0.6 * dc + 0.10 * smooth_noise(rng, NY, NX, 1.5) + rng.normal(0, 0.05, x.shape)
    imperv = np.clip(imperv * (1 - 0.85 * hillf), 0, 1)
    water = dr < 150
    imperv[water] = rng.uniform(0, 0.04, water.sum())
    ind = np.zeros(x.shape, bool)
    for ix, iy, ir in cfg["industrial"]:
        ind |= (np.hypot(x - ix, y - iy) < ir) & (imperv > 0.3) & ~water
    imperv = np.where(ind, np.maximum(imperv, 0.7), imperv)
    lu = np.full(x.shape, "Residential", dtype=object)
    lu[imperv < 0.45] = "OpenLand"
    lu[imperv < 0.15] = "Vegetation"
    lu[(imperv > 0.85) & (dc < 0.35)] = "Commercial"
    lu[ind] = "Industrial"
    lu[water] = "Waterbody"
    ndvi = np.clip(0.75 - 0.7 * imperv + rng.normal(0, 0.08, x.shape), -0.1, 0.92)
    ndvi[water] = rng.uniform(-0.08, 0.02, water.sum())

    ward_no = (jj // 3) * 5 + ii // 4 + 1
    wq = {w: rng.uniform(0.2, 0.9) for w in np.unique(ward_no)}   # hidden ward drainage quality
    wardq = np.vectorize(wq.get)(ward_no)

    m = land.ravel()
    c = {k: v.ravel()[m] for k, v in dict(
        x=x, y=y, elev=elev, slope=slope, rel=rel, acc=acc, twi=twi, dr=dr, imperv=imperv,
        lu=lu, ndvi=ndvi, water=water, dc=dc, ward_no=ward_no, wardq=wardq).items()}
    c["dcoast"] = dcoast.ravel()[m] if dcoast is not None else np.full(m.sum(), 1e6)
    n = int(m.sum())
    lat0, lon0 = cfg["lat"], cfg["lon"]
    c["lat"] = lat0 + c["y"] / 111320.0
    c["lon"] = lon0 + c["x"] / (111320.0 * np.cos(np.radians(lat0)))
    c["ward"] = np.array([f"{code}-W{w:02d}" for w in c["ward_no"]])
    c["cell_id"] = np.array([f"{code}_{k + 1:04d}" for k in range(n)])

    c["drain_density"] = np.clip(0.5 + 9 * c["imperv"] + rng.normal(0, 0.6, n), 0.1, 12)
    c["dist_drain"] = np.clip(
        (60 + 700 * (1 - c["imperv"]) ** 1.5) * rng.lognormal(0, 0.35, n), 15, 2500)
    c["cap"] = (cfg["drain_cap"] * (0.7 + 0.6 * c["wardq"])
                * (0.85 + 0.3 * np.clip(c["drain_density"] / 9, 0, 1.2)))     # hidden, mm/h
    c["rf"] = 1 + 0.10 * smooth_noise(rng, NY, NX, 3).ravel()[m]             # hidden rain factor

    zt = (-0.35 * zscore(c["rel"]) - 0.25 * zscore(c["elev"]) + 0.30 * zscore(c["twi"])
          + 0.25 * zscore(np.log(c["acc"])) - 0.15 * zscore(c["slope"]))
    c["zt"] = zscore(zt)
    lowf = np.clip(1 - (c["elev"] - c["elev"].min()) / (0.45 * (c["elev"].max() - c["elev"].min()) + 1e-6), 0, 1)
    c["lowf"] = lowf
    susc = c["zt"] + 0.4 * zscore(c["imperv"]) - 0.4 * zscore(c["cap"]) + rng.normal(0, 0.3, n)
    pct = pd.Series(susc).rank(pct=True).values
    c["pct"] = pct
    c["known"] = (pct > 0.96).astype(int)
    c["past"] = rng.poisson(0.05 + 2.2 * pct ** 4)
    c["water_flag"] = c["water"]

    # ---- vulnerability layer ----
    dcn = c["dc"]
    pop = cfg["pop_core"] * np.exp(-1.3 * dcn) * (0.3 + 0.7 * c["imperv"]) * rng.lognormal(0, 0.35, n)
    pop[c["water"]] = 0
    c["pop"] = pop
    c["slum_pct"] = np.clip(cfg["slum"] * 100 * (0.4 + 0.6 * sigmoid(c["zt"])) * (0.5 + c["imperv"])
                            * rng.lognormal(0, 0.4, n), 0, 90)
    c["elderly"] = np.clip(rng.normal(9, 2.5, n), 2, 20)
    c["children"] = np.clip(rng.normal(22, 4, n), 8, 35)
    c["underpass"] = np.minimum(rng.poisson(0.5 * c["imperv"] ** 2 * (dcn < 0.8)), 3)
    c["infra"] = rng.poisson(0.2 + 1.2 * c["imperv"])

    landcells = np.where(~c["water"])[0]
    w_h = 0.2 + c["imperv"][landcells]
    hosp = rng.choice(landcells, 18, replace=False, p=w_h / w_h.sum())
    w_s = (1 - c["pct"][landcells]) * (c["imperv"][landcells] > 0.3) + 0.02
    shel = rng.choice(landcells, 24, replace=False, p=w_s / w_s.sum())

    def nearest(idx):
        d = np.hypot(c["x"][:, None] - c["x"][idx][None, :], c["y"][:, None] - c["y"][idx][None, :])
        return d.min(axis=1) + 100

    c["hosp_count"] = np.bincount(hosp, minlength=n)
    c["d_hosp"] = nearest(hosp)
    c["d_shelter"] = nearest(shel)
    return c, hosp, shel


# ----------------------------------------------------------------------------------------------
# hourly weather / hydrology
# ----------------------------------------------------------------------------------------------
def gen_weather(rng, cfg):
    days = pd.date_range(START, END, freq="D")
    hours = pd.date_range(START, END + " 23:00", freq="h")
    nd = len(days)
    M = np.array(cfg["clim"], float)
    month = days.month.values - 1
    dim = np.array([31, 28.25, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31])
    mwd = np.clip(12 + 0.06 * M, 8, 70)
    p_base = np.clip(M / (30 * mwd), 0, 0.85)

    amt, prev = np.zeros(nd), False
    for k in range(nd):
        m = month[k]
        p = min(p_base[m] * (1.5 if prev else 0.75), 0.95)
        prev = rng.random() < p
        if prev:
            amt[k] = rng.gamma(0.9, mwd[m] / 0.9)
    for m in range(12):
        sel = month == m
        raw = amt[sel].mean() * dim[m]
        amt[sel] *= (M[m] / raw) if raw > 0 else 0
    yrs = days.year.values
    for y in np.unique(yrs):
        for m in range(12):
            sel = (yrs == y) & (month == m)
            amt[sel] *= rng.lognormal(0, 0.18)
    amt = np.minimum(amt, 450)

    H = np.zeros(nd * 24)
    for k in np.where(amt > 0.2)[0]:
        a = amt[k]
        D = int(np.clip(round(3 + 11 * np.exp(-a / 200) + rng.integers(-1, 3)), 2, 16))
        s = rng.integers(0, 24 - D + 1)
        H[k * 24 + s:k * 24 + s + D] += a * rng.dirichlet(np.full(D, 1.3))
    H = np.minimum(H, 90.0)          # no physically implausible >90 mm/h background spikes

    ev_windows, ev_peaks, surges = [], [], []
    for date, total, surge in cfg["events"]:
        k = (pd.Timestamp(date) - days[0]).days
        H[(k - 2) * 24:(k + 2) * 24] = 0
        for dk, lo, hi in ((-2, 25, 45), (-1, 40, 80)):
            s = k + dk
            H[s * 24 + 10:s * 24 + 18] += rng.uniform(lo, hi) * rng.dirichlet(np.full(8, 2.0))
        t = np.arange(24)
        prof = (np.exp(-0.5 * ((t - 7) / 3.2) ** 2) + 0.06) * rng.lognormal(0, 0.25, 24)
        H[k * 24 + 6:k * 24 + 30] += total * prof / prof.sum()
        H[(k + 1) * 24 + 6:(k + 1) * 24 + 12] += rng.uniform(20, 50) * rng.dirichlet(np.full(6, 2.0))
        ev_windows.append(k * 24 + 6)
        ev_peaks.append(k * 24 + 13)
        surges.append(surge)

    n = len(H)
    S = dict(hours=hours, r1=H, r3=trailing(H, 3), r6=trailing(H, 6), r24=trailing(H, 24),
             r72=trailing(H, 72))
    S["f6"] = leading(H, 6) * rng.lognormal(-0.02, 0.35, n) * np.where(rng.random(n) < 0.05, 0.3, 1)
    S["f24"] = leading(H, 24) * rng.lognormal(-0.02, 0.30, n) * np.where(rng.random(n) < 0.05, 0.3, 1)

    sm, riv = np.zeros(n), np.zeros(n)
    s_, r_ = 0.15, 0.0
    tau_r = cfg["river_tau"]
    for t in range(n):
        s_ = min(1.0, s_ * np.exp(-1 / 180) + H[t] / 120)
        r_ = r_ * np.exp(-1 / tau_r) + H[t] / 120
        sm[t], riv[t] = max(s_, 0.08), 1 - np.exp(-r_)
    S["sm"], S["riv"] = sm, riv

    if cfg["tide_amp"]:
        h = np.arange(n)
        phase = (-2 * np.pi * ev_peaks[-1] / 12.42) if cfg["tide_align"] else rng.uniform(0, 2 * np.pi)
        tide = cfg["tide_amp"] * np.cos(2 * np.pi * h / 12.42 + phase) * (1 + 0.3 * np.cos(2 * np.pi * h / (14.77 * 24)))
        for pk, sg in zip(ev_peaks, surges):
            tide += sg * np.exp(-0.5 * ((h - pk) / 6.0) ** 2)
        S["tide"] = tide
    else:
        S["tide"] = np.zeros(n)
    return S, ev_windows


# ----------------------------------------------------------------------------------------------
# flood label model
# ----------------------------------------------------------------------------------------------
def cell_matrices(S, c, hidx, rng=None):
    rf = c["rf"][None, :]
    m = {k: S[k][hidx][:, None] * rf for k in ("r1", "r3", "r6", "r24", "r72", "f6", "f24")}
    sm = S["sm"][hidx][:, None] * (1.15 - 0.35 * c["imperv"][None, :])
    if rng is not None:
        sm = sm + rng.normal(0, 0.02, sm.shape)
    m["sm"] = np.clip(sm, 0.02, 1.0)
    m["riv"] = S["riv"][hidx][:, None] * np.ones((1, len(c["elev"])))
    m["tide"] = S["tide"][hidx][:, None] * np.ones((1, len(c["elev"])))
    return m


def logit_base(m, c, cfg):
    imf = 0.4 + 0.6 * c["imperv"][None, :]
    if cfg["tide_amp"]:
        tb = np.clip(np.maximum(m["tide"], 0) / (cfg["tide_amp"] + 0.5), 0, 1.3) * \
            (np.exp(-c["dcoast"] / 3000) * c["lowf"])[None, :]
    else:
        tb = 0.0
    cap = c["cap"][None, :] * (1 - 0.5 * tb)
    excess = np.maximum(0, 0.5 * m["r1"] + 0.5 * m["r3"] / 3 - cap)
    lg = (0.075 * excess * imf * (1 + 0.35 * np.clip(c["zt"], -1.5, 2.5)[None, :])
          + 0.004 * np.maximum(0, m["r24"] - 90) * imf
          + 1.3 * (m["sm"] - 0.5)
          + 0.90 * c["zt"][None, :]
          + 3.5 * m["riv"] ** 1.5 * (np.exp(-c["dr"] / 600) * c["lowf"])[None, :]
          + 1.3 * tb * np.tanh(excess / 8)
          + (0.7 * c["known"] + 0.12 * c["past"])[None, :])
    # gate: with little recent rain there is essentially no pluvial flooding, whatever the terrain
    lg = lg - 8.0 * np.exp(-(m["r24"] + 0.3 * m["r72"]) / 25.0)
    return np.where(c["water"][None, :], -12.0, lg)


def calibrate(S, c, cfg, ev_hours):
    """Choose the intercept so that ~cfg['target'] of cells are flooded, on average, during the
    heavy-event windows. Background flood frequency then follows from the physics."""
    base = logit_base(cell_matrices(S, c, np.array(ev_hours)), c, cfg)
    lo, hi = -30.0, 5.0
    for _ in range(40):
        mid = (lo + hi) / 2
        if sigmoid(base + mid).mean() > cfg["target"]:
            hi = mid
        else:
            lo = mid
    return (lo + hi) / 2


# ----------------------------------------------------------------------------------------------
# main
# ----------------------------------------------------------------------------------------------
def main():
    os.makedirs(OUT, exist_ok=True)
    resources, overview = [], []
    for ci, (name, cfg) in enumerate(CITIES.items()):
        rng = np.random.default_rng(SEED + ci)
        code = cfg["code"]
        c, hosp, shel = build_cells(code, name, cfg, rng)
        n = len(c["elev"])
        S, ev_starts = gen_weather(rng, cfg)
        T = len(S["r1"])

        ev_hours, ev_lab = [], {}
        for e, st in enumerate(ev_starts):
            for h in range(st, st + N_EVENT_HRS):
                ev_hours.append(h)
                ev_lab[h] = f"{code}_EVT{e + 1}"
        icpt = calibrate(S, c, cfg, ev_hours)
        pool = np.array([h for h in range(72, T - 30) if h not in ev_lab])
        rand_sel = rng.choice(pool, N_BG_RANDOM, replace=False)
        wet_pool = pool[S["r6"][pool] > 8]
        wet_sel = rng.choice(wet_pool, N_BG_WET, replace=False)
        sel = np.array(sorted(set(ev_hours) | set(rand_sel.tolist()) | set(wet_sel.tolist())))

        m = cell_matrices(S, c, sel, rng)
        lg = logit_base(m, c, cfg) + icpt
        Lat = lg + rng.logistic(size=lg.shape)
        flooded = (Lat > 0).astype(int)
        severity = np.where(Lat <= 0, 0, np.where(Lat < 1.5, 1, np.where(Lat < 3.5, 2, 3)))

        Tn = len(sel)
        rep = lambda a: np.tile(a, Tn)
        coastal = bool(cfg["tide_amp"])
        df = pd.DataFrame({
            "cell_id": rep(c["cell_id"]),
            "lat": rep(c["lat"].round(6)), "lon": rep(c["lon"].round(6)),
            "ward": rep(c["ward"]), "city": name, "state": cfg["state"],
            "timestamp": np.repeat(S["hours"][sel].strftime("%Y-%m-%d %H:%M:%S"), n),
            "event_id": np.repeat([ev_lab.get(h, "none") for h in sel], n),
            "elevation_m": rep(c["elev"].round(2)), "slope_deg": rep(c["slope"].round(2)),
            "relative_elevation": rep(c["rel"].round(2)),
            "flow_accumulation": rep(c["acc"].astype(int)), "twi": rep(c["twi"].round(2)),
            "dist_to_river_m": rep(np.minimum(c["dr"], 99999).round(0)),
            "dist_to_drain_m": rep(c["dist_drain"].round(0)),
            "dist_to_coast_m": rep(c["dcoast"].round(0)) if coastal else np.nan,
            "drain_density": rep(c["drain_density"].round(2)),
            "land_use_class": rep(c["lu"]),
            "imperviousness_pct": rep((c["imperv"] * 100).round(1)),
            "vegetation_index": rep(c["ndvi"].round(3)),
            "rain_1h": m["r1"].ravel().round(1), "rain_3h": m["r3"].ravel().round(1),
            "rain_6h": m["r6"].ravel().round(1), "rain_24h": m["r24"].ravel().round(1),
            "rain_72h": m["r72"].ravel().round(1),
            "forecast_rain_next_6h": m["f6"].ravel().round(1),
            "forecast_rain_next_24h": m["f24"].ravel().round(1),
            "river_level_index": m["riv"].ravel().round(3),
            "tide_level_m": m["tide"].ravel().round(2) if coastal else np.nan,
            "soil_moisture": m["sm"].ravel().round(3),
            "past_flood_count_5y": rep(c["past"]), "is_known_flood_spot": rep(c["known"]),
            "flooded": flooded.ravel(), "severity": severity.ravel(),
        })
        df.to_csv(f"{OUT}/{name.lower()}_training.csv", index=False)

        cells = pd.DataFrame({
            "cell_id": c["cell_id"], "lat": c["lat"].round(6), "lon": c["lon"].round(6),
            "ward": c["ward"], "city": name, "state": cfg["state"],
            "elevation_m": c["elev"].round(2), "land_use_class": c["lu"],
            "imperviousness_pct": (c["imperv"] * 100).round(1),
            "population_density_per_km2": c["pop"].round(0),
            "elderly_pct": c["elderly"].round(1), "children_pct": c["children"].round(1),
            "slum_pct": c["slum_pct"].round(1), "hospital_count": c["hosp_count"],
            "dist_to_nearest_hospital_m": c["d_hosp"].round(0),
            "dist_to_nearest_shelter_m": c["d_shelter"].round(0),
            "underpass_count": c["underpass"], "critical_infra_count": c["infra"],
            "is_known_flood_spot": c["known"], "past_flood_count_5y": c["past"],
            "HIDDEN_assumed_drain_capacity_mm_hr": c["cap"].round(1),
            "HIDDEN_rain_spatial_factor": c["rf"].round(3),
        })
        cells.to_csv(f"{OUT}/{name.lower()}_cells.csv", index=False)

        # ---- simulated emergency resources ----
        def pick(k, w):
            w = np.asarray(w, float)
            return rng.choice(len(w), k, replace=False, p=w / w.sum())
        land_i = np.where(~c["water"])[0]

        def add(kind, idxs, lo, hi, unit, tag):
            for q, i in enumerate(idxs):
                resources.append(dict(
                    resource_id=f"{code}-{tag}{q + 1:02d}", city=name, type=kind,
                    lat=round(c["lat"][i] + rng.normal(0, 0.0008), 6),
                    lon=round(c["lon"][i] + rng.normal(0, 0.0008), 6),
                    capacity=int(rng.integers(lo, hi + 1)), capacity_unit=unit,
                    status=rng.choice(["available", "deployed"], p=[0.85, 0.15]),
                    ward=c["ward"][i]))
        add("pump", land_i[pick(28, 0.3 + c["pct"][land_i])], 300, 2000, "m3_per_hour", "PMP")
        add("boat", land_i[pick(8, c["pct"][land_i] ** 2 + 0.05)], 8, 20, "persons", "BOT")
        add("ambulance", rng.choice(hosp, 16), 1, 3, "patients", "AMB")
        add("rescue_team", land_i[pick(8, c["pop"][land_i] + 1)], 6, 12, "members", "RSC")
        add("shelter", shel, 100, 800, "persons", "SHL")
        add("hospital", hosp, 40, 900, "beds", "HSP")

        ev_mask = df["event_id"] != "none"
        overview.append(dict(
            city=name, state=cfg["state"], lat=cfg["lat"], lon=cfg["lon"], n_cells=n,
            area_km2=round(n * DX * DX / 1e6, 1), n_rows=len(df),
            flood_rate_all=round(df.flooded.mean(), 4),
            flood_rate_event_rows=round(df.loc[ev_mask, "flooded"].mean(), 4),
            flood_rate_background_rows=round(df.loc[~ev_mask, "flooded"].mean(), 4),
            annual_rain_mm_assumed=int(sum(cfg["clim"])),
            event_totals_mm_24h=" / ".join(str(e[1]) for e in cfg["events"]),
            coastal=coastal))
        print(f"{name:10s} cells={n:3d} rows={len(df):6d} flood_rate={df.flooded.mean():.3f} "
              f"event={df.loc[ev_mask,'flooded'].mean():.3f} bg={df.loc[~ev_mask,'flooded'].mean():.3f}")

    pd.DataFrame(resources).to_csv(f"{OUT}/resources_all_cities.csv", index=False)
    pd.DataFrame(overview).to_csv(f"{OUT}/city_overview.csv", index=False)


if __name__ == "__main__":
    main()
