/* FloodSense dashboard - vanilla JS + Leaflet + Chart.js. No build step. */
'use strict';
const LEVELS = ['Low', 'Moderate', 'High', 'Critical'];
const LCOL = ['#2e9e5b', '#e3b505', '#f08a24', '#d62839'];
const SEV = ['None', 'Low', 'Medium', 'High'];
const TYPE_LABEL = {pump: 'Pump', boat: 'Boat', ambulance: 'Ambulance', rescue_team: 'Rescue team', shelter: 'Shelter', hospital: 'Hospital'};
const TYPE_LETTER = {pump: 'P', boat: 'B', ambulance: 'A', rescue_team: 'R', shelter: 'S', hospital: 'H'};
const STATUS_CHIP = {
  watch: ['Watching', 'st'], sent_to_field_teams: ['Sent to field teams', 'good'], pending_confirmation: ['Awaiting officer confirmation', 'bad'],
  confirmed_sent: ['Confirmed · citizens alerted', 'good'], dismissed: ['Dismissed by officer', 'st']};
const CIT_TEXT = {awaiting_verification: 'Citizens: waiting for verified reports', advisory_ready: 'Citizens: advisory ready', advisory_sent: 'Citizens: advisory sent',
  pending_confirmation: 'Citizens: after confirmation', sent: 'Citizens: alerted', 'n/a': ''};

const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;'}[c]));
const fmtMin = m => m == null ? '—' : m <= 0 ? 'now' : m < 60 ? `${Math.round(m)} min` : `${(m / 60).toFixed(1)} h`;
const fmtN = n => n == null ? '—' : Number(n).toLocaleString('en-IN');
const pct = p => p == null ? '—' : `${Math.round(p * 100)}%`;
const lvl = p => p >= 0.6 ? 3 : p >= 0.35 ? 2 : p >= 0.15 ? 1 : 0;
const chip = (i, txt) => `<span class="chip L${i}">${esc(txt ?? LEVELS[i])}</span>`;

const S = {city: 'Mumbai', mode: 'replay', event: null, frame: 7, scenario: {}, meta: null, data: null, viewH: 0, layer: 'prob',
  selected: null, selRoutes: null, playing: false, req: 0, histCache: {}, openMsg: {}, lang: {}, lastReport: null, sel: null};

// ------------------------------------------------------------------------------------------------ api
async function api(path, body) {
  const r = await fetch(path, body === undefined ? {} : {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body)});
  if (!r.ok) {
    let m = r.statusText;
    try { m = (await r.json()).detail || m; } catch (e) { /* ignore */ }
    throw new Error(m);
  }
  return r.json();
}
const ctxBody = () => ({city: S.city, mode: S.mode, event: S.event, frame: S.frame, scenario: S.scenario});
function toast(msg, kind) {
  const t = $('#toast'); t.textContent = msg; t.className = 'toast' + (kind === 'info' ? ' info' : ''); clearTimeout(toast._t);
  toast._t = setTimeout(() => t.classList.add('hidden'), 5200);
}
function busy(on, txt) { $('#loading').classList.toggle('hidden', !on); if (txt) $('#loadTxt').textContent = txt; }

// ------------------------------------------------------------------------------------------------ map
let map, rects = {}, cellsKey = '', selRect = null;
const L_ = {};
function initMap() {
  map = L.map('map', {preferCanvas: true, zoomSnap: 0.25}).setView([19.05, 72.87], 12);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {maxZoom: 19, attribution: '© OpenStreetMap contributors'}).addTo(map);
  ['cells', 'routes', 'assign', 'shel', 'res', 'rep', 'warn', 'sel'].forEach(k => { L_[k] = L.layerGroup().addTo(map); });
  map.createPane('top'); map.getPane('top').style.zIndex = 650;
}
function cellBounds(c) {
  const dlat = 250 / 111320, dlon = 250 / (111320 * Math.cos(c.lat * Math.PI / 180));
  return [[c.lat - dlat, c.lon - dlon], [c.lat + dlat, c.lon + dlon]];
}
function lerpColor(stops, t) {
  t = Math.max(0, Math.min(1, t)) * (stops.length - 1); const i = Math.min(stops.length - 2, Math.floor(t)), f = t - i;
  const a = stops[i].match(/\w\w/g).map(h => parseInt(h, 16)), b = stops[i + 1].match(/\w\w/g).map(h => parseInt(h, 16));
  return '#' + a.map((v, k) => Math.round(v + (b[k] - v) * f).toString(16).padStart(2, '0')).join('');
}
function cellStyle(c, d) {
  if (c.water) return {fillColor: '#4a6fa5', fillOpacity: 0.55, color: '#0b1522', weight: 0.4};
  let col = '#555', op = 0.5;
  const lay = S.layer;
  if (lay === 'prob') { const p = d.traj[S.viewH][c.i]; col = LCOL[lvl(p)]; op = 0.22 + 0.55 * Math.min(1, p / 0.8); }
  else if (lay === 'sev') { col = ['#2e9e5b', '#e3b505', '#f08a24', '#d62839'][c.sev]; op = c.sev === 0 ? 0.15 : 0.35 + 0.18 * c.sev; }
  else if (lay === 'prio') { col = lerpColor(['1c3b5a', '7b2cbf', 'ff2e63'], c.prio / 90); op = 0.3 + 0.5 * Math.min(1, c.prio / 70); }
  else if (lay === 'vuln') { col = lerpColor(['1d3b2f', 'e9c46a', 'e76f51'], c.vuln); op = 0.55; }
  else if (lay === 'truth') {
    if (c.truth == null) { col = '#6b7a8d'; op = 0.25; } else { col = c.truth ? LCOL[Math.max(1, c.truth_sev) ] : '#2e9e5b'; op = c.truth ? 0.7 : 0.18; }
  }
  return {fillColor: col, fillOpacity: op, color: '#0b1522', weight: 0.4};
}
function ensureRects(d) {
  const key = d.context.city;
  if (cellsKey === key) return;
  L_.cells.clearLayers(); rects = {}; cellsKey = key;
  d.cells.forEach(c => {
    const r = L.rectangle(cellBounds(c), {weight: 0.4, fillOpacity: 0.4}).addTo(L_.cells);
    r.on('click', () => selectCell(c.id)); rects[c.id] = r;
    r.bindTooltip('', {sticky: true});
  });
  const b = L.latLngBounds(d.cells.map(c => [c.lat, c.lon])); map.fitBounds(b.pad(0.06));
}
function updateMap(d) {
  ensureRects(d);
  d.cells.forEach(c => {
    const r = rects[c.id]; r.setStyle(cellStyle(c, d));
    const pv = d.traj[S.viewH][c.i];
    r.setTooltipContent(c.water ? `${c.id}: water body` : `<b>${esc(c.id)}</b> · ${esc(c.land_use)}<br>P(flood) at +${S.viewH}h: <b>${pct(pv)}</b> (${LEVELS[lvl(pv)]})` +
      `<br>peak ${pct(c.p_peak)} in +${c.h_peak}h · priority ${c.prio}` + (c.truth != null ? `<br>actual now: ${c.truth ? 'FLOODED' : 'dry'}` : ''));
  });
  drawWarnings(d); drawResources(d); drawReports(d); drawEvacRoutes(d); drawAssign(d); drawSelection();
  drawLegend(d); applyToggles();
}
function drawLegend(d) {
  const row = (c, t) => `<div class="row"><span class="sw" style="background:${c}"></span>${t}</div>`;
  const L = S.layer; let h = '';
  if (L === 'prob') h = `<b>P(flood) at +${S.viewH} h</b>` + [0, 1, 2, 3].map(i => row(LCOL[i], `${LEVELS[i]} ${['<15%', '15–35%', '35–60%', '≥60%'][i]}`)).join('');
  else if (L === 'sev') h = '<b>Predicted severity (peak)</b>' + [1, 2, 3].map(i => row(LCOL[i], SEV[i])).join('') + row('#2e9e5b', 'None');
  else if (L === 'prio') h = '<b>Response priority</b><div class="row"><span class="sw" style="background:linear-gradient(90deg,#1c3b5a,#7b2cbf,#ff2e63);width:90px"></span></div><span class="sub">risk × population × vulnerability</span>';
  else if (L === 'vuln') h = '<b>Social vulnerability</b><div class="row"><span class="sw" style="background:linear-gradient(90deg,#1d3b2f,#e9c46a,#e76f51);width:90px"></span></div><span class="sub">density · slums · age · hospital access</span>';
  else h = '<b>Actual flooding (replay)</b>' + row('#d62839', 'Flooded') + row('#2e9e5b', 'Dry') + row('#6b7a8d', 'Unknown (before event)');
  h += `<div class="row" style="margin-top:4px"><span class="sw" style="background:#4a6fa5"></span>Water body</div>`;
  $('#legend').innerHTML = h;
}
function drawWarnings(d) {
  L_.warn.clearLayers();
  const top = d.alerts.filter(a => a.level_idx === 3).slice(0, 10);          // pulsing "!" only for the 10 most urgent Critical wards
  d.alerts.filter(a => a.level_idx >= 2).forEach(a => {
    const big = top.includes(a), cls = big ? (a.level_idx === 2 ? 'h' : '') : (a.level_idx === 3 ? 'sm' : 'h sm');
    const sz = big ? 26 : 13;
    const ic = L.divIcon({className: '', html: `<div class="warnico ${cls}">${big ? '!' : ''}</div>`, iconSize: [sz, sz], iconAnchor: [sz / 2, sz / 2]});
    L.marker([a.lat, a.lon], {icon: ic, pane: 'top'}).addTo(L_.warn)
      .bindTooltip(`<b>${a.level}</b> · ${esc(a.area)}<br>${pct(a.probability)} (${pct(a.p_low)}–${pct(a.p_high)}) · impact ${fmtMin(a.impact_in_min)}`)
      .on('click', () => focusAlert(a.key));
  });
}
function icon(type, extra) {
  const sq = type === 'shelter' || type === 'hospital' ? ' sq' : '';
  return L.divIcon({className: '', html: `<div class="divico t-${type}${sq} ${extra || ''}">${TYPE_LETTER[type]}</div>`, iconSize: [18, 18], iconAnchor: [9, 9]});
}
function drawResources(d) {
  L_.res.clearLayers(); L_.shel.clearLayers();
  d.resources.forEach(r => {
    const m = L.marker([r.lat, r.lon], {icon: icon(r.type, (r.status === 'deployed' ? 'dep ' : '') + (r.assigned ? 'asg' : '')), pane: 'top'})
      .bindTooltip(`<b>${TYPE_LABEL[r.type]}</b> ${esc(r.id)}<br>capacity ${r.capacity} ${esc(r.unit)}<br>${r.status}${r.assigned ? ' · <b>assigned</b>' : ''}`);
    (r.type === 'shelter' || r.type === 'hospital' ? L_.shel : L_.res).addLayer(m);
  });
}
function drawReports(d) {
  L_.rep.clearLayers();
  const col = {verified: '#2ee6a6', likely: '#ffd84d', unverified: '#ff7b72'};
  d.reports.filter(r => r.status !== 'not_flood' && r.lat != null).forEach(r => {
    L.circleMarker([r.lat, r.lon], {radius: 6, color: '#fff', weight: 1.5, fillColor: col[r.status] || '#aaa', fillOpacity: 0.95, pane: 'top'}).addTo(L_.rep)
      .bindTooltip(`<b>${r.status}</b> (${r.credibility == null ? '—' : Math.round(r.credibility)}/100)<br>${esc(r.text).slice(0, 110)}`);
  });
}
function drawEvacRoutes(d) {
  L_.routes.clearLayers();
  d.evac.zones.forEach(z => {
    if (!z.route) { L.circleMarker([z.lat, z.lon], {radius: 8, color: '#ff5a6b', weight: 3, fillOpacity: 0, pane: 'top'}).addTo(L_.routes).bindTooltip(`${esc(z.area)}<br><b>${z.status}</b>: ${esc(z.action)}`); return; }
    const closing = z.route.safe_window_min != null;
    L.polyline(z.route.coords, {color: closing ? '#ffb347' : '#59e0a3', weight: 4, opacity: 0.85, dashArray: closing ? '6 6' : null, pane: 'top'}).addTo(L_.routes)
      .bindTooltip(`${esc(z.area)} → ${esc(z.shelter.name)}<br>ETA ${Math.round(z.route.eta_min)} min · ${closing ? 'route closes in ' + fmtMin(z.route.safe_window_min) : 'stays open'}<br>${esc(z.action)}`);
  });
}
function drawAssign(d) {
  L_.assign.clearLayers();
  const col = {pump: '#5cc8ff', boat: '#6ee7b7', ambulance: '#ffffff', rescue_team: '#c4b5fd'};
  d.plan.assignments.forEach(a => L.polyline([[a.from_lat, a.from_lon], [a.to_lat, a.to_lon]], {color: col[a.type], weight: 1.5, opacity: 0.7, dashArray: '3 5', pane: 'top'}).addTo(L_.assign)
    .bindTooltip(`${TYPE_LABEL[a.type]} ${esc(a.resource_id)} → ${esc(a.site)} · ${a.eta_min} min · ${esc(a.action)}`));
}
function drawSelection() {
  L_.sel.clearLayers(); const d = S.data; if (!d) return;
  if (S.selected) { const c = d.cells.find(x => x.id === S.selected); if (c) L.rectangle(cellBounds(c), {color: '#fff', weight: 2.5, fillOpacity: 0, pane: 'top'}).addTo(L_.sel); }
  if (S.selRoutes && S.selRoutes.draw) {
    const r = S.selRoutes.draw;
    L.polyline(r.fastest.coords, {color: '#ff8a5c', weight: 3, dashArray: '2 7', opacity: 0.9, pane: 'top'}).addTo(L_.sel).bindTooltip(`Fastest: ${r.fastest.eta_min} min (max risk ${pct(r.fastest.max_risk)})`);
    L.polyline(r.safest.coords, {color: '#2ee6a6', weight: 5, opacity: 0.95, pane: 'top'}).addTo(L_.sel).bindTooltip(`Safest: ${r.safest.eta_min} min (max risk ${pct(r.safest.max_risk)})`);
  }
}
function applyToggles() {
  const map_ = {res: '#tgRes', shel: '#tgShel', rep: '#tgRep', routes: '#tgRoute', assign: '#tgAssign', warn: '#tgWarn'};
  Object.entries(map_).forEach(([k, id]) => { const on = $(id).checked; if (on && !map.hasLayer(L_[k])) map.addLayer(L_[k]); if (!on && map.hasLayer(L_[k])) map.removeLayer(L_[k]); });
}

// ------------------------------------------------------------------------------------------------ left panel
function renderSit(d) {
  const s = d.summary, c = d.context, li = LEVELS.indexOf(s.overall_level);
  const t = s.truth ? `<div class="sub" style="margin-top:6px">Actual flooded now: <b>${pct(s.truth.flooded_share)}</b> of cells · model mean P(now): <b>${pct(s.truth.predicted_share_now)}</b></div>` : '';
  $('#sit').innerHTML = `
    <div class="sit-head"><div><div class="sub">${esc(c.label)}</div><div class="sub">${esc(c.now)} · forecast issued now</div></div><div class="big L${li}">${s.overall_level.toUpperCase()}</div></div>
    <div class="kpis">
      <div class="kpi"><b>${fmtN(s.people_at_risk)}</b><span>people in High+ risk cells</span></div>
      <div class="kpi"><b>${fmtMin(s.next_impact_min)}</b><span>until first High-risk impact</span></div>
      <div class="kpi"><b>${s.critical_wards} <small style="font-size:12px;color:var(--muted)">/ ${s.high_wards} High</small></b><span>Critical wards</span></div>
      <div class="kpi"><b>${s.pending_confirmations}</b><span>alerts awaiting officer</span></div>
      <div class="kpi"><b>${s.rain.now_mm_h} <small style="font-size:12px;color:var(--muted)">mm/h</small></b><span>rain now · ${s.rain.last3h} mm in 3 h</span></div>
      <div class="kpi"><b>${s.rain.next6h} <small style="font-size:12px;color:var(--muted)">mm</small></b><span>forecast next 6 h · ${s.rain.next24h} in 24 h</span></div>
      <div class="kpi"><b>${s.verified_reports}<small style="font-size:12px;color:var(--muted)"> / ${s.reports_total}</small></b><span>verified / all social reports</span></div>
      <div class="kpi"><b>${pct(s.soil_moisture)}</b><span>soil saturation · river ${pct(s.river_level)}${s.tide_m != null ? ' · tide ' + s.tide_m + ' m' : ''}</span></div>
    </div>${t}`;
}
let rainChart;
function drawRain(d) {
  const s = d.series, labels = s.hours.map(h => h === 0 ? 'now' : (h > 0 ? '+' + h : h));
  const risk = s.hours.map(h => h >= 0 ? s.city_p[h] : null);
  const barCol = s.hours.map(h => h <= 0 ? '#4da3ff' : 'rgba(77,163,255,.45)');
  const cfg = {data: {labels, datasets: [
    {type: 'bar', label: 'Rain mm/h (observed | forecast)', data: s.rain, backgroundColor: barCol, yAxisID: 'y', order: 2},
    {type: 'line', label: 'Mean P(flood)', data: risk, borderColor: '#ff7b72', backgroundColor: '#ff7b72', yAxisID: 'y1', tension: 0.3, pointRadius: 0, borderWidth: 2, order: 1}]},
    options: {responsive: true, maintainAspectRatio: false, animation: false, plugins: {legend: {labels: {boxWidth: 10, font: {size: 10}}}},
      scales: {x: {ticks: {maxTicksLimit: 9, font: {size: 10}}}, y: {title: {display: true, text: 'mm/h', font: {size: 10}}, ticks: {font: {size: 10}}},
        y1: {position: 'right', min: 0, max: 1, grid: {display: false}, ticks: {font: {size: 10}, callback: v => Math.round(v * 100) + '%'}}}}};
  if (rainChart) rainChart.destroy();
  rainChart = new Chart($('#rainChart'), cfg);
}
function renderAlerts(d) {
  $('#alertCount').textContent = `${d.alerts.length} wards · ${d.alerts.filter(a => a.level_idx >= 2).length} High/Critical`;
  $('#alerts').innerHTML = d.alerts.slice(0, 40).map(a => {
    const st = STATUS_CHIP[a.status] || [a.status, 'st'];
    const msgs = Object.keys(a.messages || {});
    const open = S.openMsg[a.key], lg = S.lang[a.key] || 'en';
    const sms = open && msgs.length ? `<div class="sms"><div class="langs">${msgs.map(k => `<button data-lang="${k}" data-key="${esc(a.key)}" class="${k === lg ? 'on' : ''}">${esc(a.messages[k].lang)}</button>`).join('')}</div>
      <div>${esc((a.messages[lg] || a.messages.en).text)}</div><div class="sub" style="margin-top:4px">To: ${a.audience.map(x => x.replace('_', ' ')).join(', ')} · nearest safe shelter: ${esc(a.shelter ? a.shelter.name : '—')}</div></div>` : '';
    const btns = a.status === 'pending_confirmation'
      ? `<button class="primary" data-act="confirm" data-ward="${esc(a.ward)}" data-level="${a.level}">Confirm &amp; broadcast</button><button data-act="dismiss" data-ward="${esc(a.ward)}" data-level="${a.level}">Dismiss</button>` : '';
    const prev = msgs.length ? `<button data-act="msg" data-key="${esc(a.key)}">${open ? 'Hide' : 'Preview'} SMS</button>` : '';
    return `<div class="alert L${a.level_idx} ${S.sel === a.key ? 'sel' : ''}" data-key="${esc(a.key)}" data-ward="${esc(a.ward)}">
      <div class="hd"><span>${esc(a.area)}</span>${chip(a.level_idx)}</div>
      <div class="meta">P <b>${pct(a.probability)}</b> (${pct(a.p_low)}–${pct(a.p_high)}) · severity <b>${a.severity}</b> · impact <b>${fmtMin(a.impact_in_min)}</b> · ${fmtN(a.people_at_risk)} people</div>
      <ul>${a.reasons.map(r => `<li>${esc(r)}</li>`).join('')}</ul>
      <div class="row2"><span class="chip ${st[1]} st">${st[0]}</span>${a.level === 'High' ? `<span class="sub">${CIT_TEXT[a.citizens_status] || ''}</span>` : ''}</div>
      <div class="sub" style="margin-top:3px">${esc(a.action)}</div><div class="btns">${btns}${prev}</div>${sms}</div>`;
  }).join('') || '<div class="sub">No ward is above Moderate risk.</div>';
}
function focusAlert(key) {
  S.sel = key; renderAlerts(S.data); const el = document.querySelector(`.alert[data-key="${CSS.escape(key)}"]`);
  if (el) el.scrollIntoView({block: 'center', behavior: 'smooth'});
  const a = S.data.alerts.find(x => x.key === key); if (a) map.flyTo([a.lat, a.lon], Math.max(map.getZoom(), 13.5), {duration: 0.6});
}

// ------------------------------------------------------------------------------------------------ right tabs
function showTab(name) {
  document.querySelectorAll('#tabs button').forEach(b => b.classList.toggle('on', b.dataset.tab === name));
  document.querySelectorAll('.tab').forEach(t => t.classList.toggle('hidden', t.id !== 'tab-' + name));
  $('#right').scrollTop = 0;
  if (name === 'hist') loadHistory();
  if (name === 'whatif') renderWhatIf();
}
let cellChart;
async function selectCell(id) {
  S.selected = id; S.selRoutes = null; drawSelection(); showTab('cell');
  $('#tab-cell').innerHTML = '<div class="card sub">Loading cell…</div>';
  try {
    const x = await api('/api/cell', {...ctxBody(), cell_id: id});
    if (S.selected !== id) return;
    renderCell(x);
  } catch (e) { toast(e.message); }
}
function renderCell(x) {
  const pk = x.peak, v = x.vulnerability, li = lvl(pk.p), maxR = Math.max(...x.reasons.map(r => r.shap), 0.1);
  $('#tab-cell').innerHTML = `
    <div class="card"><h3>${esc(x.cell.area)} <small>${esc(x.cell.id)} · ${esc(x.cell.land_use)} · ${x.cell.elevation_m} m · ${x.cell.imperviousness_pct}% paved</small></h3>
      <div class="row2">${chip(li)} <span class="chip st">Severity: ${pk.severity}</span> <span class="chip st">priority ${Math.round(v.priority)}</span> ${v.known_flood_spot ? '<span class="chip bad">known flood spot</span>' : ''}</div>
      <div class="kpis"><div class="kpi"><b>${pct(pk.p)}</b><span>peak probability, in +${pk.hour} h</span></div><div class="kpi"><b>${fmtMin(pk.lead_high_min)}</b><span>until High (≥35%) · Critical in ${fmtMin(pk.lead_crit_min)}</span></div></div>
      <div class="chartbox tall" style="margin-top:8px"><canvas id="cellChart"></canvas></div></div>
    <div class="card"><h3>Why? <small>top drivers (TreeSHAP)</small></h3>${x.reasons.length ? x.reasons.map(r => `<div class="reason"><div>${esc(r.text)}</div><div class="bar"><i style="width:${Math.round(100 * r.shap / maxR)}%"></i></div></div>`).join('') : '<div class="sub">No single dominant driver.</div>'}</div>
    <div class="card"><h3>Who is exposed</h3><div class="kv"><span>People in cell</span><b>${fmtN(v.people_in_cell)}</b><span>Expected affected</span><b>${fmtN(Math.round(v.people_at_risk))}</b>
      <span>Vulnerability index</span><b>${v.index.toFixed(2)}</b><span>Informal settlement</span><b>${v.slum_pct.toFixed(0)}%</b><span>Elderly / children</span><b>${v.elderly_pct.toFixed(0)}% / ${v.children_pct.toFixed(0)}%</b>
      <span>Nearest hospital / shelter</span><b>${Math.round(v.hospital_dist_m)} m / ${Math.round(v.shelter_dist_m)} m</b><span>Underpasses · critical infra</span><b>${v.underpasses} · ${v.critical_infra}</b><span>Past floods (5 y)</span><b>${v.past_floods_5y}</b></div></div>
    <div class="card"><h3>Evacuate from here</h3><button class="primary" id="routeBtn">Find safest routes to shelters</button><div id="routeOut"></div></div>
    ${x.reports.length ? `<div class="card"><h3>Reports within 1.2 km</h3>${x.reports.map(repHtml).join('')}</div>` : ''}`;
  $('#routeBtn').onclick = () => findRoutes(x.cell.id);
  drawCellChart(x);
}
function drawCellChart(x) {
  const s = x.series, labels = s.hours.map(h => h === 0 ? 'now' : '+' + h + 'h');
  const truth = x.truth ? s.hours.map(h => { const f = x.truth.current_frame + h; return f >= 0 && f < x.truth.flooded.length ? x.truth.flooded[f] : null; }) : null;
  const ds = [
    {label: 'low', data: s.lo, borderColor: 'transparent', backgroundColor: 'rgba(255,123,114,.22)', pointRadius: 0, fill: false},
    {label: 'forecast range', data: s.hi, borderColor: 'transparent', backgroundColor: 'rgba(255,123,114,.22)', pointRadius: 0, fill: '-1'},
    {label: 'P(flood)', data: s.p, borderColor: '#ff7b72', backgroundColor: '#ff7b72', tension: 0.3, pointRadius: 0, borderWidth: 2.5},
    {label: 'High (35%)', data: s.hours.map(() => 0.35), borderColor: '#f08a24', borderDash: [4, 4], pointRadius: 0, borderWidth: 1},
    {label: 'Critical (60%)', data: s.hours.map(() => 0.6), borderColor: '#d62839', borderDash: [4, 4], pointRadius: 0, borderWidth: 1}];
  if (truth) ds.push({label: 'actual (1=flooded)', data: truth, showLine: false, pointStyle: 'rectRot', pointRadius: 5, borderColor: '#2ee6a6', backgroundColor: '#2ee6a6'});
  if (cellChart) cellChart.destroy();
  cellChart = new Chart($('#cellChart'), {type: 'line', data: {labels, datasets: ds}, options: {responsive: true, maintainAspectRatio: false, animation: false,
    plugins: {legend: {labels: {boxWidth: 10, font: {size: 10}, filter: i => i.text !== 'low'}}},
    scales: {y: {min: 0, max: 1, ticks: {callback: v => Math.round(v * 100) + '%', font: {size: 10}}}, x: {ticks: {maxTicksLimit: 9, font: {size: 10}}}}}});
}
async function findRoutes(id) {
  $('#routeOut').innerHTML = '<div class="sub">Routing…</div>';
  try {
    const r = await api('/api/route', {...ctxBody(), origin_cell: id});
    S.selRoutes = {list: r.routes, draw: r.routes[0] ? {safest: r.routes[0].safest, fastest: r.routes[0].fastest} : null};
    $('#routeOut').innerHTML = r.routes.length ? r.routes.map((q, k) => `<div class="route" data-k="${k}" style="cursor:pointer">
      <b>${esc(q.shelter.name)}</b> ${q.shelter.safe ? '<span class="chip good">shelter safe</span>' : '<span class="chip bad">shelter at risk</span>'}
      <div class="sub">Safest: <b>${Math.round(q.safest.eta_min)} min</b>, max risk ${pct(q.safest.max_risk)} · ${q.safest.safe_window_min == null ? 'stays open for the whole 24 h forecast' : 'closes in ' + fmtMin(q.safest.safe_window_min) + ' if you wait'}</div>
      <div class="sub">Fastest: ${Math.round(q.fastest.eta_min)} min, max risk ${pct(q.fastest.max_risk)} · capacity ${q.shelter.capacity}</div></div>`).join('')
      : '<div class="note-box">No open route to a safe shelter: this area is cut off. Request boat / rescue-team evacuation.</div>';
    document.querySelectorAll('#routeOut .route').forEach(el => el.onclick = () => { const q = S.selRoutes.list[+el.dataset.k]; S.selRoutes.draw = {safest: q.safest, fastest: q.fastest}; drawSelection(); });
    drawSelection();
  } catch (e) { toast(e.message); $('#routeOut').innerHTML = ''; }
}
function renderEvac(d) {
  const e = d.evac;
  $('#tab-evac').innerHTML = `<div class="card"><h3>Evacuation plan <small>${fmtN(e.exposed_total)} exposed · ${fmtN(e.people_total)} to move</small></h3>
    <div class="note-box">Routes are re-evaluated hour by hour: an edge is closed when its predicted flood probability at the time you would reach it passes 60% (35% for underpasses). “Depart by” leaves a 20-minute buffer before the zone reaches High risk.</div>
    <table><tr><th>Zone</th><th>Move</th><th>To shelter</th><th>ETA</th><th>Action</th></tr>${e.zones.map((z, k) => z.route ?
      `<tr class="click" data-k="${k}"><td>${esc(z.area)}</td><td>${fmtN(z.people)}</td><td>${esc(z.shelter.name)}</td><td>${Math.round(z.route.eta_min)} min<br><span class="sub">${z.route.safe_window_min == null ? 'open' : 'closes ' + fmtMin(z.route.safe_window_min)}</span></td>
       <td><span class="chip ${z.action === 'DEPART NOW' ? 'bad' : 'mid'}">${esc(z.action)}</span></td></tr>`
      : `<tr class="click" data-k="${k}"><td>${esc(z.area)}</td><td>${fmtN(z.people)}</td><td colspan="2"><span class="chip bad">${z.status}</span></td><td>${esc(z.action)}</td></tr>`).join('') || '<tr><td colspan="5" class="sub">No zone needs evacuation yet.</td></tr>'}</table></div>
    <div class="card"><h3>Shelter capacity</h3>${e.shelters_used.map(s => `<div class="reason"><div>${esc(s.id)} <span class="sub">${fmtN(s.used)} / ${fmtN(s.capacity)}</span></div><div class="bar"><i style="width:${Math.min(100, 100 * s.used / s.capacity)}%"></i></div></div>`).join('') || '<div class="sub">No shelter allocation needed.</div>'}
      <div class="sub" style="margin-top:6px">Total shelter capacity ${fmtN(e.shelter_capacity_total)} vs ${fmtN(e.people_total)} people to move.</div></div>`;
  document.querySelectorAll('#tab-evac tr.click').forEach(tr => tr.onclick = () => { const z = d.evac.zones[+tr.dataset.k]; map.flyTo([z.lat, z.lon], 14, {duration: 0.6}); if (z.route) { S.selRoutes = {list: [], draw: {safest: z.route, fastest: z.fastest_route || z.route}}; drawSelection(); } });
}
function renderRes(d) {
  const p = d.plan, cmp = p.comparison, b = cmp.baseline, o = cmp.optimized;
  const row = (k, v) => `<tr><td>${TYPE_LABEL[k]}</td><td>${v.required}</td><td>${v.available}</td><td>${v.assigned}</td><td>${v.shortfall ? `<span class="chip bad">−${v.shortfall}</span>` : '<span class="chip good">covered</span>'}</td></tr>`;
  $('#tab-res').innerHTML = `
    <div class="card"><h3>Needed vs available <small>${p.n_available} available · ${p.n_deployed} already deployed</small></h3>
      <table><tr><th>Type</th><th>Needed</th><th>Available</th><th>Assigned</th><th>Gap</th></tr>${Object.entries(p.summary).map(([k, v]) => row(k, v)).join('')}</table>
      <div class="sub" style="margin-top:6px">Demand comes from the forecast: High+ cells need pumps, Critical populated cells need boats, High/Critical wards need ambulances, Critical wards and cut-off zones need rescue teams.</div></div>
    <div class="card"><h3>Optimised vs first-come-first-served</h3>
      <table><tr><th></th><th>Baseline</th><th>Optimised</th></tr>
      <tr><td>Priority-weighted coverage</td><td>${b.priority_weighted_coverage}%</td><td><b>${o.priority_weighted_coverage}%</b></td></tr>
      <tr><td>Avg response (priority-weighted)</td><td>${b.avg_response_min} min</td><td><b>${o.avg_response_min} min</b></td></tr>
      <tr><td>High-priority sites reached ≤30 min</td><td>${b.high_priority_within_30min}</td><td><b>${o.high_priority_within_30min}</b></td></tr></table>
      <div class="sub" style="margin-top:6px">Same resources, better placement: a mixed-integer program maximises priority-weighted coverage and breaks ties by response time.</div></div>
    <div class="card"><h3>Shelter gap</h3><div class="kv"><span>People to move</span><b>${fmtN(p.shelters.evacuees)}</b><span>Shelter capacity</span><b>${fmtN(p.shelters.capacity)}</b></div>
      ${p.shelters.gap ? `<div class="note-box" style="margin-top:6px">Gap of <b>${fmtN(p.shelters.gap)}</b> people: open overflow shelters or request mutual aid.</div>` : ''}</div>
    <div class="card"><h3>Dispatch list <small>${p.assignments.length} assignments</small></h3>
      <table><tr><th>Resource</th><th>Go to</th><th>ETA</th><th>When</th></tr>${p.assignments.slice(0, 24).map(a => `<tr><td>${TYPE_LABEL[a.type]}<br><span class="sub">${esc(a.resource_id)}</span></td><td>${esc(a.site)}<br><span class="sub">priority ${a.priority}</span></td><td>${a.eta_min} min</td>
        <td><span class="chip ${a.action.startsWith('DISPATCH') ? 'bad' : 'mid'}">${esc(a.action)}</span></td></tr>`).join('')}</table></div>
    ${p.unmet.length ? `<div class="card"><h3>Unmet demand <small>request mutual aid</small></h3><table>${p.unmet.map(u => `<tr><td>${TYPE_LABEL[u.type]} ×${u.units}</td><td>${esc(u.site)}</td><td>priority ${u.priority}</td></tr>`).join('')}</table></div>` : ''}`;
}
function repHtml(r) {
  const col = {verified: 'good', likely: 'mid', unverified: 'bad', not_flood: 'st'}[r.status] || 'st', b = r.breakdown || {};
  const bd = r.status === 'not_flood' ? 'Not about flooding — ignored.' : `text ${b.text_confidence ?? '—'} · rumour-style ${b.rumour_likelihood ?? '—'} · location plausibility ${b.model_risk_at_location ?? '—'} · rain support ${b.rain_support ?? '—'} · corroborating ${b.corroborating_reports ?? 0} · ${b.photo ? 'photo' : 'no photo'} · location: ${b.location_precision || r.loc}`;
  return `<div class="rep"><div class="row2"><span class="chip ${col} st">${r.status}</span><b>${r.credibility == null ? '' : Math.round(r.credibility) + '/100'}</b><span class="sub">${r.place ? esc(r.place) : (r.loc === 'gps' ? 'GPS' : '')} · ${esc(r.label)}${r.source === 'user' ? ' · you' : ''}</span></div>
    <div class="t">${esc(r.text)}</div><div class="bd">${bd}</div></div>`;
}
function renderReports(d) {
  const ex = ['Water above the footpath near the station, buses have stopped', 'Forward this: dam broke, whole area will be drowned in 1 hour, share now', 'Lovely rain today, chai time'];
  $('#tab-rep').innerHTML = `
    <div class="card"><h3>Submit a citizen report <small>scored against the model</small></h3>
      <textarea id="repText" placeholder="e.g. Knee deep water near Kurla station, cars stuck"></textarea>
      <div class="row2" style="margin-top:6px"><label class="sub"><input type="checkbox" id="repGps"> attach selected cell's GPS</label><label class="sub"><input type="checkbox" id="repImg"> has photo</label><span class="grow"></span><button class="primary" id="repSend">Submit</button></div>
      <div class="row2" style="margin-top:6px">${ex.map((t, k) => `<button class="ghost" data-ex="${k}" style="font-size:11px">example ${k + 1}</button>`).join('')}</div>
      ${S.lastReport ? `<div style="margin-top:8px"><b>Result</b>${repHtml({...S.lastReport, source: 'user'})}</div>` : ''}</div>
    <div class="card"><h3>Incoming reports <small>${d.summary.verified_reports} verified · ${d.summary.reports_total} total</small></h3>
      <div class="note-box">Each post is classified (flood / not), located (GPS or place name), and scored 0–100 from five signals. ≥70 verified · ≥45 likely. Rumour-style forwards and spots the model finds implausible score low.</div>
      <div style="margin-top:8px">${d.reports.map(repHtml).join('') || '<div class="sub">No reports yet at this time.</div>'}</div></div>`;
  document.querySelectorAll('#tab-rep [data-ex]').forEach(b => b.onclick = () => { $('#repText').value = ex[+b.dataset.ex]; });
  $('#repSend').onclick = submitReport;
}
async function submitReport() {
  const text = $('#repText').value.trim(); if (!text) return toast('Type a report first', 'info');
  const body = {...ctxBody(), text, has_image: $('#repImg').checked};
  if ($('#repGps').checked && S.selected && S.data) { const c = S.data.cells.find(x => x.id === S.selected); if (c) { body.lat = c.lat; body.lon = c.lon; } }
  try { S.lastReport = await api('/api/report', body); await load('Re-scoring…'); showTab('rep'); } catch (e) { toast(e.message); }
}
const WI = [['peak_mm_h', 'Peak intensity', 5, 120, 1, 'mm/h'], ['duration_h', 'Storm duration', 2, 24, 1, 'h'], ['hours_to_peak', 'Peak arrives in', 0, 18, 1, 'h'],
  ['antecedent_mm_72h', 'Rain in last 72 h', 0, 300, 5, 'mm'], ['tide_high_in_h', 'High tide in', 0, 12, 1, 'h'], ['surge_m', 'Storm surge', 0, 1.5, 0.1, 'm']];
function renderWhatIf() {
  const def = S.meta.scenario_defaults, cur = {...def, ...S.scenario}, coastal = S.meta.cities[S.city].coastal;
  $('#tab-whatif').innerHTML = `<div class="card"><h3>What-if rainfall <small>${S.mode === 'scenario' ? 'active' : 'moves you into What-if mode'}</small></h3>
    <div class="note-box">Type the rain you expect; the same model, alerts, routes and resource plan re-run on your inputs.</div>
    ${WI.filter(w => coastal || !['tide_high_in_h', 'surge_m'].includes(w[0])).map(w => `<div class="slider-row"><span>${w[1]}</span><input type="range" min="${w[2]}" max="${w[3]}" step="${w[4]}" value="${cur[w[0]]}" data-p="${w[0]}"><b>${cur[w[0]]} ${w[5]}</b></div>`).join('')}
    <div class="row2" style="margin-top:8px"><button id="wiReset">Reset</button><button id="wiLive" title="Needs internet">Use LIVE forecast</button></div>
    <div class="sub" style="margin-top:6px">Presets: <a href="#" data-pre="light">light</a> · <a href="#" data-pre="heavy">heavy monsoon</a> · <a href="#" data-pre="extreme">extreme</a></div></div>`;
  const pre = {light: {peak_mm_h: 12, duration_h: 6, antecedent_mm_72h: 20}, heavy: {peak_mm_h: 45, duration_h: 8, antecedent_mm_72h: 80}, extreme: {peak_mm_h: 85, duration_h: 12, antecedent_mm_72h: 180}};
  document.querySelectorAll('#tab-whatif input[type=range]').forEach(r => {
    r.oninput = () => { r.nextElementSibling.textContent = r.value + ' ' + WI.find(w => w[0] === r.dataset.p)[5]; };
    r.onchange = () => { S.scenario[r.dataset.p] = +r.value; setMode('scenario'); };
  });
  $('#wiReset').onclick = () => { S.scenario = {}; setMode('scenario'); renderWhatIf(); };
  $('#wiLive').onclick = () => setMode('live');
  document.querySelectorAll('#tab-whatif [data-pre]').forEach(a => a.onclick = e => { e.preventDefault(); S.scenario = {...pre[a.dataset.pre]}; setMode('scenario'); renderWhatIf(); });
}

// ------------------------------------------------------------------------------------------------ history / compare
async function loadHistory() {
  const box = $('#tab-hist');
  if (!S.histCache.compare) {
    box.innerHTML = '<div class="card sub">Loading…</div>';
    try { S.histCache.compare = (await api('/api/compare')).rows; } catch (e) { box.innerHTML = `<div class="card">${esc(e.message)}</div>`; return; }
  }
  if (!S.histCache[S.city]) S.histCache[S.city] = (await api('/api/history/' + S.city)).events;
  const ev = S.histCache[S.city], rows = S.histCache.compare;
  const m = e => `<tr><td>${e.date}</td><td>${e.in_sample ? '<span class="chip st">in-sample</span>' : '<span class="chip good">out-of-time</span>'}</td><td>${e.total_mm_24h} mm</td><td>${e.pct_cells_flooded}%</td><td>${fmtN(e.people_in_flooded_cells)}</td></tr>`;
  box.innerHTML = `
    <div class="card"><h3>${esc(S.city)} past events</h3>
      <table><tr><th>Date</th><th>Model</th><th>24 h rain</th><th>Cells flooded*</th><th>People there</th></tr>${ev.map(m).join('')}</table>
      <div class="sub">*3+ consecutive flooded hours. “in-sample”: the model was trained on this event; “out-of-time”: it never saw it.</div></div>
    <div class="card"><h3>Actual vs predicted flooded share <small>${esc(S.city)}</small></h3><div class="chartbox tall"><canvas id="histChart"></canvas></div></div>
    <div class="card"><h3>How well did the alerts work? <small>${esc(S.city)}</small></h3>
      <table><tr><th>Event</th><th>Alert</th><th>Caught</th><th>Median lead</th><th>False alarms</th></tr>${ev.map(e => ['high', 'critical'].map(k => `<tr><td>${e.date}</td><td>${k === 'high' ? 'High ≥35%' : 'Critical ≥60%'}</td><td>${pct(e['alerts_' + k].hit_rate)}</td><td>${e['alerts_' + k].median_lead_h} h</td><td>${pct(e['alerts_' + k].false_alarm_share)}</td></tr>`).join('')).join('')}</table>
      <div class="note-box" style="margin-top:6px">Honest trade-off: the lower High threshold catches more floods earlier but raises false alarms. Alerts are judged from 12 h before the labelled window; “caught” = warned before a sustained flood began.</div></div>
    <div class="card"><h3>Compare cities <small>2025 events (out-of-time)</small></h3><div class="chartbox tall"><canvas id="cmpChart"></canvas></div>
      <table style="margin-top:8px"><tr><th>City</th><th>Rain</th><th>Peak 1 h</th><th>AUC</th><th>Caught</th><th>Lead</th><th>False</th></tr>${rows.filter(r => !r.in_sample).map(r => `<tr class="click" data-city="${r.city}"><td>${r.city}</td><td>${r.total_mm_24h}</td><td>${r.peak_rain_1h}</td><td>${r.auc}</td><td>${pct(r.alerts_high.hit_rate)}</td><td>${r.alerts_high.median_lead_h} h</td><td>${pct(r.alerts_high.false_alarm_share)}</td></tr>`).join('')}</table></div>`;
  const labels = ev[0].flood_share_truth.map((_, i) => i);
  new Chart($('#histChart'), {type: 'line', data: {labels, datasets: ev.flatMap((e, k) => [
    {label: `actual ${e.date}`, data: e.flood_share_truth, borderColor: ['#2ee6a6', '#59b2ff'][k], borderWidth: 2.5, pointRadius: 0, tension: 0.25},
    {label: `predicted ${e.date}`, data: e.flood_share_pred, borderColor: ['#2ee6a6', '#59b2ff'][k], borderDash: [5, 4], borderWidth: 2, pointRadius: 0, tension: 0.25}])},
    options: {responsive: true, maintainAspectRatio: false, animation: false, plugins: {legend: {labels: {boxWidth: 10, font: {size: 10}}}}, scales: {y: {min: 0, max: 1, ticks: {callback: v => Math.round(v * 100) + '%'}}, x: {title: {display: true, text: 'hour of event', font: {size: 10}}}}}});
  const o = rows.filter(r => !r.in_sample);
  new Chart($('#cmpChart'), {type: 'bar', data: {labels: o.map(r => r.city), datasets: [
    {label: 'Floods caught before onset (High alert)', data: o.map(r => r.alerts_high.hit_rate), backgroundColor: '#2ee6a6'},
    {label: 'False-alarm share', data: o.map(r => r.alerts_high.false_alarm_share), backgroundColor: '#ff7b72'},
    {label: 'Cells flooded', data: o.map(r => r.pct_cells_flooded / 100), backgroundColor: '#59b2ff'}]},
    options: {responsive: true, maintainAspectRatio: false, animation: false, plugins: {legend: {labels: {boxWidth: 10, font: {size: 10}}}}, scales: {y: {min: 0, max: 1, ticks: {callback: v => Math.round(v * 100) + '%'}}}}});
  box.querySelectorAll('tr.click').forEach(tr => tr.onclick = () => { $('#citySel').value = tr.dataset.city; changeCity(tr.dataset.city); });
}

// ------------------------------------------------------------------------------------------------ overlays
let indiaMap;
async function openIndia() {
  $('#india').classList.remove('hidden');
  const o = await api('/api/india');
  if (!indiaMap) { indiaMap = L.map('indiaMap').setView([21.5, 80], 4.6); L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {maxZoom: 10, attribution: '© OpenStreetMap contributors'}).addTo(indiaMap); }
  setTimeout(() => indiaMap.invalidateSize(), 50);
  indiaMap.eachLayer(l => { if (l instanceof L.CircleMarker) indiaMap.removeLayer(l); });
  const li = x => LEVELS.indexOf(x);
  o.cities.forEach(c => L.circleMarker([c.lat, c.lon], {radius: 8 + Math.sqrt(c.people_at_risk) / 28, color: '#fff', weight: 1.5, fillColor: LCOL[li(c.overall_level)], fillOpacity: 0.85}).addTo(indiaMap)
    .bindTooltip(`<b>${c.city}</b> · ${c.overall_level}<br>${fmtN(c.people_at_risk)} people at High+ risk`).on('click', () => openCity(c.city)));
  $('#indiaList').innerHTML = `<h3>States</h3><table><tr><th>State</th><th>Status</th><th>Cities</th><th>People at risk</th><th>Critical wards</th></tr>${o.states.map(s => `<tr><td>${esc(s.state)}</td><td>${chip(li(s.overall_level))}</td><td>${esc(s.cities.join(', '))}</td><td>${fmtN(s.people_at_risk)}</td><td>${s.critical_wards}</td></tr>`).join('')}</table>
    <h3 style="margin-top:14px">Cities</h3><table><tr><th>City</th><th>Status</th><th>Cells L/M/H/C</th><th>Rain</th><th>People at risk</th></tr>${o.cities.map(c => `<tr class="click" data-city="${c.city}"><td><b>${c.city}</b><br><span class="sub">${esc(c.state)}</span></td><td>${chip(li(c.overall_level))}</td>
      <td>${Object.values(c.level_counts).join(' / ')}</td><td>${c.rain_24h_mm} mm</td><td>${fmtN(c.people_at_risk)}</td></tr>`).join('')}</table>
    <div class="note-box" style="margin-top:10px">City status uses the SHARE of the city affected: Critical if ≥20% of cells are Critical, High if ≥20% are High or worse, Moderate if ≥30% are Moderate or worse.</div>`;
  document.querySelectorAll('#indiaList tr.click').forEach(tr => tr.onclick = () => openCity(tr.dataset.city));
}
function openCity(c) { $('#india').classList.add('hidden'); $('#citySel').value = c; changeCity(c); }
async function openAbout() {
  $('#about').classList.remove('hidden');
  const m = S.meta, md = m.model, v = m.verification, n = m.nlp;
  $('#aboutBody').innerHTML = `<div class="note-box">${esc(m.disclaimer)}</div>
    <div class="card"><h3>Flood model <small>5-model LightGBM ensemble + severity model, trained on rows before ${md.trained_before}</small></h3>
      <div class="kv"><span>Out-of-time AUC / PR-AUC</span><b>${md.metrics.auc} / ${md.metrics.pr_auc}</b><span>Precision / recall at High (≥35%)</span><b>${md.metrics.precision_at_high} / ${md.metrics.recall_at_high}</b>
      <span>Test flood rate</span><b>${pct(md.metrics.test_flood_rate)}</b><span>Severity within ±1 class</span><b>${pct(md.metrics.severity_within_one_when_flooded)}</b></div>
      <h3 style="margin-top:10px">Top drivers (global)</h3>${Object.entries(md.feature_importance).slice(0, 8).map(([k, x]) => `<div class="reason"><div>${esc(k)}</div><div class="bar"><i style="width:${Math.round(100 * x / 0.26)}%"></i></div></div>`).join('')}</div>
    <div class="card"><h3>Social-media text model</h3><div class="kv"><span>Flood vs not (held-out templates) F1</span><b>${n.flood_vs_not_f1 ?? '—'}</b><span>5-way type accuracy (held-out)</span><b>${n.accuracy_5class ?? '—'}</b></div>
      <div class="sub" style="margin-top:6px">Trained on templated synthetic posts, so real-world accuracy would be lower. Swap in CrisisNLP / HumAID for real use.</div></div>
    <div class="card"><h3>Report verification</h3><div class="kv"><span>AUC (genuine vs misplaced / rumour)</span><b>${v.auc ?? '—'}</b>
      <span>Mean score: genuine / misplaced / rumour</span><b>${v.mean_score_by_kind ? [v.mean_score_by_kind.genuine, v.mean_score_by_kind.misplaced, v.mean_score_by_kind.rumor].join(' / ') : '—'}</b></div>
      <div class="sub" style="margin-top:6px">Rumours are caught well; misplaced-location reports only partly, because location checks are only as good as the model's spatial skill.</div></div>`;
}

// ------------------------------------------------------------------------------------------------ control flow
async function load(txt) {
  const id = ++S.req; busy(true, txt || 'Computing forecast…');
  try {
    const d = await api('/api/state', ctxBody());
    if (id !== S.req) return;
    S.data = d; S.event = d.context.event || S.event;
    if (S.mode === 'replay') S.frame = d.context.frame;
    render();
  } catch (e) {
    if (id !== S.req) return;
    toast(e.message);
    if (S.mode === 'live') { S.mode = 'replay'; syncControls(); }
  } finally { if (id === S.req) busy(false); }
}
function render() {
  const d = S.data;
  renderSit(d); drawRain(d); renderAlerts(d); renderEvac(d); renderRes(d); renderReports(d); updateMap(d); syncControls();
  if (S.selected && !document.querySelector('#tab-cell').classList.contains('hidden') && S.selected) selectCellQuiet();
}
async function selectCellQuiet() {
  try { const x = await api('/api/cell', {...ctxBody(), cell_id: S.selected}); renderCell(x); if (S.selRoutes) { S.selRoutes = null; drawSelection(); } } catch (e) { /* ignore */ }
}
function syncControls() {
  const rep = S.mode === 'replay', d = S.data;
  document.querySelectorAll('#modeSeg button').forEach(b => b.classList.toggle('on', b.dataset.mode === S.mode));
  $('#eventWrap').style.display = rep ? '' : 'none'; $('#frameSlider').disabled = !rep; $('#playBtn').disabled = !rep;
  $('#frameSlider').value = S.frame; $('#viewHLabel').textContent = S.viewH === 0 ? 'now' : '+' + S.viewH + ' h';
  $('#truthBtn').disabled = !rep;
  if (!rep && S.layer === 'truth') { S.layer = 'prob'; document.querySelectorAll('#layerSeg button').forEach(b => b.classList.toggle('on', b.dataset.layer === 'prob')); }
  if (d) {
    $('#nowLabel').textContent = rep ? `${d.context.now} · frame ${S.frame >= 0 ? '+' : ''}${S.frame} h` : `${d.context.label}`;
    $('#frameNote').textContent = rep ? (S.frame < 0 ? `Before the event: ${-S.frame} h ahead of the labelled window. No ground truth yet; watch the warning build.` : 'Ground truth is available for this hour (use the "Actual" layer).')
      : (S.mode === 'live' ? 'LIVE rainfall from Open-Meteo on synthetic terrain. Demo only.' : 'What-if: forecast built from your inputs (What-if tab).');
  }
}
function setMode(m) {
  S.mode = m; S.selRoutes = null; load(m === 'live' ? 'Fetching live forecast…' : 'Computing forecast…');
}
function changeCity(c) {
  S.city = c; S.event = null; S.selected = null; S.selRoutes = null; S.frame = 7; cellsKey = '';
  const evs = S.meta.cities[c].events; $('#eventSel').innerHTML = evs.map(e => `<option value="${e.id}">${e.date} · ${e.total} mm</option>`).join('');
  S.event = evs[evs.length - 1].id; $('#eventSel').value = S.event;
  $('#tab-cell').innerHTML = '<div class="card sub">Click any cell on the map to see its forecast, drivers, exposure and evacuation routes.</div>';
  load();
}
let playTimer = null;
async function play() {
  if (S.playing) { S.playing = false; $('#playBtn').textContent = '▶ Play'; return; }
  S.playing = true; $('#playBtn').textContent = '⏸ Pause';
  if (S.frame >= 17) S.frame = -12;
  while (S.playing && S.mode === 'replay') {
    await load('Next hour…');
    if (!S.playing) break;
    if (S.frame >= 17) break;
    await new Promise(r => setTimeout(r, 900));
    if (!S.playing) break;
    S.frame += 1;
  }
  S.playing = false; $('#playBtn').textContent = '▶ Play';
}

async function init() {
  initMap();
  Chart.defaults.color = '#9fb3cc'; Chart.defaults.borderColor = '#26364d';
  S.meta = await api('/api/meta');
  $('#citySel').innerHTML = Object.keys(S.meta.cities).map(c => `<option>${c}</option>`).join('');
  $('#citySel').onchange = e => changeCity(e.target.value);
  $('#eventSel').onchange = e => { S.event = e.target.value; S.frame = 7; load(); };
  document.querySelectorAll('#modeSeg button').forEach(b => b.onclick = () => { if (b.dataset.mode !== S.mode || b.dataset.mode === 'live') { if (b.dataset.mode === 'scenario') showTab('whatif'); setMode(b.dataset.mode); } });
  document.querySelectorAll('#tabs button').forEach(b => b.onclick = () => showTab(b.dataset.tab));
  document.querySelectorAll('#layerSeg button').forEach(b => b.onclick = () => { S.layer = b.dataset.layer; document.querySelectorAll('#layerSeg button').forEach(x => x.classList.toggle('on', x === b)); if (S.data) updateMap(S.data); });
  $('#frameSlider').oninput = e => { $('#nowLabel').textContent = `frame ${+e.target.value >= 0 ? '+' : ''}${e.target.value} h`; };
  $('#frameSlider').onchange = e => { S.playing = false; $('#playBtn').textContent = '▶ Play'; S.frame = +e.target.value; load(); };
  $('#viewH').oninput = e => { S.viewH = +e.target.value; $('#viewHLabel').textContent = S.viewH === 0 ? 'now' : '+' + S.viewH + ' h'; if (S.data) updateMap(S.data); };
  $('#playBtn').onclick = play;
  ['tgRes', 'tgShel', 'tgRep', 'tgRoute', 'tgAssign', 'tgWarn'].forEach(id => $('#' + id).onchange = applyToggles);
  $('#indiaBtn').onclick = () => openIndia().catch(e => toast(e.message)); $('#indiaClose').onclick = () => $('#india').classList.add('hidden');
  $('#aboutBtn').onclick = openAbout; $('#aboutClose').onclick = () => $('#about').classList.add('hidden');
  $('#alerts').addEventListener('click', async e => {
    const btn = e.target.closest('button'), card = e.target.closest('.alert'); if (!card) return;
    if (btn && btn.dataset.act === 'msg') { S.openMsg[btn.dataset.key] = !S.openMsg[btn.dataset.key]; renderAlerts(S.data); return; }
    if (btn && btn.dataset.lang) { S.lang[btn.dataset.key] = btn.dataset.lang; renderAlerts(S.data); return; }
    if (btn && (btn.dataset.act === 'confirm' || btn.dataset.act === 'dismiss')) {
      try { await api('/api/alert/decision', {city: S.city, ctx_key: S.data.context.key, ward: btn.dataset.ward, level: btn.dataset.level, action: btn.dataset.act}); toast(btn.dataset.act === 'confirm' ? 'Confirmed: citizen alert broadcast (simulated)' : 'Alert dismissed', 'info'); await load('Updating…'); } catch (er) { toast(er.message); }
      return;
    }
    focusAlert(card.dataset.key);
  });
  changeCity('Mumbai');
}
init().catch(e => { console.error(e); toast('Failed to start: ' + e.message); });
