"""Turns a Context into per-cell flood risk: probability over the next 24 h with an uncertainty range, when each
cell crosses the High/Critical thresholds (lead time), predicted severity, vulnerability-weighted priority
and plain-language reasons (TreeSHAP)."""
from collections import OrderedDict
from dataclasses import dataclass

import numpy as np

from ..config import HORIZON, RAIN_SCENARIOS, THRESH, level_index
from ..context import Context
from ..ml.features import FEATURES, REASON_TEXT, context_features
from ..ml.model import get_model

HS = np.arange(HORIZON + 1)
_CACHE: "OrderedDict[str, Risk]" = OrderedDict()


@dataclass
class Risk:
    ctx: Context
    P: np.ndarray            # (H, n) probability, central forecast
    lo: np.ndarray           # (H, n) lower bound (drier forecast, ensemble spread)
    hi: np.ndarray           # (H, n) upper bound (wetter forecast, ensemble spread)
    X: object                # feature rows (hour-major) used for SHAP
    p_now: np.ndarray
    p_peak: np.ndarray
    h_peak: np.ndarray
    lead_high_min: np.ndarray    # minutes until p >= High (0 = already, nan = not within 24 h)
    lead_crit_min: np.ndarray
    sev: np.ndarray              # predicted severity class 0..3 at the peak hour
    vuln: np.ndarray
    priority: np.ndarray         # 0..100
    people_at_risk: np.ndarray   # expected people affected at the peak


def _crossing_minutes(P, thr):
    """Minutes until each column first reaches `thr` (linear interpolation between hours); nan if never."""
    H, n = P.shape
    out = np.full(n, np.nan)
    above = P >= thr
    for i in range(n):
        idx = np.flatnonzero(above[:, i])
        if len(idx) == 0:
            continue
        h = idx[0]
        out[i] = 0.0 if h == 0 else 60.0 * ((h - 1) + (thr - P[h - 1, i]) / max(P[h, i] - P[h - 1, i], 1e-9))
    return out


def compute_risk(ctx: Context) -> "Risk":
    cache_id = f"{ctx.cd.name}|{ctx.key}|{ctx.frame}"
    if cache_id in _CACHE:
        _CACHE.move_to_end(cache_id)
        return _CACHE[cache_id]
    cd, model = ctx.cd, get_model()
    n, H = cd.n, len(HS)

    X = context_features(ctx, HS, 1.0)
    p, sd = model.predict(X)
    P, SD = p.reshape(H, n), sd.reshape(H, n)

    # uncertainty range: drier / wetter forecast (one model, as a delta) + ensemble spread
    m0 = model.clf[0]
    base0 = m0.predict(X[FEATURES].to_numpy(float)).reshape(H, n)
    deltas = []
    for s in (RAIN_SCENARIOS[0], RAIN_SCENARIOS[2]):
        Xs = context_features(ctx, HS, s)
        deltas.append(m0.predict(Xs[FEATURES].to_numpy(float)).reshape(H, n) - base0)
    lo = np.clip(P + np.minimum(deltas[0], 0) - SD, 0, 1)
    hi = np.clip(P + np.maximum(deltas[1], 0) + SD, 0, 1)

    p_now = P[0]
    win = P[:13]
    h_peak = win.argmax(0)
    p_peak = win.max(0)
    lead_high = _crossing_minutes(P, THRESH["high"])
    lead_crit = _crossing_minutes(P, THRESH["critical"])

    # severity at each cell's peak hour
    rows = h_peak * n + np.arange(n)
    sp = model.severity(X.iloc[rows])
    sev = np.where(p_peak < THRESH["moderate"], 0, sp[:, 1:].argmax(1) + 1)

    c = cd.cells
    vuln = c.vuln.values
    priority = 100 * p_peak * (0.35 + 0.65 * vuln)
    risk = Risk(ctx, P, lo, hi, X, p_now, p_peak, h_peak, lead_high, lead_crit, sev, vuln, priority,
                p_peak * c["pop"].values)
    _CACHE[cache_id] = risk
    if len(_CACHE) > 48:
        _CACHE.popitem(last=False)
    return risk


def reasons_for(risk: Risk, cell_ids, top=3):
    """Plain-language reasons (largest positive SHAP contributions) for the given cells at their peak hour."""
    n = risk.ctx.cd.n
    cell_ids = list(cell_ids)
    if not cell_ids:
        return {}
    rows = [int(risk.h_peak[i]) * n + i for i in cell_ids]
    Xr = risk.X.iloc[rows]
    contrib = get_model().contributions(Xr)[:, :-1]
    out = {}
    for r, i in enumerate(cell_ids):
        order = np.argsort(-contrib[r])
        items = []
        for j in order[:top + 3]:
            if contrib[r, j] <= 0.05 or len(items) >= top:
                continue
            f = FEATURES[j]
            items.append(dict(feature=f, shap=round(float(contrib[r, j]), 2),
                              text=REASON_TEXT[f].format(v=Xr.iloc[r][f]) if f in REASON_TEXT else f))
        out[i] = items
    return out


def cell_series(risk: Risk, i: int):
    return dict(hours=HS.tolist(), p=np.round(risk.P[:, i], 3).tolist(), lo=np.round(risk.lo[:, i], 3).tolist(),
                hi=np.round(risk.hi[:, i], 3).tolist())


def level_arrays(risk: Risk):
    return (np.array([level_index(v) for v in risk.p_now]), np.array([level_index(v) for v in risk.p_peak]))


def central_forecast(ctx: Context, hs):
    """Fast central probability forecast P[h, cell] for the horizons `hs` (used for lead-time validation)."""
    p, _ = get_model().predict(context_features(ctx, hs, 1.0))
    return p.reshape(len(hs), ctx.cd.n)
