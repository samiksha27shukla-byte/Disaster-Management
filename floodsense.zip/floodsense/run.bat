@echo off
rem One-command start for Windows (not tested here - written to mirror run.sh)
cd /d %~dp0
if not exist .venv ( python -m venv .venv )
call .venv\Scripts\activate
pip install -q -r requirements.txt
python -m backend.ml.bootstrap
echo Open http://localhost:8000
uvicorn backend.main:app --host 0.0.0.0 --port 8000
