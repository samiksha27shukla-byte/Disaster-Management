"""Run:  pytest -q      (needs the built models: python -m backend.ml.bootstrap)"""
import numpy as np
import pandas as pd
import pytest
from fastapi.testclient import TestClient

import backend.db as dbmod


@pytest.fixture(scope="session")
def client(tmp_path_factory):
    dbmod.DB_PATH = tmp_path_factory.mktemp("db") / "test.db"          # never touch the real demo DB
    from backend.main import app
    with TestClient(app) as c:
        yield c


BASE = dict(city="Mumbai", mode="replay", event="MUM_EVT2", frame=7)


def state(client, **kw):
    r = client.post("/api/state", json={**BASE, **kw})
    assert r.status_code == 200, r.text
    return r.json()


# ---------------------------------------------------------------- API shape
def test_health_and_meta(client):
    assert client.get("/api/health").json()["model"] is True
    m = client.get("/api/meta").json()
    assert m["synthetic_data"] is True and len(m["cities"]) == 7
    assert m["model"]["metrics"]["auc"] > 0.8


def test_state_shape_and_ranges(client):
    s = state(client)
    cells = [c for c in s["cells"] if not c["water"]]
    assert len(cells) > 200
    for c in cells:
        assert 0 <= c["p_now"] <= 1 and 0 <= c["p_peak"] <= 1
        assert c["p_lo"] <= c["p_peak"] + 1e-9 <= c["p_hi"] + 2e-9          # uncertainty range brackets the forecast
        assert 0 <= c["vuln"] <= 1 and 0 <= c["sev"] <= 3
    assert len(s["traj"]) == 13 and len(s["traj"][0]) == len(s["cells"])
    assert s["summary"]["overall_level"] in ("Low", "Moderate", "High", "Critical")
    assert s["summary"]["truth"] is not None                                # replay frame >= 0 has ground truth


def test_unknown_inputs(client):
    assert client.post("/api/state", json={"city": "Atlantis"}).status_code == 404
    assert client.post("/api/state", json={**BASE, "event": "NOPE"}).status_code == 404
    assert client.post("/api/state", json={**BASE, "mode": "magic"}).status_code == 400


# ---------------------------------------------------------------- the model must respond sensibly
def test_scenario_is_monotonic_in_rain(client):
    lo = state(client, mode="scenario", scenario=dict(peak_mm_h=10))["summary"]
    hi = state(client, mode="scenario", scenario=dict(peak_mm_h=80))["summary"]
    assert hi["mean_p_peak"] > lo["mean_p_peak"] + 0.1
    assert hi["people_at_risk"] > lo["people_at_risk"]


def test_early_warning_rises_before_the_event(client):
    early = state(client, frame=-10)["summary"]["mean_p_peak"]          # forecast of the storm that has not started
    quiet = state(client, mode="scenario", scenario=dict(peak_mm_h=3, antecedent_mm_72h=0))["summary"]["mean_p_peak"]
    assert early > quiet


def test_replay_does_not_leak_the_future():
    from backend.context import replay_context
    from backend.data_service import get_city
    from backend.config import LOOKBACK
    cd = get_city("Mumbai")
    ev = cd.events["MUM_EVT2"]
    ctx = replay_context(cd, "MUM_EVT2", 3)
    a0 = ev["start_idx"] + 3 - LOOKBACK
    truth = cd.r1[a0:a0 + len(ctx.rain)]
    assert np.allclose(ctx.rain[:LOOKBACK + 1], truth[:LOOKBACK + 1])           # observed past is exact
    assert not np.allclose(ctx.rain[LOOKBACK + 1:LOOKBACK + 13], truth[LOOKBACK + 1:LOOKBACK + 13])   # future is a noisy forecast
    assert abs(ctx.riv[LOOKBACK + 12] - cd.riv[a0 + LOOKBACK + 12]) > 1e-4         # future river level re-simulated from the forecast, not copied


def test_train_serve_feature_parity():
    """Features built from a Context at horizon 0 must equal the training-CSV rows for the same hour."""
    from backend.context import replay_context
    from backend.data_service import LAND_USE, get_city
    from backend.ml.features import context_features
    cd = get_city("Chennai")
    ev = cd.events["CHE_EVT2"]
    X = context_features(replay_context(cd, "CHE_EVT2", 6), [0])
    tr = pd.read_csv("data/chennai_training.csv", parse_dates=["timestamp"])
    tr["land_use_code"] = tr.land_use_class.map(LAND_USE)
    row = tr[tr.timestamp == cd.abs_to_ts(ev["start_idx"] + 6)].reset_index(drop=True)
    for col, tol in [("rain_1h", .15), ("rain_3h", .3), ("rain_6h", .5), ("rain_24h", 1), ("rain_72h", 2), ("river_level_index", .01),
                     ("tide_level_m", .02), ("elevation_m", .01), ("twi", .01), ("land_use_code", 0)]:
        assert np.nanmax(np.abs(X[col].values - row[col].values)) <= tol, col


# ---------------------------------------------------------------- alerts: human in the loop
def test_critical_alerts_wait_for_a_human(client):
    s = state(client)
    crit = [a for a in s["alerts"] if a["level"] == "Critical"]
    assert crit and all(a["status"] == "pending_confirmation" for a in crit)
    assert all("citizens" in a["audience"] for a in crit)
    assert set(crit[0]["messages"]) >= {"en", "hi", "mr"}                   # Mumbai: English, Hindi, Marathi
    assert all(a["status"] == "watch" for a in s["alerts"] if a["level"] == "Moderate")
    a = crit[0]
    ok = client.post("/api/alert/decision", json=dict(city="Mumbai", ctx_key=s["context"]["key"], ward=a["ward"], level="Critical", action="confirm"))
    assert ok.status_code == 200
    after = [x for x in state(client)["alerts"] if x["ward"] == a["ward"] and x["level"] == "Critical"][0]
    assert after["status"] == "confirmed_sent"
    assert client.post("/api/alert/decision", json=dict(city="Mumbai", ctx_key="x", ward="w", level="High", action="explode")).status_code == 400


# ---------------------------------------------------------------- routing
def test_routes_never_cross_closed_roads():
    from backend.context import replay_context
    from backend.data_service import get_city
    from backend.services import routing
    from backend.services.risk import compute_risk
    cd = get_city("Mumbai")
    risk = compute_risk(replay_context(cd, "MUM_EVT2", 5))
    plan = routing.evac_plan(risk)
    G, Pm = routing.build_graph(cd), routing.minute_grid(risk)
    checked = 0
    for z in plan["zones"]:
        if not z.get("route"):
            continue
        path, t = z["route"]["path"], 0.0
        for u, v in zip(path[:-1], path[1:]):
            dt, _ = routing._edge(G, Pm, u, v, G["d"][(u, v)], t, path[0])
            assert dt is not None, "route crosses an edge that is closed at arrival time"
            t += dt
            checked += 1
    assert checked > 0


def test_route_endpoint(client):
    s = state(client)
    origin = [c for c in s["cells"] if not c["water"]][10]["id"]
    r = client.post("/api/route", json={**BASE, "origin_cell": origin})
    assert r.status_code == 200
    for q in r.json()["routes"]:
        assert q["safest"]["eta_min"] > 0 and len(q["safest"]["coords"]) >= 1


# ---------------------------------------------------------------- optimizer
def test_optimizer_respects_constraints():
    from backend.context import replay_context
    from backend.data_service import get_city
    from backend.services.alerts import build_alerts
    from backend.services.optimizer import plan_resources
    from backend.services.risk import compute_risk
    from backend.services.routing import evac_plan
    cd = get_city("Chennai")
    risk = compute_risk(replay_context(cd, "CHE_EVT2", 7))
    plan = plan_resources(risk, build_alerts(risk), evac_plan(risk))
    ids = [a["resource_id"] for a in plan["assignments"]]
    assert len(ids) == len(set(ids)), "a resource was assigned twice"
    avail = set(cd.resources[cd.resources.status == "available"].resource_id)
    assert set(ids) <= avail, "a deployed resource was dispatched"
    for kind, v in plan["summary"].items():
        assert v["assigned"] <= v["available"] and v["assigned"] <= v["required"]
        assert v["shortfall"] == v["required"] - v["assigned"]
    c = plan["comparison"]
    assert c["optimized"]["priority_weighted_coverage"] >= c["baseline"]["priority_weighted_coverage"]


# ---------------------------------------------------------------- social + verification
def test_verification_separates_genuine_from_rumour(client):
    s = state(client)
    hot = max((c for c in s["cells"] if not c["water"]), key=lambda c: c["p_now"])
    genuine = client.post("/api/report", json={**BASE, "text": "Knee deep water, cars stuck, buses stopped", "lat": hot["lat"], "lon": hot["lon"], "has_image": True}).json()
    rumour = client.post("/api/report", json={**BASE, "text": "Forward this: dam broke, Dadar will be drowned in 1 hour share now"}).json()
    chatter = client.post("/api/report", json={**BASE, "text": "Lovely rain today, chai time near Bandra"}).json()
    assert genuine["status"] in ("verified", "likely") and genuine["credibility"] >= 45
    assert rumour["status"] == "unverified" and rumour["credibility"] < genuine["credibility"]
    assert chatter["status"] == "not_flood"
    assert client.post("/api/report", json={**BASE, "text": "  "}).status_code == 400


def test_nlp_and_place_extraction():
    from backend.data_service import get_city
    from backend.ml.nlp import extract_place, get_nlp
    nlp = get_nlp()
    assert nlp.classify("Road closed, water above the divider near the station")[1] > 0.5
    assert nlp.classify("Beautiful clouds this evening, going for a walk")[1] < 0.5
    cd = get_city("Mumbai")
    assert extract_place(cd, "Bus stopped att Chembur, cannot cross")["name"] == "Chembur"
    assert extract_place(cd, "water logging near dadr station")["name"] == "Dadar"
    assert extract_place(cd, "nothing to see here") is None


# ---------------------------------------------------------------- history, overview, live
def test_history_and_compare(client):
    h = client.get("/api/history/Kochi").json()["events"]
    assert len(h) == 2 and h[0]["in_sample"] and not h[1]["in_sample"]
    rows = client.get("/api/compare").json()["rows"]
    assert len(rows) == 14
    for r in rows:
        assert 0 <= r["alerts_high"]["hit_rate"] <= 1 and 0 <= r["alerts_critical"]["false_alarm_share"] <= 1
    cities = client.get("/api/india").json()["cities"]
    assert len(cities) == 7 and {c["overall_level"] for c in cities} <= {"Low", "Moderate", "High", "Critical"}


def test_live_mode_parses_open_meteo_and_fails_cleanly(client, monkeypatch):
    import backend.services.live_weather as lw
    t0 = pd.Timestamp.now("UTC").tz_localize(None).floor("h") - pd.Timedelta(days=4, hours=2)
    times = [(t0 + pd.Timedelta(hours=i)).strftime("%Y-%m-%dT%H:%M") for i in range(24 * 9)]
    rain = np.zeros(len(times))
    rain[100:112] = 18.0                                                  # a storm somewhere around "now"
    monkeypatch.setattr(lw, "fetch_hourly", lambda lat, lon, timeout=8.0: {"hourly": {"time": times, "precipitation": rain.tolist()}, "utc_offset_seconds": 0})
    r = client.post("/api/state", json=dict(city="Nagpur", mode="live"))
    assert r.status_code == 200 and r.json()["context"]["mode"] == "live"

    def boom(*a, **k):
        raise RuntimeError("no network")
    monkeypatch.setattr(lw, "fetch_hourly", boom)
    r = client.post("/api/state", json=dict(city="Nagpur", mode="live"))
    assert r.status_code == 503 and "unavailable" in r.json()["detail"]
