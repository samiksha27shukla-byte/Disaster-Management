"""Build everything the app needs:  python -m backend.ml.bootstrap [--force]
data -> weather series -> social streams -> flood + severity models -> NLP -> replay metrics -> verification eval -> overview."""
import json
import subprocess
import sys

from ..config import DATA, MODELS, ROOT


def build_all(force: bool = False, verbose: bool = True):
    MODELS.mkdir(exist_ok=True)
    if force or not (DATA / "cities.json").exists():
        subprocess.run([sys.executable, str(ROOT / "data_gen" / "prepare_weather.py")], check=True)
    from ..data_service import load_all
    cities = load_all()
    if force or not (DATA / "social_mumbai.csv").exists():
        from .social_gen import make_streams
        make_streams(cities)
    if force or not (MODELS / "model_meta.json").exists():
        from .train import train
        train(verbose)
    if force or not (MODELS / "nlp.joblib").exists():
        from .nlp import train_nlp
        train_nlp(verbose)
    if force or not (MODELS / "replay_metrics.json").exists():
        from ..services.replay import compute_all_metrics
        compute_all_metrics(verbose)
    if force or not (MODELS / "verification_eval.json").exists():
        from ..services.social import evaluate_verification
        r = evaluate_verification(list(cities.values()))
        (MODELS / "verification_eval.json").write_text(json.dumps(r, indent=1))
        if verbose:
            print("verification:", r["auc"], r["mean_score_by_kind"])
    if force or not (MODELS / "india_overview.json").exists():
        from ..services.overview import build_overview
        build_overview()
    if verbose:
        print("bootstrap complete")


if __name__ == "__main__":
    build_all(force="--force" in sys.argv)
