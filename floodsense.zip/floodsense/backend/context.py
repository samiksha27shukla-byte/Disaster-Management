"""
A Context is "the weather situation at one moment": 96 h of observed history, 24+ h of FORECAST, and the
hydrology state (soil moisture, river level, tide). Everything downstream (risk, alerts, routes,
resources) is a function of a Context, so replaying a past event and running a what-if scenario
use exactly the same code.

 * replay_context   : a real (synthetic-history) event at frame f. Observed past, NOISY forecast of the
                      future - the future truth is never shown to the model.
 * scenario_context : the user types rainfall inputs (peak mm/h, duration, timing, antecedent wetness, tide).
"""
import hashlib
import json
from dataclasses import dataclass, field

import numpy as np

from .config import AXIS_LEN, LOOKBACK
from .data_service import CityData


@dataclass
class Context:
    cd: CityData
    mode: str
    key: str                      # stable id for alert decisions, e.g. "MUM_EVT2" or "scenario-ab12cd"
    label: str
    now_ts: object
    rain: np.ndarray              # city-mean hourly rain, observed to L, forecast after
    sm: np.ndarray
    riv: np.ndarray
    tide: np.ndarray
    L: int = LOOKBACK
    event: str | None = None
    frame: int | None = None
    abs_now: int | None = None
    params: dict = field(default_factory=dict)
    _cache: dict = field(default_factory=dict, repr=False)

    def arrays(self, scale: float = 1.0):
        """(rain, sm, riv, tide) with the FORECAST part of the rain multiplied by `scale`
        (soil moisture / river level are re-simulated forward)."""
        if scale == 1.0:
            return self.rain, self.sm, self.riv, self.tide
        if scale not in self._cache:
            rain = self.rain.copy()
            rain[self.L + 1:] *= scale
            sm, riv = self.sm.copy(), self.riv.copy()
            _rollout(self.cd, rain, sm, riv, self.L)
            self._cache[scale] = (rain, sm, riv, self.tide)
        return self._cache[scale]


def _rollout(cd: CityData, rain, sm, riv, start):
    """Advance soil moisture and river level for axis indices > start (same recursion as the generator)."""
    s = float(sm[start])
    r = -np.log(max(1e-9, 1 - float(riv[start])))
    decay = np.exp(-1 / cd.river_tau)
    for k in range(start + 1, len(rain)):
        s = min(1.0, s * np.exp(-1 / 180) + rain[k] / 120)
        r = r * decay + rain[k] / 120
        sm[k], riv[k] = max(s, 0.08), 1 - np.exp(-r)


def replay_context(cd: CityData, event_id: str, frame: int) -> Context:
    ev = cd.events[event_id]
    abs_now = ev["start_idx"] + int(frame)
    a0, n = abs_now - LOOKBACK, AXIS_LEN
    true = cd.r1[a0:a0 + n]
    rain = true.copy()
    rng = np.random.default_rng(abs_now)                     # same forecast every time this frame is asked for
    lead = np.arange(1, n - LOOKBACK)
    sigma = 0.22 + 0.012 * lead
    noise = rng.lognormal(-0.5 * sigma ** 2, sigma) * np.where(rng.random(len(lead)) < 0.04, 0.35, 1.0)
    rain[LOOKBACK + 1:] = true[LOOKBACK + 1:] * noise
    sm, riv = cd.sm[a0:a0 + n].copy(), cd.riv[a0:a0 + n].copy()
    _rollout(cd, rain, sm, riv, LOOKBACK)
    tide = cd.tide[a0:a0 + n].copy()
    return Context(cd, "replay", event_id, f"{cd.name} · {ev['date']} event", cd.abs_to_ts(abs_now), rain, sm, riv,
                   tide, event=event_id, frame=int(frame), abs_now=abs_now)


SCENARIO_DEFAULTS = dict(peak_mm_h=45.0, duration_h=8.0, hours_to_peak=4.0, antecedent_mm_72h=60.0,
                         tide_high_in_h=5.0, surge_m=0.3)


def scenario_context(cd: CityData, params: dict | None = None) -> Context:
    p = {**SCENARIO_DEFAULTS, **{k: float(v) for k, v in (params or {}).items() if k in SCENARIO_DEFAULTS}}
    n, L = AXIS_LEN, LOOKBACK
    t = np.arange(n) - L
    rain = np.zeros(n)
    w = np.exp(-np.arange(72)[::-1] / 36.0)                    # antecedent rain, heavier close to "now"
    rain[L - 71:L + 1] += p["antecedent_mm_72h"] * w / w.sum()
    sigma = max(p["duration_h"], 2.0) / 2.355
    rain += p["peak_mm_h"] * np.exp(-0.5 * ((t - p["hours_to_peak"]) / sigma) ** 2)
    sm, riv = np.full(n, 0.15), np.zeros(n)
    s, r = 0.15, 0.0
    decay = np.exp(-1 / cd.river_tau)
    for k in range(n):
        s = min(1.0, s * np.exp(-1 / 180) + rain[k] / 120)
        r = r * decay + rain[k] / 120
        sm[k], riv[k] = max(s, 0.08), 1 - np.exp(-r)
    if cd.coastal:
        tide = cd.tide_amp * np.cos(2 * np.pi * (t - p["tide_high_in_h"]) / 12.42) \
            + p["surge_m"] * np.exp(-0.5 * ((t - p["hours_to_peak"]) / 6.0) ** 2)
    else:
        tide = np.zeros(n)
    key = "scenario-" + hashlib.md5(json.dumps(p, sort_keys=True).encode()).hexdigest()[:6]
    import pandas as pd
    return Context(cd, "scenario", key, f"{cd.name} · what-if scenario", pd.Timestamp.now().floor("h"), rain, sm,
                   riv, tide, params=p)
