"""Feature definition. Training (from CSV) and inference (from a Context) use the same 24 columns."""
import numpy as np
import pandas as pd

FEATURES = [
    "elevation_m", "slope_deg", "relative_elevation", "flow_accumulation", "twi",
    "dist_to_river_m", "dist_to_drain_m", "dist_to_coast_m", "drain_density",
    "land_use_code", "imperviousness_pct", "vegetation_index",
    "rain_1h", "rain_3h", "rain_6h", "rain_24h", "rain_72h",
    "forecast_rain_next_6h", "forecast_rain_next_24h",
    "river_level_index", "tide_level_m", "soil_moisture",
    "past_flood_count_5y", "is_known_flood_spot",
]

# plain-language reason text per feature, used by the explanation layer
REASON_TEXT = {
    "rain_1h": "Intense rain right now ({v:.0f} mm/h)",
    "rain_3h": "Heavy rain in the last 3 h ({v:.0f} mm)",
    "rain_6h": "Sustained rain over 6 h ({v:.0f} mm)",
    "rain_24h": "Heavy 24 h rainfall ({v:.0f} mm)",
    "rain_72h": "Very wet last 3 days ({v:.0f} mm)",
    "forecast_rain_next_6h": "More rain forecast in next 6 h ({v:.0f} mm)",
    "forecast_rain_next_24h": "More rain forecast in next 24 h ({v:.0f} mm)",
    "soil_moisture": "Soil already saturated",
    "river_level_index": "River running high",
    "tide_level_m": "High tide slows drainage",
    "elevation_m": "Low-lying ground ({v:.0f} m)",
    "relative_elevation": "Local depression (lower than surroundings)",
    "twi": "Terrain collects water (high wetness index)",
    "flow_accumulation": "Large upslope area drains here",
    "slope_deg": "Flat terrain, water cannot run off",
    "dist_to_river_m": "Close to river/waterbody ({v:.0f} m)",
    "dist_to_drain_m": "Far from storm drains ({v:.0f} m)",
    "drain_density": "Sparse drainage network",
    "imperviousness_pct": "Paved surface, little absorption ({v:.0f}%)",
    "vegetation_index": "Little vegetation cover",
    "land_use_code": "Land use favours runoff",
    "dist_to_coast_m": "Close to the coast ({v:.0f} m)",
    "past_flood_count_5y": "Flooded before ({v:.0f}x in 5 yr)",
    "is_known_flood_spot": "Known flood-prone spot",
}


def _trail(cs, k, w):
    return cs[k + 1] - cs[np.maximum(0, k - w + 1)]


def _lead(cs, k, w):
    return cs[np.minimum(len(cs) - 1, k + 1 + w)] - cs[k + 1]


def context_features(ctx, hs, scale: float = 1.0) -> pd.DataFrame:
    """Feature rows for every cell at each horizon h in `hs` (hours after "now"). Hour-major order."""
    cd = ctx.cd
    rain, sm, riv, tide = ctx.arrays(scale)
    hs = np.asarray(hs, int)
    k = ctx.L + hs
    cs = np.concatenate([[0.0], np.cumsum(rain)])
    city = {
        "rain_1h": rain[k], "rain_3h": _trail(cs, k, 3), "rain_6h": _trail(cs, k, 6),
        "rain_24h": _trail(cs, k, 24), "rain_72h": _trail(cs, k, 72),
        "forecast_rain_next_6h": _lead(cs, k, 6), "forecast_rain_next_24h": _lead(cs, k, 24),
    }
    c = cd.cells
    n, H = cd.n, len(hs)
    rf = c.rf.values[None, :]
    out = {}
    for name in ("elevation_m", "slope_deg", "relative_elevation", "flow_accumulation", "twi", "dist_to_river_m",
                 "dist_to_drain_m", "dist_to_coast_m", "drain_density", "land_use_code", "imperviousness_pct",
                 "vegetation_index", "past_flood_count_5y", "is_known_flood_spot"):
        out[name] = np.broadcast_to(c[name].values.astype(float)[None, :], (H, n))
    for name, v in city.items():
        out[name] = v[:, None] * rf
    out["river_level_index"] = np.broadcast_to(riv[k][:, None], (H, n))
    out["tide_level_m"] = np.broadcast_to(tide[k][:, None], (H, n)) if cd.coastal else np.full((H, n), np.nan)
    out["soil_moisture"] = np.clip(sm[k][:, None] * (1.15 - 0.35 * c.imperviousness_pct.values[None, :] / 100), 0.02, 1.0)
    return pd.DataFrame({f: np.asarray(out[f]).reshape(-1) for f in FEATURES})
