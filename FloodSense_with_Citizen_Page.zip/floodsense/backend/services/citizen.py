"""Citizen (public) view.

A ward's advisory is shown only when the existing alert gate allows it:
  High      -> after the ward's report is verified        (citizens_status: advisory_ready / advisory_sent)
  Critical  -> only after an officer confirms it          (citizens_status: sent)
Anything else is shown only as generic 'monitoring' text. Probabilities, model reasons,
officer notes and pending alerts are never returned to the public.
"""
from ..gazetteer import CITY_LANG, LANG_NAME
from . import social
from .alerts import _nearest_safe_shelter, build_alerts

PUBLIC_STATUSES = {"advisory_ready", "advisory_sent", "sent"}

ACTIONS = [
    "Move to higher ground or the nearest shelter now.",
    "Avoid underpasses, low roads and moving water.",
    "Do not walk or drive through flood water.",
    "In an emergency call 112.",
]

NOTICE = "Demo: synthetic data from a past event. This is not an official flood statement."


def _languages(cd):
    """English, Hindi and the city's local language (the codes alert messages are written in)."""
    codes = list(dict.fromkeys(["en", "hi", CITY_LANG[cd.name]]))
    return [dict(code=c, name=LANG_NAME[c]) for c in codes]


def _shelter_dict(s):
    if not s:
        return None
    return dict(id=s["id"], name=s["name"], lat=s["lat"], lon=s["lon"])


def citizen_meta(ctx):
    """Ward list and languages for a city. No risk computation needed."""
    cd = ctx.cd
    wards = sorted(
        ({"id": w, "area": r.label, "lat": float(r.lat), "lon": float(r.lon)} for w, r in cd.wards.iterrows()),
        key=lambda x: x["area"],
    )
    return dict(city=cd.name, state=cd.state, mode=ctx.mode, now=str(ctx.now_ts)[:16], notice=NOTICE,
                wards=wards, languages=_languages(cd))


def citizen_view(risk, ward_id, lang=None):
    """Public view of one ward. Raises KeyError for an unknown ward."""
    ctx, cd = risk.ctx, risk.ctx.cd
    row = cd.wards.loc[ward_id]                      # KeyError if unknown
    alerts = {a["ward"]: a for a in build_alerts(risk, social.visible_reports(ctx))}
    a = alerts.get(ward_id)
    shelter = _nearest_safe_shelter(risk, row.lat, row.lon)
    i, _ = cd.nearest_cell(row.lat, row.lon)

    out = dict(
        city=cd.name, mode=ctx.mode, now=str(ctx.now_ts)[:16], notice=NOTICE,
        ward=dict(id=ward_id, area=row.label, lat=float(row.lat), lon=float(row.lon)),
        origin_cell=str(cd.cells.cell_id[i]),
        shelter=_shelter_dict(shelter),
        languages=_languages(cd),
    )

    if a and a["citizens_status"] in PUBLIC_STATUSES and a.get("messages"):
        msgs = a["messages"]
        code = lang if lang in msgs else ("en" if "en" in msgs else next(iter(msgs)))
        out.update(
            status="advisory",
            title="Flood warning",   # matches the wording of the alert text in every language
            advisory=dict(text=msgs[code]["text"], lang=code, lang_name=LANG_NAME[code]),
            actions=ACTIONS,
            language_options=[k for k in msgs],
        )
        # Advisory text names the shelter the alert chose; keep the shelter block consistent with it.
        if a.get("shelter"):
            out["shelter"] = _shelter_dict(a["shelter"])
    elif a and a["level_idx"] >= 1:
        out.update(
            status="monitoring",
            title="Conditions are being checked",
            advisory=None,
            message=(f"Rain and river levels in {row.label} are being monitored. If an advisory is issued it will "
                     "appear here. Do not wait for it if water is rising: move to higher ground and call 112."),
            actions=ACTIONS[-1:],
        )
    else:
        out.update(
            status="no_advisory",
            title="No flood advisory right now",
            advisory=None,
            message=(f"No flood advisory for {row.label} at this time. Heavy rain can still flood low roads quickly, "
                     "so keep checking this page."),
            actions=ACTIONS[-1:],
        )
    return out


def report_message(result):
    """Turn an internal report result into a neutral message. No scores are shown to the public."""
    if result.get("status") == "not_flood":
        return "Thanks. Your message did not describe flooding, so it was not sent to officers."
    return "Thank you. Your report has been received and will be checked against current conditions."
