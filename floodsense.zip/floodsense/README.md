# FloodSense — urban flood prediction, verification & response (PS 14 prototype)

> **All data is synthetic.** Terrain, rainfall history, population, emergency resources, social posts and even area
> names are generated so the *whole pipeline* works end to end. Nothing here is a statement about real flooding in
> any real neighbourhood. See [Limitations](#limitations-read-this) and [Swapping in real data](#swapping-in-real-data).

Existing systems map floods after they happen. FloodSense **predicts which places will flood hours ahead, verifies what
people report, and sends routes and resources before the water arrives — prioritising the people most at risk.**

![dashboard](docs/screenshots/01_main.png)

## Quick start

```bash
pip install -r requirements.txt
uvicorn backend.main:app --port 8000        # then open http://localhost:8000
```
or `./run.sh` (macOS/Linux) / `run.bat` (Windows, untested) — creates a virtualenv, installs, builds anything missing, serves.
Models and data are **already included**, so it starts in seconds. First click takes ~4 s (warm-up), then ~1.5 s per hour-step.

Docker: `docker compose up --build` (Dockerfile provided but **not tested** in the build environment).

## What it does — mapped to the PS 14 text

| PS 14 requirement | Where it lives |
|---|---|
| Aggregate weather forecasts | `context.py` — 96 h observed + 24 h **noisy forecast** (replay), user inputs (what-if), or real Open-Meteo rain (live) |
| Aggregate social-media signals | `ml/nlp.py`, `services/social.py` — classify, locate (GPS / place name), score |
| Aggregate geographic data | 24 terrain/drainage/land-use features per 500 m cell (`data/*_training.csv`) |
| Emergency resource availability | `data/resources_all_cities.csv` → feeds the **optimiser**, not the flood model (resources don't cause floods) |
| Flood-risk modelling | `ml/train.py` — 5-model LightGBM ensemble + severity model; probability **with uncertainty range** |
| Geospatial vulnerability mapping | `data_service.py` — vulnerability index (density, informal settlement, age, hospital access, infrastructure) → **priority = risk × vulnerability** |
| Real-time incident verification | `services/social.py` — credibility 0-100 from 5 signals; rumours and implausible spots score low |
| Dynamic evacuation routes | `services/routing.py` — **time-aware**: each road is judged at the hour you would reach it; routes carry a validity window |
| Resource allocation optimisation | `services/optimizer.py` — mixed-integer program, compared with first-come-first-served |
| Severity-based alerts | `services/alerts.py` — per ward, with audience routing, 3–4 languages, **human confirmation for Critical** |
| *(extras)* history & comparison | `services/replay.py` — replay + out-of-time validation, compare cities, India overview |

![cell](docs/screenshots/02_cell_routes.png)

## A 5-minute demo script

1. **India overview** (header) — 7 cities / 6 states ranked by share of city affected. Click Mumbai.
2. Drag the timeline to **−12 h** and press **Play**: no rain is forecast yet, but the city is already *Moderate* (saturated soil, high river from the two days before). Watch it escalate to *High* (~−8 h) and *Critical* (~−3 h) as the forecast storm arrives — Critical wards go from 2 to 16, hours before the labelled flooding window starts.
3. Click the top **Critical** alert: probability **with range**, severity, “impact in X min”, plain-language reasons (TreeSHAP). **Preview SMS** — English / Hindi / Marathi. **Confirm & broadcast** (Critical alerts wait for a human).
4. Click a red cell → **Why?**, **Who is exposed**, **Find safest routes**: green = safest, orange = fastest; “closes in 40 min if you wait”.
5. **Evacuate** tab: zones, shelters, “depart by”. **Resources** tab: needed vs available, shortfall, optimised vs first-come-first-served.
6. **Reports** tab: submit *“Forward this: dam broke…”* (scores ~0, unverified) vs *“Knee deep water near Kurla station”* with a photo (verified).
7. **What-if** tab: raise peak rain to 90 mm/h and watch everything re-compute. Switch layers to **Priority** / **Vulnerability** / **Actual**.
8. **History** tab: predicted vs actual flooded share, alert hit rate / lead time / false alarms for 2023 (in-sample) and 2025 (out-of-time).

## Architecture

```mermaid
flowchart LR
  subgraph Inputs
    W[Weather: replay / what-if / live Open-Meteo]
    G[Terrain · drainage · land use · population]
    S[Social posts]
    R[Resources · shelters · hospitals]
  end
  W --> C[Context: 96h observed + 24h forecast + soil/river/tide]
  C --> F[Feature builder - same 24 features as training]
  G --> F
  F --> M[LightGBM x5 + severity + SHAP]
  M --> K[Risk: P(h) 0-24h, range, lead time, severity, priority]
  S --> N[Text model + place extraction] --> V[Verification score]
  K --> V
  K --> A[Alerts: ward, audience, language, human confirm]
  K --> T[Time-aware routing]
  K --> O[MILP resource optimiser]
  R --> O
  R --> T
  A & T & O & V --> API[FastAPI]
  API --> UI[Leaflet + Chart.js dashboard]
  API --- DB[(SQLite: decisions, reports)]
```

**One idea ties it together:** every analysis is a function of a `Context` (the weather situation at one moment), so replaying 2025,
typing a what-if, or loading live rain all use exactly the same code path.

### Key design decisions
- **No future leakage in replay.** The model sees observed rain up to “now” and a *noisy forecast* after it (error grows with lead time); soil moisture and river level are re-simulated forward from that forecast. (`tests/test_api.py::test_replay_does_not_leak_the_future`)
- **Honest validation.** Models are trained on rows **before 2025**; the 2025 events are out-of-time. The 2023 events are in-sample and labelled so in the UI.
- **Uncertainty.** Range = drier/wetter forecast (×0.75 / ×1.3 rain) combined with ensemble spread.
- **Explainability.** Exact TreeSHAP values (LightGBM `pred_contrib`), translated to plain language.
- **Human in the loop.** Critical alerts stay `pending_confirmation` until an officer confirms (stored in SQLite); High alerts reach citizens only after verified reports or a high lower bound.
- **Routes are time-aware.** An edge is closed when its predicted probability *at the time you would reach it* passes 60% (35% for underpasses).

## Measured results (all on synthetic data)

| What | Result |
|---|---|
| Flood model, out-of-time test (2025, 64,628 rows) | AUC **0.85**, PR-AUC 0.56 (base rate 0.17); precision / recall at High (≥35%): 0.55 / 0.47 |
| Severity (when flooded) | exact class 64%, within one class 94% |
| Within-event ranking (replay, 7 out-of-time events) | mean AUC **0.75** — telling *which* cells flood in a storm is harder than *whether* it floods |
| **High alert** (≥35% within 6 h), 7 out-of-time events | catches **88%** of sustained floods before onset (range 71–99%), median lead **12 h**, but **~51% false-alarm share** (40–65%) |
| **Critical alert** (≥60%), same events | catches ~50%, median lead 8 h, **~19% false-alarm share** |
| Report verification (genuine vs misplaced/rumour) | AUC **0.78**; rumours → 0% verified, but misplaced-location reports are only partly caught (32% still verified vs 50% of genuine) |
| Text model, held-out templates | flood-vs-not F1 **0.84**; 5-way *type* accuracy only **0.37** (weak) |
| Optimiser vs first-come-first-served (Mumbai, peak) | priority-weighted coverage 25% → 32%, response 17 → 12 min, same resources |

The honest trade-off is **recall vs false alarms**: lowering the threshold warns earlier and catches more, at the cost of crying wolf. “Sustained flood” = 3+ consecutive flooded hours (labels flicker hour to hour, so one hour is not a flood). Lead time is measured from 12 h before the labelled window; earlier warnings are not counted.

## API (FastAPI, interactive docs at `/docs`)

| Endpoint | Purpose |
|---|---|
| `POST /api/state` | Everything for the dashboard: risk per cell, alerts, evacuation plan, resource plan, reports |
| `POST /api/cell` | One cell: 24 h forecast + range, SHAP reasons, vulnerability, truth (replay) |
| `POST /api/route` | Safest vs fastest routes from a cell to safe shelters, with validity window |
| `POST /api/report` | Submit a citizen report → classified, located, scored, stored |
| `POST /api/alert/decision` | Officer confirms / dismisses an alert (persisted) |
| `GET /api/india` · `/api/history/{city}` · `/api/compare` · `/api/meta` | Overview, replay metrics, model card |
| `GET /api/live/{city}` | Real hourly rain from Open-Meteo (needs internet; 503 otherwise) |

Every analytical call takes `{city, mode: replay|scenario|live, event, frame, scenario}`.

## Limitations (read this)

- **Synthetic everything.** The flood label comes from a rule-based simulator (rain × terrain × drainage × soil × river × tide + noise). A model that scores well here has learned *the simulator*, not physics. Treat the numbers above as proof the **pipeline works**, not that floods are predictable to this accuracy.
- **Antecedent wetness drives early flags.** The simulated events are preceded by two days of heavy rain, so some low-lying wards are already High/Critical *before* any new rain is forecast (“impact now” there reflects saturation, not incoming rain). Real events with a dry run-up would start lower.
- **Grid, not streets.** Roads are an 8-neighbour grid (`routing.py`); rivers are crossable only at pseudo-bridges. Swap in an OSMnx graph for real routing.
- **Place names are demo labels** snapped to synthetic cells (gazetteer coordinates approximate).
- **The text model is trained on templates.** Real tweets will score lower; it still false-fires on some benign text that shares words with flood templates. Replace with CrisisNLP / HumAID.
- **Verification weights are hand-set**, not learned. Location checks can only be as good as the model's spatial skill.
- **Probabilities are not calibrated frequencies.** Training data is oversampled with storm hours (base rate 14%), so “60%” means *relative* risk in this dataset.
- **Resource demand rules are heuristics** (e.g. 1–2 pumps per High cell); real thresholds need operational input.
- **Citizen alert translations are machine-written** — have native speakers review before any real use. No SMS is actually sent.
- **Live mode** pairs real rainfall with synthetic terrain and omits tide. It was tested only with a mocked response (no internet in the build sandbox).
- `run.bat` and the Dockerfile were written but **not executed** in the build environment.
- Single-process demo server; no authentication, no multi-user locking.

## Swapping in real data

1. **Rain**: ERA5 / IMD for history, Open-Meteo or IMD for forecasts → fill `Context.rain` (see `live_weather.py` for the pattern).
2. **Terrain / drainage / land use**: Copernicus DEM (elevation, slope, TWI, flow accumulation), OpenStreetMap (rivers, drains, roads), ESA WorldCover (imperviousness). Keep the 24 columns in `ml/features.py`.
3. **Labels**: Bhuvan-Flood / NDEM flood layers, Sentinel-1 flood extents, geocoded flood-prone spots. **Split by event, never randomly.**
4. **Routing**: replace `build_graph()` with an OSMnx graph; the time-aware Dijkstra and validity logic stay.
5. **Social text**: retrain `ml/nlp.py` on CrisisNLP / HumAID; keep place masking.
6. **Resources / shelters / population**: ward-level census + the control room's asset register.
Then `python -m backend.ml.bootstrap --force`.

## Project layout

```
backend/
  main.py            FastAPI app + endpoints
  context.py         weather situation (replay / scenario) incl. forecast + hydrology rollout
  data_service.py    cells, vulnerability, weather, truth, resources, gazetteer
  db.py              SQLite (officer decisions, submitted reports)
  ml/                features.py · model.py · train.py · nlp.py · social_gen.py · bootstrap.py
  services/          risk · alerts · routing · optimizer · social · replay · overview · live_weather
frontend/            index.html · app.js · style.css · vendor/ (Leaflet, Chart.js - bundled, no CDN)
data/                7 cities: training/cells CSVs, hourly weather, social streams, resources
data_gen/            generate_flood_data.py (dataset generator) · prepare_weather.py
models/              trained models + metrics JSON
tests/               15 tests (pytest)
docs/screenshots/
```

## Develop

```bash
pip install -r requirements-dev.txt
pytest -q                                    # 15 tests, ~20 s
python -m backend.ml.bootstrap --force       # rebuild weather series, streams, models, metrics (~2 min)
python data_gen/generate_flood_data.py data  # regenerate the base synthetic datasets (then bootstrap --force)
```

The map uses OpenStreetMap tiles (internet needed for the base map only; everything else works offline).
