"""India-level overview: each city's headline situation (its 2025 event at the peak frame) rolled up by state."""
import json

import numpy as np

from ..config import CITY_ORDER, LEVELS, MODELS, THRESH, city_level_index, level_index
from ..context import replay_context
from ..data_service import get_city
from .alerts import build_alerts
from .risk import compute_risk
from .routing import evac_plan

PEAK_FRAME = 7


def city_summary(cd, event=None, frame=PEAK_FRAME):
    event = event or sorted(cd.events)[-1]
    ctx = replay_context(cd, event, frame)
    r = compute_risk(ctx)
    alerts = build_alerts(r)
    evac = evac_plan(r)
    land = ~cd.cells.is_water.values
    lv = np.array([level_index(p) for p in r.p_peak])[land]
    lead = [a["impact_in_min"] for a in alerts if a["level_idx"] >= 2 and a["impact_in_min"] is not None]
    top = city_level_index(lv)
    return dict(
        city=cd.name, state=cd.state, lat=cd.lat0, lon=cd.lon0, event=event, date=cd.events[event]["date"], frame=frame,
        overall_level=LEVELS[top], level_counts={LEVELS[i]: int((lv == i).sum()) for i in range(4)},
        mean_peak_probability=round(float(r.p_peak[land].mean()), 3), max_probability=round(float(r.p_peak.max()), 3),
        people_at_risk=int(r.people_at_risk[r.p_peak >= THRESH["high"]].sum()),
        critical_wards=int(sum(a["level"] == "Critical" for a in alerts)), high_wards=int(sum(a["level"] == "High" for a in alerts)),
        next_impact_min=min(lead) if lead else None, evacuees=evac["people_total"],
        rain_24h_mm=cd.events[event]["total_mm_24h"], n_cells=int(land.sum()))


def build_overview():
    cities = [city_summary(get_city(c)) for c in CITY_ORDER]
    states = {}
    for c in cities:
        s = states.setdefault(c["state"], dict(state=c["state"], cities=[], people_at_risk=0, critical_wards=0, high_wards=0, top=0))
        s["cities"].append(c["city"])
        s["people_at_risk"] += c["people_at_risk"]
        s["critical_wards"] += c["critical_wards"]
        s["high_wards"] += c["high_wards"]
        s["top"] = max(s["top"], LEVELS.index(c["overall_level"]))
    for s in states.values():
        s["overall_level"] = LEVELS[s.pop("top")]
    out = dict(cities=cities, states=list(states.values()))
    (MODELS / "india_overview.json").write_text(json.dumps(out, indent=1))
    return out


def load_overview():
    p = MODELS / "india_overview.json"
    return json.loads(p.read_text()) if p.exists() else build_overview()
