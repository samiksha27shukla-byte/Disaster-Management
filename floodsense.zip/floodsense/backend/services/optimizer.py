"""
Resource allocation: which pump / boat / ambulance / rescue team goes where.

1. DEMAND is derived from the forecast (not typed in): High+ cells need pumps, populated Critical cells need boats,
   High/Critical wards need ambulances, Critical wards need rescue teams, cut-off zones need boats.
2. SUPPLY is the list of resources whose status is 'available'.
3. A mixed-integer program (SciPy / HiGHS) assigns resources to sites, maximising priority-weighted coverage
   and breaking ties by response time.
4. It is compared with a naive first-come-first-served dispatch so the benefit is measurable.
Since it runs on the FORECAST, it doubles as pre-positioning: `dispatch_by_min` says when to leave.
"""
import math

import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp

from ..config import THRESH
from .risk import Risk

SPEED = {"pump": 20, "boat": 12, "ambulance": 35, "rescue_team": 28}     # km/h
MOBILISE_MIN = 5
DETOUR = 1.35
MAX_ETA = 90
W_PRIORITY = 3.0
TYPES = ["pump", "boat", "ambulance", "rescue_team"]


def _eta(dx, dy, kind):
    return MOBILISE_MIN + DETOUR * math.hypot(dx, dy) / (SPEED[kind] * 1000 / 60.0)


def _demand_sites(risk: Risk, alerts: list[dict], evac: dict | None):
    cd = risk.ctx.cd
    c = cd.cells
    land = ~c.is_water.values
    high = np.flatnonzero((risk.p_peak >= THRESH["high"]) & land)
    top = high[np.argsort(-risk.priority[high])][:40]
    sites = {t: [] for t in TYPES}
    for i in top:
        sites["pump"].append((int(i), 2 if risk.p_peak[i] >= THRESH["critical"] else 1))
    crit = [i for i in top if risk.p_peak[i] >= THRESH["critical"] and risk.people_at_risk[i] >= 300][:12]
    for i in crit:
        sites["boat"].append((int(i), int(np.clip(math.ceil(risk.people_at_risk[i] / 1500), 1, 3))))
    wards = cd.wards
    for a in alerts:
        if a["level_idx"] < 2:
            continue
        cells = [i for i in wards.loc[a["ward"], "cells"] if not c.is_water[i]]
        top_cell = int(max(cells, key=lambda i: risk.priority[i]))
        sites["ambulance"].append((top_cell, 2 if a["level"] == "Critical" else 1))
        if a["level"] == "Critical":
            sites["rescue_team"].append((top_cell, 2 if a["severity_idx"] >= 3 else 1))
    for z in (evac or {}).get("zones", []):
        if z.get("status") == "ISOLATED":
            cell = int(cd.nearest_cell(z["lat"], z["lon"])[0])
            sites["boat"].append((cell, 2))
            sites["rescue_team"].append((cell, 1))
    # merge duplicate sites
    for t in TYPES:
        m = {}
        for cell, u in sites[t]:
            m[cell] = max(m.get(cell, 0), u)
        sites[t] = sorted(m.items(), key=lambda kv: -risk.priority[kv[0]])
    return sites


def _solve(kind, res, sites, risk):
    """res: rows of available resources of this type. Returns list of (resource_row_idx, site_cell, eta)."""
    cd = risk.ctx.cd
    c = cd.cells
    pairs = []
    for r_i, r in enumerate(res.itertuples()):
        for s_i, (cell, _) in enumerate(sites):
            eta = _eta(c.x[cell] - r.x, c.y[cell] - r.y, kind)
            if eta <= MAX_ETA:
                pairs.append((r_i, s_i, eta))
    if not pairs:
        return []
    nv = len(pairs)
    obj = np.array([-(W_PRIORITY * risk.priority[sites[s][0]] - eta) for _, s, eta in pairs])
    A = np.zeros((len(res) + len(sites), nv))
    ub = np.concatenate([np.ones(len(res)), [u for _, u in sites]])
    for v, (r, s, _) in enumerate(pairs):
        A[r, v] = 1
        A[len(res) + s, v] = 1
    sol = milp(obj, constraints=LinearConstraint(A, -np.inf, ub), integrality=np.ones(nv), bounds=Bounds(0, 1))
    if sol.x is None:
        return []
    return [(r, sites[s][0], eta) for v, (r, s, eta) in enumerate(pairs) if sol.x[v] > 0.5]


def _naive(kind, res, sites, risk):
    """First-come-first-served: sites in arrival (cell id) order, each takes its nearest free resource."""
    cd = risk.ctx.cd
    c = cd.cells
    free = set(range(len(res)))
    out = []
    for cell, units in sorted(sites, key=lambda s: s[0]):
        for _ in range(units):
            if not free:
                return out
            r_i = min(free, key=lambda r: math.hypot(c.x[cell] - res.x.iloc[r], c.y[cell] - res.y.iloc[r]))
            eta = _eta(c.x[cell] - res.x.iloc[r_i], c.y[cell] - res.y.iloc[r_i], kind)
            if eta <= MAX_ETA:
                out.append((r_i, cell, eta))
                free.discard(r_i)
    return out


def _score(assign_by_type, sites_by_type, risk):
    pr = risk.priority
    tot_w = sum(pr[cell] * u for t in TYPES for cell, u in sites_by_type[t]) or 1.0
    got_w = covered_30 = tot_units = 0.0
    etas, ws = [], []
    hp_units = hp_cov = 0
    for t in TYPES:
        for cell, u in sites_by_type[t]:
            tot_units += u
            if pr[cell] >= 50:
                hp_units += u
        for _, cell, eta in assign_by_type[t]:
            got_w += pr[cell]
            etas.append(eta)
            ws.append(pr[cell])
            if pr[cell] >= 50 and eta <= 30:
                hp_cov += 1
    n_assigned = sum(len(v) for v in assign_by_type.values())
    return dict(units_covered=int(n_assigned), units_needed=int(tot_units),
                priority_weighted_coverage=round(got_w / tot_w * 100, 1),
                avg_response_min=round(float(np.average(etas, weights=ws)) if etas else 0.0, 1),
                high_priority_within_30min=f"{hp_cov}/{hp_units}")


def plan_resources(risk: Risk, alerts: list[dict], evac: dict | None = None) -> dict:
    cd = risk.ctx.cd
    c = cd.cells
    avail = cd.resources[cd.resources.status == "available"]
    sites = _demand_sites(risk, alerts, evac)
    opt, naive, assignments, summary = {}, {}, [], {}
    for kind in TYPES:
        res = avail[avail.type == kind].reset_index(drop=True)
        total = int(sum(u for _, u in sites[kind]))
        if res.empty or not sites[kind]:
            opt[kind], naive[kind] = [], []
        else:
            opt[kind], naive[kind] = _solve(kind, res, sites[kind], risk), _naive(kind, res, sites[kind], risk)
        for r_i, cell, eta in opt[kind]:
            r = res.iloc[r_i]
            lead = risk.lead_high_min[cell]
            dispatch_by = None if np.isnan(lead) else max(0.0, float(lead) - eta - 10)
            assignments.append(dict(
                resource_id=r.resource_id, type=kind, from_lat=float(r.lat), from_lon=float(r.lon),
                to_lat=float(c.lat[cell]), to_lon=float(c.lon[cell]), site=f"{cd.place_of_cell(cell) or ''} ({c.cell_id[cell]})".strip(),
                site_cell=int(cell), eta_min=round(eta), priority=round(float(risk.priority[cell]), 1),
                p_peak=round(float(risk.p_peak[cell]), 2),
                dispatch_by_min=None if dispatch_by is None else round(dispatch_by),
                action="DISPATCH NOW" if dispatch_by is None or dispatch_by <= 10 else f"Pre-position, dispatch in {round(dispatch_by)} min"))
        summary[kind] = dict(required=total, available=int(len(res)), assigned=len(opt[kind]),
                             shortfall=max(0, total - len(opt[kind])))
    unmet = []
    for kind in TYPES:
        got = {}
        for _, cell, _ in opt[kind]:
            got[cell] = got.get(cell, 0) + 1
        for cell, u in sites[kind]:
            if got.get(cell, 0) < u:
                unmet.append(dict(type=kind, site=f"{cd.place_of_cell(cell) or ''} ({c.cell_id[cell]})".strip(),
                                  units=u - got.get(cell, 0), priority=round(float(risk.priority[cell]), 1)))
    unmet.sort(key=lambda u: -u["priority"])
    assignments.sort(key=lambda a: -a["priority"])
    ev_total = (evac or {}).get("people_total", 0)
    cap = (evac or {}).get("shelter_capacity_total", int(cd.shelters.capacity.sum()))
    return dict(summary=summary, assignments=assignments, unmet=unmet[:12],
                comparison=dict(baseline=_score(naive, sites, risk), optimized=_score(opt, sites, risk)),
                shelters=dict(evacuees=ev_total, capacity=cap, gap=max(0, ev_total - cap)),
                n_available=int(len(avail)), n_deployed=int((cd.resources.status == "deployed").sum()))
