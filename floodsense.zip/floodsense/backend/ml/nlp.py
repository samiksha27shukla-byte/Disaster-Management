"""Social-media text model: classify a post (waterlogging / road_blocked / rescue_request / damage / not_flood)
and pull a place name out of it. TF-IDF (word + character n-grams, robust to typos and Hinglish) + logistic regression.

Evaluation is on HELD-OUT TEMPLATES, but the text is still templated, so scores are optimistic compared with real tweets.
"""
import difflib
import json
import re
from functools import lru_cache

import joblib
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score
from sklearn.pipeline import make_pipeline, make_union

from ..config import MODELS
from ..gazetteer import GAZETTEER
from .social_gen import make_corpus

NLP_PATH = MODELS / "nlp.joblib"
NLP_META = MODELS / "nlp_meta.json"


_PLACE_RE = re.compile(r"\b(" + "|".join(sorted({re.escape(n) for d in GAZETTEER.values() for n in d} | {"our area"},
                                              key=len, reverse=True)) + r")\b", re.I)


def mask_places(text: str) -> str:
    """Replace place names by a neutral token so the model cannot learn 'Kurla => flood'."""
    return _PLACE_RE.sub(" placetoken ", text)


def _pipe():
    return make_pipeline(
        make_union(TfidfVectorizer(ngram_range=(1, 2), sublinear_tf=True),
                   TfidfVectorizer(analyzer="char_wb", ngram_range=(2, 5), sublinear_tf=True, min_df=2)),
        LogisticRegression(C=10, max_iter=600))


def train_nlp(verbose=True) -> dict:
    MODELS.mkdir(exist_ok=True)
    corpus = make_corpus()
    corpus["text"] = corpus.text.map(mask_places)
    tr, te = corpus[corpus.split == "train"], corpus[corpus.split == "test"]
    pipe = _pipe().fit(tr.text, tr.label)
    pred = pipe.predict(te.text)
    y_bin, p_bin = te.label != "not_flood", pd_not(pred)
    metrics = dict(
        n_train=len(tr), n_test_heldout_templates=len(te),
        accuracy_5class=round(float(accuracy_score(te.label, pred)), 3),
        flood_vs_not_precision=round(float(precision_score(y_bin, p_bin)), 3),
        flood_vs_not_recall=round(float(recall_score(y_bin, p_bin)), 3),
        flood_vs_not_f1=round(float(f1_score(y_bin, p_bin)), 3))
    pipe.fit(corpus.text, corpus.label)              # final model sees all templates
    joblib.dump(pipe, NLP_PATH)
    NLP_META.write_text(json.dumps(metrics, indent=1))
    if verbose:
        print("NLP:", metrics)
    return metrics


def pd_not(pred):
    return [p != "not_flood" for p in pred]


class SocialNLP:
    def __init__(self):
        try:
            self.pipe = joblib.load(NLP_PATH)
        except Exception:                      # missing file or scikit-learn version mismatch -> rebuild (takes seconds)
            train_nlp(verbose=False)
            self.pipe = joblib.load(NLP_PATH)
        self.classes = list(self.pipe.classes_)
        self.i_not = self.classes.index("not_flood")

    def classify_full(self, text: str):
        pr = self.pipe.predict_proba([mask_places(text)])[0]
        flood_conf = float(1 - pr[self.i_not])
        sub = {c: p for c, p in zip(self.classes, pr) if c != "not_flood"}
        label = "not_flood" if flood_conf < 0.5 else max(sub, key=sub.get)
        return dict(label=label, flood_conf=flood_conf, rumor_prob=float(pr[self.classes.index("rumor")]))

    def classify(self, text: str):
        """-> (label, flood_confidence) where flood_confidence = 1 - P(not_flood)."""
        r = self.classify_full(text)
        return r["label"], r["flood_conf"]


@lru_cache(maxsize=1)
def get_nlp() -> SocialNLP:
    return SocialNLP()


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9 ]+", " ", s.lower())


def extract_place(cd, text: str):
    """Find a known place name in the text (exact, then fuzzy for typos). -> gazetteer entry or None."""
    t = " " + re.sub(r"\s+", " ", _norm(text)) + " "
    for g in sorted(cd.gaz, key=lambda g: -len(g["name"])):
        if f" {_norm(g['name']).strip()} " in t:
            return g
    words = t.split()
    names = {_norm(g["name"]).strip(): g for g in cd.gaz}
    for n in (1, 2, 3):
        for i in range(len(words) - n + 1):
            gram = " ".join(words[i:i + n])
            m = difflib.get_close_matches(gram, list(names), n=1, cutoff=0.84)
            if m and len(gram) >= 4:
                return names[m[0]]
    return None
